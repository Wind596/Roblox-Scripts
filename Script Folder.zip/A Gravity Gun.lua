local MD = false
local p = game:GetService("Players").LocalPlayer

p:GetMouse().Button1Up:Connect(function()
	MD = false
end)

p:GetMouse().Button1Down:Connect(function()
	if MD then return end
	MD = true
	if p:GetMouse().Target == nil then return end
	if p:GetMouse().Target.Anchored == true then return end
	if not game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.F) then return end
	local part = p:GetMouse().Target
	part.CanCollide = false
	local BP = Instance.new("BodyPosition", part)
	BP.MaxForce = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
	repeat
		BP.Position = p:GetMouse().Hit.Position
		wait()
	until MD == false
	part.CanCollide = true
	BP:Destroy()
end)