local p = game:GetService("Players").LocalPlayer
local char = p.Character

loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
workspace:WaitForChild('Rig')

local speed = 2

local c = workspace.Rig
wait()

p.Character["Torso"]:Destroy()
char["Right Leg"]:Destroy()
char["Left Leg"]:Destroy()
c.Humanoid.PlatformStand = true
local Root = c["Head"]
local BV = Instance.new("BodyVelocity", Root)
local BG = Instance.new("BodyGyro", Root)
local MD = false
flying = true
BG.MaxTorque = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
BV.MaxForce = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
BV.Velocity = Vector3.new(0,0,0)
char.Humanoid.WalkSpeed = 0
char.Humanoid.JumpPower = 0
c.Humanoid.WalkSpeed = 0
c.Humanoid.JumpPower = 0
workspace.CurrentCamera.CameraSubject = Root

local LeftHand = c["Left Arm"]
local LA = Instance.new("Attachment",LeftHand)
LA.CFrame = CFrame.new(1, -1.5, 1.5, 1, 0, 0, 0, -4.37113883e-08, -1, 0, 1, -4.37113883e-08)
LA.Name = "LeftHandHook"

local att1 = Instance.new("Attachment",Root)

local ap = Instance.new("AlignPosition",LeftHand)
ap.Attachment0 = LA
ap.Attachment1 = att1
ap.RigidityEnabled = true 

local ao = Instance.new("AlignOrientation",LeftHand) 
ao.Attachment0 = LA
ao.Attachment1 = att1
ao.RigidityEnabled = true

local RightHand = c["Right Arm"]
local RA = Instance.new("Attachment",RightHand)
RA.CFrame = CFrame.new(-1, 1.5, -1.5, 1, 0, 0, 0, -4.37113883e-08, 1, 0, -1, -4.37113883e-08)
RA.Name = "RightHandHook"

local att1 = Instance.new("Attachment",Root)

local ap = Instance.new("AlignPosition",RightHand)
ap.Attachment0 = RA
ap.Attachment1 = att1
ap.RigidityEnabled = true 

local ao = Instance.new("AlignOrientation",RightHand) 
ao.Attachment0 = RA
ao.Attachment1 = att1
ao.RigidityEnabled = true

local flyreq = game:GetService('UserInputService').InputBegan:Connect(function(key, gay)
	if gay then return end
	if key.KeyCode == Enum.KeyCode.W then
		while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.W) do
			BV.Velocity += workspace.CurrentCamera.CFrame.LookVector * speed
			wait()
		end
		BV.Velocity = Vector3.new(0,0,0)
	elseif key.KeyCode == Enum.KeyCode.S then
		while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.S) do
			BV.Velocity -= workspace.CurrentCamera.CFrame.LookVector * 4
			wait()
		end
		BV.Velocity = Vector3.new(0,0,0)
	elseif key.KeyCode == Enum.KeyCode.F then
		game:GetService("TweenService"):Create(RA, TweenInfo.new(0.3), {['CFrame'] = CFrame.new(-2, -1, 1.5, 0.766044438, -0.642787576, 0, 0.642787576, 0.766044438, -0, 0, 0, 0.99999994)}):Play()
		wait(0.3)
		game:GetService("TweenService"):Create(RA, TweenInfo.new(0.3), {['CFrame'] = CFrame.new(-0, -0.100000001, 1.5, 0.766044438, 0.642787576, -0, -0.642787576, 0.766044438, 0, 0, 0, 0.99999994)}):Play()
		wait(0.3)
		game:GetService("TweenService"):Create(RA, TweenInfo.new(0.3), {['CFrame'] = CFrame.new(-2, -1, 1.5, 0.766044438, -0.642787576, 0, 0.642787576, 0.766044438, -0, 0, 0, 0.99999994)}):Play()
		wait(0.3)
		game:GetService("TweenService"):Create(RA, TweenInfo.new(0.3), {['CFrame'] = CFrame.new(-1, 1.5, -1.5, 1, 0, 0, 0, -4.37113883e-08, 1, 0, -1, -4.37113883e-08)}):Play()
	end
end)

local MUP = p:GetMouse().Button1Up:Connect(function()
	MD = false
end)

local MDOWN = p:GetMouse().Button1Down:Connect(function()
	if MD then return end
	MD = true
	if p:GetMouse().Target == nil then return end
	if p:GetMouse().Target.Anchored == true then return end
	if not game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.Q) then return end
	local part = p:GetMouse().Target
	part.CanCollide = false
	local BP = Instance.new("BodyPosition", part)
	BP.MaxForce = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
	repeat
		BP.Position = p:GetMouse().Hit.Position
		wait()
	until MD == false
	part.CanCollide = true
	BP:Destroy()
end)

c:FindFirstChildOfClass("Humanoid").Died:Connect(function()
	flying = false
	flyreq:Disconnect()
	BV:Destroy()
	BG:Destroy()
	MUP:Disconnect()
	MDOWN:Disconnect()
end)

spawn(function()
	repeat
		wait()
		BG.CFrame = workspace.CurrentCamera.CFrame
	until flying == false 
	flyreq:Disconnect()
	BV:Destroy()
	BG:Destroy()
end)

for i,v in pairs(char:GetDescendants()) do
	if v:IsA("Clothing") or v:IsA("ShirtGraphic") then
		v:Destroy()
	end
end

c.Torso["Right Shoulder"]:Destroy()
c.Torso["Left Shoulder"]:Destroy()

if c:FindFirstChild("ForceField") then
   c.ForceField:Destroy() 
end

loadstring(game:HttpGet(('https://ghostbin.co/paste/krmyf/raw'),true))()