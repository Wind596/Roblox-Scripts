local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local GPA = Instance.new("TextButton")
local UICorner = Instance.new("UICorner")
local UICorner_2 = Instance.new("UICorner")
local TextLabel = Instance.new("TextLabel")
local ID = Instance.new("TextBox")
local UICorner_3 = Instance.new("UICorner")
local p = game:GetService("Players").LocalPlayer

ScreenGui.Parent = game:GetService("CoreGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.424013436, 0, 0.438106805, 0)
Frame.Size = UDim2.new(0, 180, 0, 102)

GPA.Name = "GPA"
GPA.Parent = Frame
GPA.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
GPA.BorderSizePixel = 0
GPA.Position = UDim2.new(0.0388888903, 0, 0.702911496, 0)
GPA.Size = UDim2.new(0, 165, 0, 21)
GPA.Font = Enum.Font.SciFi
GPA.Text = "Play"
GPA.TextColor3 = Color3.fromRGB(255, 255, 255)
GPA.TextSize = 14.000
GPA.TextWrapped = true

UICorner.CornerRadius = UDim.new(0, 5)
UICorner.Parent = GPA

UICorner_2.CornerRadius = UDim.new(0, 5)
UICorner_2.Parent = Frame

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0, 0, 0.0588235296, 0)
TextLabel.Size = UDim2.new(0, 180, 0, 14)
TextLabel.Font = Enum.Font.SciFi
TextLabel.Text = "Animation ID Player"
TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.TextSize = 14.000

ID.Name = "ID"
ID.Parent = Frame
ID.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
ID.BorderSizePixel = 0
ID.Position = UDim2.new(0.0666666701, 0, 0.40196079, 0)
ID.Size = UDim2.new(0, 154, 0, 19)
ID.Font = Enum.Font.SciFi
ID.PlaceholderText = "ID Here"
ID.Text = ""
ID.TextColor3 = Color3.fromRGB(255, 255, 255)
ID.TextSize = 14.000

UICorner_3.CornerRadius = UDim.new(0, 5)
UICorner_3.Parent = ID

GPA.MouseButton1Click:Connect(function()
	if p.Character ~= nil and p.Character:FindFirstChildOfClass("Humanoid") then

		local animid
		
		if tonumber(ID.Text) then 
		   animid = "rbxassetid://" .. ID.Text 
		else
		   animid = ID.Text 
		end
		
		local _delay

		if not workspace:FindFirstChild('Rig') then
			loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
			workspace:WaitForChild('Rig')
		end

		local Reanim_Rig=workspace.Rig
		local t=Reanim_Rig.Torso
		rs=t["Right Shoulder"]
		ls=t["Left Shoulder"]
		rh=t["Right Hip"]
		lh=t["Left Hip"]
		n=t["Neck"]
		rj=Reanim_Rig.HumanoidRootPart["RootJoint"]
		rsc0=rs.C0
		lsc0=ls.C0
		rhc0=rh.C0
		lhc0=lh.C0
		rjc0=rj.C0
		nc0=n.C0
		count2 = 100
		maxcount2=100
		local grgrg = game["Run Service"].Heartbeat:Connect(function()
			if Reanim_Rig == nil then grgrg:Disconnect() end
			count2 = count2 + 1
			if count2<=maxcount2 then
				rs.Transform=rs.Transform:Lerp(rsc0,count2/maxcount2)
				ls.Transform=ls.Transform:Lerp(lsc0,count2/maxcount2)
				rh.Transform=rh.Transform:Lerp(rhc0,count2/maxcount2)
				lh.Transform=lh.Transform:Lerp(lhc0,count2/maxcount2)
				n.Transform=n.Transform:Lerp(nc0,count2/maxcount2)
				rj.Transform=rj.Transform:Lerp(rjc0,count2/maxcount2)
			end
		end)
		animid=game:GetObjects(animid)[1]
		local anim = {}
		local function kftotbl(kf)
			local tbl3 = {}
			for i,v in pairs(kf:GetDescendants()) do
				if v:IsA("Pose") then
					tbl3[string.sub(v.Name,1,1)..string.sub(v.Name,#v.Name,#v.Name)] = v.CFrame
				end
			end
			return(tbl3)
		end
		for i,v in pairs(animid:GetChildren()) do
			if v:IsA("Keyframe") then
				anim[v.Time]=kftotbl(v)
			end
		end

		local function getnext(tbl,number)
			local c=100
			local rtrnv=0
			for i,v in pairs(tbl) do
				if i>number and i-number<c then
					c=i-number
					rtrnv=i
				end
			end
			return(rtrnv)
		end
		local count = 0
		if Reanim_Rig:WaitForChild("Humanoid", 5):FindFirstChild('Animator') then
			local hhhh=workspace.Rig.Humanoid.Animator
			hhhh:Destroy()
		end
		for _,v in pairs(workspace.Rig.Humanoid:GetPlayingAnimationTracks()) do
			v:Stop()
		end
		while true do
			if Reanim_Rig == nil then break end
			for i,oasjdadlasdkadkldjkl in pairs(anim) do
				local asdf=getnext(anim,count)
				local v=anim[asdf]
				if v["Lg"] then
					lhc0 = v["Lg"]
				end
				if v["Rg"] then
					rhc0 = v["Rg"]
				end
				if v["Lm"] then
					lsc0 = v["Lm"]
				end
				if v["Rm"] then
					rsc0 = v["Rm"]
				end
				if v["To"] then
					rjc0 = v["To"]
				end
				if v["Hd"] then
					nc0 = v["Hd"]
				end
				count2=0
				maxcount2=asdf - count
				count=asdf
				wait(asdf-count)
				count2=maxcount2
				if v["Lg"] then
					Reanim_Rig.Torso["Left Hip"].Transform = v["Lg"]
				end
				if v["Rg"] then
					Reanim_Rig.Torso["Right Hip"].Transform = v["Rg"]
				end
				if v["Lm"] then
					Reanim_Rig.Torso["Left Shoulder"].Transform = v["Lm"]
				end
				if v["Rm"] then
					Reanim_Rig.Torso["Right Shoulder"].Transform = v["Rm"]
				end
				if v["To"] then
					Reanim_Rig.HumanoidRootPart["RootJoint"].Transform = v["To"]
				end
				if v["Hd"] then
					Reanim_Rig.Torso["Neck"].Transform = v["Hd"]
				end
			end
		end
	end
end)


local L_1_ = game:GetService("UserInputService")
function drag(L_2_arg1)
	dragToggle = nil
	local dragSpeed = 0.25
	dragInput = nil
	dragStart = nil
	local dragPos = nil
	function updateInput(L_3_arg1)
		local Delta = L_3_arg1.Position - dragStart
		local Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
		game:GetService("TweenService"):Create(L_2_arg1, TweenInfo.new(dragSpeed), {
			Position = Position
		}):Play()
	end
	L_2_arg1.InputBegan:Connect(function(L_4_arg1)
		if (L_4_arg1.UserInputType == Enum.UserInputType.MouseButton1 or L_4_arg1.UserInputType == Enum.UserInputType.Touch) and L_1_:GetFocusedTextBox() == nil then
			dragToggle = true
			dragStart = L_4_arg1.Position
			startPos = L_2_arg1.Position
			L_4_arg1.Changed:Connect(function()
				if L_4_arg1.UserInputState == Enum.UserInputState.End then
					dragToggle = false
				end
			end)
		end
	end)
	L_2_arg1.InputChanged:Connect(function(L_5_arg1)
		if L_5_arg1.UserInputType == Enum.UserInputType.MouseMovement or L_5_arg1.UserInputType == Enum.UserInputType.Touch then
			dragInput = L_5_arg1
		end
	end)
	game:GetService("UserInputService").InputChanged:Connect(function(L_6_arg1)
		if L_6_arg1 == dragInput and dragToggle then
			updateInput(L_6_arg1)
		end
	end)
end
drag(Frame)