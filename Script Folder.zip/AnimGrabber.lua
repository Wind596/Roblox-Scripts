local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local GPA = Instance.new("TextButton")
local UICorner = Instance.new("UICorner")
local UICorner_2 = Instance.new("UICorner")
local TextLabel = Instance.new("TextLabel")
local AID = Instance.new("TextButton")
local UICorner_3 = Instance.new("UICorner")

ScreenGui.Parent = game:GetService("CoreGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.424013436, 0, 0.438106805, 0)
Frame.Size = UDim2.new(0, 180, 0, 102)

GPA.Name = "GPA"
GPA.Parent = Frame
GPA.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
GPA.BorderSizePixel = 0
GPA.Position = UDim2.new(0.0388888903, 0, 0.702911496, 0)
GPA.Size = UDim2.new(0, 165, 0, 21)
GPA.Font = Enum.Font.Code
GPA.Text = "Get Playing Animations"
GPA.TextColor3 = Color3.fromRGB(255, 255, 255)
GPA.TextSize = 14.000
GPA.TextWrapped = true

UICorner.CornerRadius = UDim.new(0, 5)
UICorner.Parent = GPA

UICorner_2.CornerRadius = UDim.new(0, 5)
UICorner_2.Parent = Frame

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0, 0, 0.0588235296, 0)
TextLabel.Size = UDim2.new(0, 180, 0, 14)
TextLabel.Font = Enum.Font.Code
TextLabel.Text = "Result :"
TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.TextSize = 14.000

AID.Name = "AID"
AID.Parent = Frame
AID.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
AID.BorderSizePixel = 0
AID.Position = UDim2.new(0.0388888903, 0, 0.389185995, 0)
AID.Size = UDim2.new(0, 165, 0, 21)
AID.Font = Enum.Font.Code
AID.Text = "nil"
AID.TextColor3 = Color3.fromRGB(255, 255, 255)
AID.TextSize = 14.000
AID.TextWrapped = true

UICorner_3.CornerRadius = UDim.new(0, 5)
UICorner_3.Parent = AID

-- Scripts:

local function URHPC_fake_script() -- GPA.LocalScript 
	local script = Instance.new('LocalScript', GPA)

	local p = game:GetService("Players").LocalPlayer
	script.Parent.MouseButton1Click:Connect(function()
		if script.Parent.Text ~= "nil" then
			if p.Character ~= nil and p.Character:FindFirstChildOfClass("Humanoid") then 
				for gay,c in pairs(p.Character:FindFirstChildOfClass("Humanoid"):GetPlayingAnimationTracks()) do
					script.Parent.Parent.AID.Text = c.Animation.AnimationId
				end
			else
				script.Parent.Parent.AID.Text = "Unknown Character"
			end
		end
	end)
end
coroutine.wrap(URHPC_fake_script)()
local function HNLDRF_fake_script()
	local script = Instance.new('LocalScript', AID)
	script.Parent.MouseButton1Click:Connect(function()
		if script.Parent.Text ~= "nil" then
			local setc = syn.write_clipboard or setclipboard or toclipboard or set_clipboard or (Clipboard and Clipboard.set)
			local origtext = script.Parent.Text
			setc(script.Parent.Text)
			script.Parent.Text = "Copied To Clipboard"
			wait(1.5)
			script.Parent.Text = origtext
		end
	end)
end
coroutine.wrap(HNLDRF_fake_script)()
local function BNSVB_fake_script() -- Frame.Drag 
	local script = Instance.new('LocalScript', Frame)

	local L_1_ = game:GetService("UserInputService")
	function drag(L_2_arg1)
		dragToggle = nil
		local dragSpeed = 0.23
		dragInput = nil
		dragStart = nil
		local dragPos = nil
		function updateInput(L_3_arg1)
			local Delta = L_3_arg1.Position - dragStart
			local Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
			game:GetService("TweenService"):Create(L_2_arg1, TweenInfo.new(0.25), {
				Position = Position
			}):Play()
		end
		L_2_arg1.InputBegan:Connect(function(L_4_arg1)
			if (L_4_arg1.UserInputType == Enum.UserInputType.MouseButton1 or L_4_arg1.UserInputType == Enum.UserInputType.Touch) and L_1_:GetFocusedTextBox() == nil then
				dragToggle = true
				dragStart = L_4_arg1.Position
				startPos = L_2_arg1.Position
				L_4_arg1.Changed:Connect(function()
					if L_4_arg1.UserInputState == Enum.UserInputState.End then
						dragToggle = false
					end
				end)
			end
		end)
		L_2_arg1.InputChanged:Connect(function(L_5_arg1)
			if L_5_arg1.UserInputType == Enum.UserInputType.MouseMovement or L_5_arg1.UserInputType == Enum.UserInputType.Touch then
				dragInput = L_5_arg1
			end
		end)
		game:GetService("UserInputService").InputChanged:Connect(function(L_6_arg1)
			if L_6_arg1 == dragInput and dragToggle then
				updateInput(L_6_arg1)
			end
		end)
	end
	drag(script.Parent)
end
coroutine.wrap(BNSVB_fake_script)()
