if getgenv().BlackoutLoaded == true then print("Error: Blackout is already running or is set to true in global envirorment") return end
getgenv().BlackoutLoaded = true
if not game:IsLoaded() then
	game.Loaded:Wait()
end
local UserInputService = game:GetService("UserInputService")
local infJump
local net = false
local setsimulation = setsimulationradius or set_simulation_radius
local p = game:GetService("Players").LocalPlayer
local lighted = false
local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local UICorner = Instance.new("UICorner")
local cmdbox = Instance.new("TextBox")
local UICorner_2 = Instance.new("UICorner")
local ver = 11.2
local Noclip
local mouse = p:GetMouse()
local gravReset
local CTS
local CGP
local sethidden = sethiddenproperty or set_hidden_property or set_hidden_prop
local gethidden = gethiddenproperty or get_hidden_property or get_hidden_prop
local lastoof
local xd = Instance.new("ScreenGui")
local SP
local banging = false
local banger
local banga
local bang
local flying = false
local flyspeed = 25
local defFlyspeed = 25

if syn and syn.protect_gui then
	syn.protect_gui(ScreenGui)
end

function randomstring()
	local length = math.random(10,20)
	local array = {}
	for i = 1,length do
		array[i] = string.char(math.random(32,126))
	end
	return table.concat(array)
end

function Joint(P1,P2, POS, ROT)
	local AlignP = Instance.new('AlignPosition', P2);
	AlignP.ApplyAtCenterOfMass = true;
	AlignP.MaxForce = 67752;
	AlignP.MaxVelocity = math.huge/9e110;
	AlignP.ReactionForceEnabled = false;
	AlignP.Responsiveness = 200;
	AlignP.RigidityEnabled = true;
	local AlignO = Instance.new('AlignOrientation', P2);
	AlignO.MaxAngularVelocity = math.huge/9e110;
	AlignO.MaxTorque = 67752;
	AlignO.PrimaryAxisOnly = false;
	AlignO.ReactionTorqueEnabled = false;
	AlignO.Responsiveness = 200;
	AlignO.RigidityEnabled = true;
	local AttA=Instance.new('Attachment',P2);
	local AttB=Instance.new('Attachment',P1);
	AlignP.Attachment1 = AttA;
	AlignP.Attachment0 = AttB;
	AlignO.Attachment1 = AttA;
	AlignO.Attachment0 = AttB;
	AttA.Name = "Align" .. P1.Name
	AttA.Rotation = ROT
	AttA.Position = POS
	AttB.Name = "Align" .. P1.Name
end

function r15(plr)
	if plr.Character:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R15 then
		return true
	end
end

function r6(plr)
	if plr.Character:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
		return true
	end
end

function claim(plr)
	local char = p.Character
	local tchar = plr.Character
	local hum = p.Character:FindFirstChildOfClass("Humanoid")
	local hrp = findroot(p.Character)
	local hrp2 = findroot(plr.Character)
	hum.Name = "1"
	local newHum = hum:Clone()
	newHum.Parent = char
	newHum.Name = "Humanoid"
	wait()
	hum:Destroy()
	workspace.CurrentCamera.CameraSubject = char
	newHum.DisplayDistanceType = "None"
	local tool = p:FindFirstChildOfClass("Backpack"):FindFirstChildOfClass("Tool") or p.Character:FindFirstChildOfClass("Tool")
	tool.Parent = char
	hrp.CFrame = hrp2.CFrame * CFrame.new(0, 0, 0) * CFrame.new(math.random(-100, 100)/200,math.random(-100, 100)/200,math.random(-100, 100)/200)
	local n = 0
	repeat
		wait(.1)
		n = n + 1
		hrp.CFrame = hrp2.CFrame
	until (tool.Parent ~= char or not hrp or not hrp2 or not hrp.Parent or not hrp2.Parent or n > 250) and n > 2
end

function isNumber(str)
	if tonumber(str) ~= nil or str == 'inf' then
		return true
	end
end

function findplayer(thing)
	if thing == "me" then
		return p
	else
		for i,c in pairs(game:GetService("Players"):GetPlayers()) do
			if string.match(string.lower(c.Name),string.lower('^' .. thing)) then
				return c
			end
		end
	end
end

function notify(String, col)
	if col == "Red" then
		cmdbox.PlaceholderColor3 = Color3.fromRGB(255, 0, 0)
	elseif col == "Green" then
		cmdbox.PlaceholderColor3 = Color3.fromRGB(0, 255, 0)
	end
	cmdbox.PlaceholderText = String
	wait(2)
	game:GetService("TweenService"):Create(cmdbox, TweenInfo.new(0.25), {['PlaceholderColor3'] = Color3.fromRGB(178, 178, 178)}):Play()
	wait(0.5)
	cmdbox.PlaceholderText = "BLACKOUT V"..ver
end

function refresh(player)
	local char = player.Character
	if char:FindFirstChildOfClass("Humanoid") then char:FindFirstChildOfClass("Humanoid"):ChangeState(15) end
	char:ClearAllChildren()
	local newChar = Instance.new("Model",workspace)
	p.Character = newChar
	wait()
	p.Character = char
	newChar:Destroy()
end

function findroot(char)
	local rootPart = char:FindFirstChild('HumanoidRootPart') or char:FindFirstChild('Torso') or char:FindFirstChild('UpperTorso')
	return rootPart
end

function speak(String)
	local A_1 = String
	local A_2 = "All"
	local Event = game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest
	Event:FireServer(A_1, A_2)
end

UserInputService.InputBegan:Connect(function(key)
	if key.keyCode == Enum.KeyCode.PageUp then
		spawn(function()
			pcall(function()
				if infJump then infJump:Disconnect() end
				infJump = game:GetService("UserInputService").JumpRequest:Connect(function(Jump)
					p.Character:FindFirstChildOfClass'Humanoid':ChangeState("Jumping")
				end)
				notify('Enabled Infinite Jump', 'Green')
			end)
		end)
	elseif key.KeyCode == Enum.KeyCode.PageDown then
		spawn(function()
			pcall(function()
				if infJump then infJump:Disconnect() end
				notify('Disabled Infinite Jump', 'Green')
			end)
		end)
	elseif key.KeyCode == Enum.KeyCode.Delete then
		spawn(function()
			pcall(function()
				if game:GetService('Players').LocalPlayer:GetMouse().Target == nil then return else game:GetService'Players'.LocalPlayer:GetMouse().Target.Name = tostring(math.random()) game:GetService'Players'.LocalPlayer:GetMouse().Target:Destroy() end
			end)
		end)
	elseif key.KeyCode == Enum.KeyCode.End then
		spawn(function()
			pcall(function()
				if game:GetService'Players'.LocalPlayer:GetMouse().Target == nil then return else p.Character.Humanoid.Sit = false wait() game:GetService'Players'.LocalPlayer.Character.HumanoidRootPart.CFrame = game:GetService'Players'.LocalPlayer:GetMouse().Hit + Vector3.new(0,7,0) end
			end)
		end)
	elseif key.KeyCode == Enum.KeyCode.Home then
		if p.PlayerGui.Chat.Frame.ChatBarParentFrame.Frame.BoxFrame.Frame.ChatBar:IsFocused() or cmdbox:IsFocused() then return end
		cmdbox:CaptureFocus()
		wait()
		cmdbox.Text = ""
	end
end)

p.CharacterAdded:Connect(function()
	p.Character:WaitForChild("Humanoid")
	wait(0.5)
	p.Character:FindFirstChildOfClass('Humanoid').Died:Connect(function()
		if findroot(p.Character) then
			lastoof = findroot(p.Character).CFrame
		end
	end)
end)

ScreenGui.Parent = game:GetService("CoreGui").RobloxGui
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
Frame.BackgroundTransparency = 0.250
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.0136518767, 0, 0.885922313, 0)
Frame.Size = UDim2.new(0, 368, 0, 44)

UICorner.CornerRadius = UDim.new(0, 6)
UICorner.Parent = Frame

cmdbox.Parent = Frame
cmdbox.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
cmdbox.BorderSizePixel = 0
cmdbox.Position = UDim2.new(0.0298913047, 0, 0.134325325, 0)
cmdbox.Size = UDim2.new(0, 346, 0, 31)
cmdbox.Font = Enum.Font.Code
cmdbox.PlaceholderText = ""
cmdbox.Text = ""
cmdbox.TextColor3 = Color3.fromRGB(255, 128, 0)
cmdbox.TextSize = 14.000
cmdbox.TextWrapped = true
cmdbox.TextColor3 = Color3.fromRGB(178, 178, 178)

UICorner_2.CornerRadius = UDim.new(0, 6)
UICorner_2.Parent = cmdbox

cmdbox.Focused:Connect(function()
	game:GetService("TweenService"):Create(cmdbox, TweenInfo.new(1), {['TextColor3'] = Color3.fromRGB(255, 128, 0)}):Play()
end)

cmdbox.FocusLost:Connect(function()
	game:GetService("TweenService"):Create(cmdbox, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(178, 178, 178)}):Play()
	wait(0.30)
	local nc = string.lower(cmdbox.Text)
	local c = nc:split(' ')
	local command = c[1]
	local arg = c[2]
	local arg2 = c[3]
	cmdbox.Text = ""
	if command == "goto" then
		if arg then
			local Target = findplayer(arg)
			if Target.Character ~= nil then
				if game:GetService('Players').LocalPlayer.Character:FindFirstChild("Humanoid") then
					game:GetService('Players').LocalPlayer.Character:FindFirstChildOfClass('Humanoid').Sit = false
				end
				wait(0.1)
				findroot(game:GetService('Players').LocalPlayer.Character).CFrame = findroot(Target.Character).CFrame + Vector3.new(3,1,0)
			end
		end
	elseif command == "net" then
		if net == false then
			if setsimulation then
				net = true
				spawn(function()
					game["Run Service"].RenderStepped:Connect(function()
						p.ReplicationFocus = workspace
						settings().Physics.AllowSleep = false
						settings().Physics.PhysicsEnvironmentalThrottle = Enum.EnviromentalPhysicsThrottle.Disabled
						setsimulation(math.huge,math.huge,math.huge,math.huge)
						sethidden(p, "SimulationRadius",math.huge,math.huge,math.huge,math.huge)
						sethidden(p, "MaximumSimulationRadius",math.huge)
						game:GetService("RunService").Heartbeat:wait()
					end) 
				end)
				notify("Net Enabled", "Green")
			else
				notify("Unsupported Exploit", "Red")
			end
		else
			notify("You already have a active net", "Red")
		end
	elseif command == "light" then
		if lighted == false then 
			local light = Instance.new("PointLight",findroot(p.Character))
			light.Range = 30
			lighted = true
		else
			notify("You already have a light", "Red")
		end
	elseif command == "unlight" then
		if lighted then
			findroot(game:GetService('Players').LocalPlayer.Character).PointLight:Destroy()
			lighted = false
		else
			notify("You don't have a current light", "Red")
		end
	elseif command == "split" then
		if r15(p) then
			p.Character.UpperTorso.Waist:Destroy()
		else
			notify("This requires R15", "Red")
		end
	elseif command == "grav" or command == "gravity" then
		if arg then
			if isNumber(arg) then
				workspace.Gravity = arg
			else
				notify("Unknown Value", "Red")
			end
		else
			workspace.Gravity = 196.2
		end
	elseif command == "god" or command == "godmode" then
		if p.Character ~= nil then
			local p = game:GetService("Players").LocalPlayer
			local c = p.Character
			local temp = Instance.new("Model", workspace)
			Instance.new("Humanoid",temp)
			temp.Name = "Fred"
			p.Character = temp
			if c:FindFirstChildOfClass("Humanoid"):FindFirstChild("Animator") then
				c:FindFirstChildOfClass("Humanoid").Animator.Parent = temp.Humanoid
			end
			wait()
			local rig
			if c:FindFirstChildOfClass("Humanoid").RigType == Enum.HumanoidRigType.R15 then
				rig = "R15"
			else
				rig = "R6"
			end
			local Reset = Instance.new("BindableEvent")
			Reset.Event:Connect(function()
				game:GetService("StarterGui"):SetCore("ResetButtonCallback", true)
				Reset:Destroy()
				local m = Instance.new("Model", workspace)
				m.Name = "UwU"
				local h = Instance.new("Humanoid", m)
				p.Character:Destroy()
				wait()
				p.Character = m
				wait()
				h.Health = 0
				p.ChildAdded:Wait()
				m:Destroy()
			end)
			game:GetService("StarterGui"):SetCore("ResetButtonCallback", Reset)
			c.Humanoid:Destroy()
			local humanoid = Instance.new("Humanoid", c)
			humanoid.RequiresNeck = false
			humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			humanoid.HealthDisplayDistance = Enum.HumanoidHealthDisplayType.AlwaysOff
			if rig == "R15" then
				humanoid.RigType = Enum.HumanoidRigType.R15
				humanoid.HipHeight = 2.19
			else
				humanoid.RigType = Enum.HumanoidRigType.R6
			end
			p.Character = c
			workspace.CurrentCamera.CameraSubject = c
			if c:FindFirstChild("Animate") then
				c.Animate.Disabled = true
				c.Animate.Disabled = false
			end
			wait()
			temp:Destroy()
			notify("Godmode Enabled", "Green")
		else
			notify("Failed to find character", "Red")
		end
	elseif command == "speed" or command == "ws" or command == "walkspeed" then
		if arg then
			if isNumber(arg) then
				p.Character:FindFirstChildOfClass('Humanoid').WalkSpeed = arg
				notify("Set speed to" .. arg, "Green")
			else
				notify("Unknown Value", "Red")
			end
		else
			p.Character:FindFirstChildOfClass('Humanoid').WalkSpeed = 16
		end
	elseif command == "jp" or command == "jump" or command == "jumppower" then
		if arg then
			if isNumber(arg) then
				p.Character:FindFirstChildOfClass('Humanoid').JumpPower = arg
				notify("Set JumpPower To " .. arg, "Green")
			else
				notify("Unknown Value", "Red")
			end
		else
			p.Character:FindFirstChildOfClass('Humanoid').JumpPower = 50
		end
	elseif command == "roast" then
		local roastPick = {
			"Anne Frank hid better then you",
			"Go to bed",
			"You need a shower",
			"You look like a barbie doll which i gave a makeover with my markers",
			"Your momma back built like a skate ramp I can do an ollie off her",
			"You look like the 1% of germs that hand-soap doesn't kill",
			"Boy u literally be smelling like tv oil",
			"No wonder your parents hate you",
			"You haven't had any neurological brain development in the last decade",
			"I will build a sandcastle out of your dead nans ashes",
			"Your brain has the capacity of a dried sea sponge",
			"You make me cringe, I literally want to quit this game because of you",
			"Your outfit is horrendous",
			"Your name is horrendous",
			"Your IQ is so low that even scientists cant zoom in on it",
			"You are a femmie",
			"You are fat",
			"You stink of your nans cremation",
			"How many people does it take to screw in a lightbulb? 20 of your kind",
			"I can smell you through the screen",
			"Candy shop got robbed, didn't know you did it",
			"You are poor",
			"Your brain is the size of an average ants",
			"Everything you've worked for, your whole life is embarassing",
			"Go back to school",
			"Are you dumb or just young",
			"You make me feel e-sick",
			"I very much dislike you",
			"Settle along you peasent",
			"You are worth nothing",
			"I hope you suffer",
			"Your words, they make no sense",
			"Please leave the server you cretin",
			"You make me sick",
			"Huh? Didn't know infants could play roblox",
			"I bet you live in a poverty stricken country",
			"You belong in the special ed class",
			"Is it just me or does someone smell, nvm thats just you",
			"Is it just me or is someone dumb, nvm thats just you",
			"Is it just me or is someone fat, nvm thats just you",
			"Everytime you sit down they add another map to the country",
			"Imagine falling of both sides of the bed"
		}
		local value = math.random(1,#roastPick)
		local picked_value = roastPick[value]
		speak(picked_value)
		notify("lmao", "Green")
	elseif command == "bettercam" or command == "nccam" then
		p.CameraMinZoomDistance = math.huge - math.huge
		p.CameraMaxZoomDistance = math.huge - math.huge
	elseif command == "reset" then
		local old_rs_time = game:GetService("Players").RespawnTime
		game:GetService("Players").RespawnTime = 0
		p.Character.Torso.Neck:Destroy()
		p.CharacterAdded:Wait()
		game:GetService("Players").RespawnTime = old_rs_time
	elseif command == "hide" then
		p.Character.Parent = nil
	elseif command == "unhide" then
		p.Character.Parent = workspace
	elseif command == "noname" then
		for i,v in pairs(p.Character:GetDescendants())do
			if v:IsA("BillboardGui") or v:IsA("SurfaceGui") then
				v:Destroy()
			end
		end
	elseif command == "noface" then
		p.Character.Head.face:Destroy()
	elseif command == "rj" or command == "rejoin" then
		if #game:GetService("Players"):GetPlayers() <= 1 then
			p:Kick("Teleporting...")
			wait()
			game:GetService('TeleportService'):Teleport(game.PlaceId, p)
		else
			game:GetService('TeleportService'):TeleportToPlaceInstance(game.PlaceId, game.JobId, p)
		end
	elseif command == "fcd" then
		if fireclickdetector then
			for i,v in pairs(workspace:GetDescendants()) do
				if v:IsA("ClickDetector") then
					fireclickdetector(v)
				end
			end
			notify("Fired Click Detectors", "Green")
		else
			notify("Unsupported Exploit", "Red")
		end
	elseif command == "rspy" then
		loadstring(game:HttpGet("https://raw.githubusercontent.com/Nootchtai/FrostHook_Spy/master/Spy.lua"))()
	elseif command == "exit" then
		p:Kick()
		game:Shutdown()
	elseif command == "fti" then
		if firetouchinterest then
			for i,v in pairs(workspace:GetDescendants()) do
				if v:IsA("TouchTransmitter") or v:IsA('TouchInterest') then
					firetouchinterest(findroot(p.Character), v.Parent, 0)
				end
			end
			notify("Fired Touch Interests", "Green")
		else
			notify("Unsupported Exploit", "Red")
		end
	elseif command == "noclip" or command == "nc" then
		local function NoclipLoop()
			if p.Character ~= nil then
				for _, child in pairs(p.Character:GetDescendants()) do
					if child:IsA("BasePart") and child.CanCollide == true then
						child.CanCollide = false
					end
				end
			end
		end
		Noclip = game:GetService('RunService').Stepped:connect(NoclipLoop)
	elseif command == "unnoclip" or command == "clip" then
		if Noclip then Noclip:Disconnect() end
	elseif command == "swim" then
		workspace.Gravity = 0
		local function swimDied()
			workspace.Gravity = 198.2
		end
		gravReset = p.Character:FindFirstChildOfClass('Humanoid').Died:Connect(swimDied)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Climbing,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.FallingDown,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Flying,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Freefall,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.GettingUp,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Jumping,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Landed,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Physics,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.PlatformStanding,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Ragdoll,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Running,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.RunningNoPhysics,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.StrafingNoPhysics,false)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Swimming,false)
		p.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Swimming)
	elseif command == "unswim" then
		workspace.Gravity = 198.2
		if gravReset then
			gravReset:Disconnect()
		end
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Climbing,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.FallingDown,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Flying,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Freefall,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.GettingUp,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Jumping,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Landed,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Physics,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.PlatformStanding,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Ragdoll,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Running,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.RunningNoPhysics,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.StrafingNoPhysics,true)
		p.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Swimming,true)
		p.Character.Humanoid:ChangeState(Enum.HumanoidStateType.RunningNoPhysics)
	elseif command == "reach" then
		for i,v in pairs(p.Character:GetDescendants()) do
			if v:IsA("Tool") then
				if arg then
					CTS = v.Handle.Size
					CGP = v.GripPos
					local a = Instance.new("SelectionBox",v.Handle)
					a.Name = "SelectionBoxCreated"
					a.Adornee = v.Handle
					a.Color3 = Color3.new(255, 0, 0)
					v.Handle.Massless = true
					v.Handle.Size = Vector3.new(0.5,0.5,arg)
					v.GripPos = Vector3.new(0,0,0)
					p.Character.Humanoid:UnequipTools()
					wait(0.5)
					p.Character.Humanoid:EquipTool(v)
				else
					CTS = v.Handle.Size
					CGP = v.GripPos
					local a = Instance.new("SelectionBox",v.Handle)
					a.Name = "SelectionBoxCreated"
					a.Adornee = v.Handle
					a.Color3 = Color3.new(255, 0, 0)
					v.Handle.Massless = true
					v.Handle.Size = Vector3.new(0.5,0.5,60)
					v.GripPos = Vector3.new(0,0,0)
					p.Character.Humanoid:UnequipTools()
					wait(0.5)
					p.Character.Humanoid:EquipTool(v)
				end
			end
		end
	elseif command == "unreach" then
		for i,v in pairs(p.Character:GetDescendants()) do
			if v:IsA("Tool") then
				v.Handle.Size = CTS
				v.GripPos = CGP
				v.Handle.SelectionBoxCreated:Destroy()
			end
		end
	elseif command == "dex" or command == "darkdex" or command == "explorer" then
		loadstring(game:HttpGetAsync("https://pastebin.com/raw/fPP8bZ8Z"))()
	elseif command == "tpua" or command == "bringua" then
		if sethidden then
			if arg then
				local player = findplayer(arg)
				for i,v in pairs(workspace:GetDescendants()) do
					if v:IsA("Part") or v:IsA("BasePart") or v:IsA("UnionOperation") and v:IsDescendantOf(p.Character) == false and v.Anchored == false then
						for i,c in pairs(v:GetChildren()) do
							if c:IsA("BodyPosition") or c:IsA("BodyGyro") then
								c:Destroy()
							end
						end
						v.CFrame = findroot(player.Character).CFrame
					end
					game:GetService("RunService").Heartbeat:Wait()
				end
			else
				for i,v in pairs(workspace:GetDescendants()) do
					if v:IsA("Part") or v:IsA("BasePart") or v:IsA("UnionOperation") and v:IsDescendantOf(p.Character) == false then
						for i,c in pairs(v:GetChildren()) do
							if c:IsA("BodyPosition") or c:IsA("BodyGyro") then
								c:Destroy()
							end
						end
						v.CFrame = findroot(p.Character).CFrame
					end
				end
			end
			wait()
			for i,c in pairs(p.Character:GetDescendants()) do
				if c:IsA("BodyPosition") or c:IsA("BodyGyro") then
					c:Destroy()
				end
			end
		else
			notify("Unsupported Exploit", "Red")
		end
	elseif command == "thawua" then
		if sethidden then
			for i,c in pairs(workspace:GetDescendants()) do
				if c:IsA("BodyPosition") or c:IsA("BodyGyro") then
					c:Destroy()
				end
			end
		else
			notify("Unsupported Exploit", "Red")
		end
	elseif command == "antiafk" then
		local GC = getconnections or get_signal_cons
		if GC then
			for i,v in pairs(GC(p.Idled)) do
				if v["Disable"] then
					v["Disable"](v)
				elseif v["Disconnect"] then
					v["Disconnect"](v)
				end
			end
			notify('Anti Afk Enabled')
		else
			notify("Unsupported Exploit", "Red")
		end
	elseif command == "lag" or command == "backtrack" then
		if arg then
			if tonumber(arg) then
				settings():GetService("NetworkSettings").IncommingReplicationLag = arg
			end
		end
	elseif command == "strengthen" then
		for _, child in pairs(p.Character:GetDescendants()) do
			if child.ClassName == "Part" then
				if arg then
					child.CustomPhysicalProperties = PhysicalProperties.new(arg, 0.3, 0.5)
				else
					child.CustomPhysicalProperties = PhysicalProperties.new(100, 0.3, 0.5)
				end
			end
		end
	elseif command == "weaken" then
		for _, child in pairs(p.Character:GetDescendants()) do
			if child.ClassName == "Part" then
				if arg then
					child.CustomPhysicalProperties = PhysicalProperties.new(-arg, 0.3, 0.5)
				else
					child.CustomPhysicalProperties = PhysicalProperties.new(0, 0.3, 0.5)
				end
			end
		end
	elseif command == "unweaken" or command == "unstrengthen" then
		for _, child in pairs(p.Character:GetDescendants()) do
			if child.ClassName == "Part" then
				child.CustomPhysicalProperties = PhysicalProperties.new(0.7, 0.3, 0.5)
			end
		end
	elseif command == "diedtp" then
		if lastoof ~= nil then
			if p.Character:FindFirstChild("Humanoid") then
				p.Character:FindFirstChildOfClass('Humanoid').Sit = false
			end
			wait()
			findroot(p.Character).CFrame = lastoof
		else
			notify("No recorded death", "Red")
		end
	elseif command == "drophats" then
		for i,v in pairs(p.Character:GetDescendants()) do
			if v:IsA("Accessory") then
				v.Parent = workspace
			end
		end
	elseif command == "blockhats" then
		for i,v in pairs(p.Character:GetDescendants()) do
			if v:IsA("Accessory") then
				if v.Handle:FindFirstChildOfClass("SpecialMesh") then
					v.Handle:FindFirstChildOfClass("SpecialMesh"):Destroy()
				end
			end
		end
	elseif command == "delhats" or command == "deletehats" then
		for i,v in pairs(p.Character:GetDescendants()) do
			if v:IsA("Accessory") then
				v.Handle.AccessoryWeld:Destroy()
			end
		end
	elseif command == "freezeua" then
		if sethidden then
			for i,v in pairs(workspace:GetDescendants()) do
				if v:IsA("Part") or v:IsA("BasePart") or v:IsA("UnionOperation") then
					for i,c in pairs(v:GetChildren()) do
						if c:IsA("BodyPosition") or c:IsA("BodyGyro") then
							c:Destroy()
						end
					end
					local bodypos = Instance.new("BodyPosition")
					bodypos.Parent = v
					bodypos.Position = v.Position
					bodypos.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
					local bodygyro = Instance.new("BodyGyro")
					bodygyro.Parent = v
					bodygyro.CFrame = v.CFrame
					bodygyro.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
				end
			end
		else
			notify("Unsupported Exploit", "Red")
		end
	elseif command == "sp" or command == "saveposition" then
		if p.Character ~= nil then
			SP = findroot(p.Character).CFrame
			notify("Saved Position", "Green")
		else
			notify("Failed to find character")
		end
	elseif command == "lp" or command == "loadposition" then
		if SP ~= nil then
			if p.Character:FindFirstChild("Humanoid") then
				p.Character:FindFirstChildOfClass('Humanoid').Sit = false
			end
			findroot(p.Character).CFrame = SP
			notify("Loaded Position", "Green")
		else
			notify("No recorded position", "Red")
		end
	elseif command == "sound" or command == "music" then
		if arg then
			if game:GetService("SoundService"):FindFirstChild("Nap_Was_Here") then
				game:GetService("SoundService").Nap_Was_Here:Destroy()
			end
			local e = Instance.new("Sound", game:GetService("SoundService"))
			e.Name = "Nap_Was_Here"
			if c[3] then
				if isNumber(c[3]) then
					e.Volume = c[3]
				end
			else
				e.Volume = 10
			end
			if isNumber(arg) then
				e.SoundId = "rbxassetid://" .. arg
			end
			e.Looped = true
			e:Play()
		else
			if game:GetService("SoundService"):FindFirstChild("Nap_Was_Here") then
				game:GetService("SoundService").Nap_Was_Here:Destroy()
			end
			local e = Instance.new("Sound", game:GetService("SoundService"))
			e.Name = "Nap_Was_Here"
			e.Volume = 10
			e.SoundId = "rbxassetid://5160230627"
			e.Looped = true
			e:Play()
		end
	elseif command == "re" then
		if p.Character ~= nil then
			local oldp = p.Character.HumanoidRootPart.CFrame
			refresh(p)
			p.CharacterAdded:Wait()
			wait(0.2)
			p.Character.HumanoidRootPart.CFrame = oldp
		end
	elseif command == "bang" then
		if arg and p.Character ~= nil then
			banging = true
			tar = findplayer(arg)
			banga = Instance.new("Animation")
			banga.AnimationId = "rbxassetid://148840371"
			bang = p.Character.Humanoid:LoadAnimation(banga)
			bang:Play(.1, 1, 1)
			banger = game:GetService('RunService').Stepped:Connect(function()
				pcall(function()
					findroot(p.Character).CFrame = findroot(tar.Character).CFrame
				end)
			end)
		else
			banga = Instance.new("Animation")
			banga.AnimationId = "rbxassetid://148840371"
			bang = p.Character.Humanoid:LoadAnimation(banga)
			bang:Play(.1, 1, 1)
		end
	elseif command == "fling" then
		if arg and findplayer(arg) ~= nil and p.Character ~= nil then
			notify("Flinging idiot...", "Green")
			local oldpos = p.Character.HumanoidRootPart.CFrame
			local bambam = Instance.new("BodyAngularVelocity")
			bambam.Parent = findroot(p.Character)
			bambam.AngularVelocity = Vector3.new(0,311111,0)
			bambam.MaxTorque = Vector3.new(0,311111,0)
			bambam.P = math.huge
			local Target = findplayer(arg)
			findroot(game:GetService('Players').LocalPlayer.Character).CFrame = findroot(Target.Character).CFrame
			wait(0.3)
			bambam:Destroy()
			p.Character.HumanoidRootPart.CFrame = oldpos
			notify("Idiot flung", "Green")
		else
			local bambam = Instance.new("BodyAngularVelocity")
			bambam.Parent = findroot(p.Character)
			bambam.AngularVelocity = Vector3.new(0,311111,0)
			bambam.MaxTorque = Vector3.new(0,311111,0)
			bambam.P = math.huge
		end
	elseif command == "unfling" then
		if findroot(p.Character):FindFirstChild("BodyAngularVelocity") then
			findroot(p.Character):FindFirstChild("BodyAngularVelocity"):Destroy()
		end
	elseif command == "unbang" then
		banging = false
		if banger then
			banger:Disconnect()
		end
		bang:Stop()
		banga:Destroy()
	elseif command == "sit" then
		if p.Character ~= nil then
			p.Character.Humanoid.Sit = true
		end
	elseif command == "unsit" then
		if p.Character ~= nil then
			p.Character.Humanoid.Sit = false
		end
	elseif command == "freeze" then
		if p.Character ~= nil then
			local force = Instance.new("BodyPosition", findroot(p.Character))
			force.Position = findroot(p.Character).Position
			force.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
			force.Name = "Freeze"
		end
	elseif command == "unfreeze" then
		if p.Character ~= nil then
			if findroot(p.Character):FindFirstChild("Freeze") then
				findroot(p.Character):FindFirstChild("Freeze"):Destroy()
			end
		end
	elseif command == "autoclick" then
		if mouse1press and mouse1release then
			wait()
			local clickDelay = 0.001
			local releaseDelay = 0.001
			autoclicking = true
			cancelAutoClick = UserInputService.InputBegan:Connect(function(input, gameProcessedEvent)
				if not gameProcessedEvent then
					if (input.KeyCode == Enum.KeyCode.F1 and UserInputService:IsKeyDown(Enum.KeyCode.F1)) or (input.KeyCode == Enum.KeyCode.F1) then
						autoclicking = false
						notify("Stopped AutoClick", "Green")
						cancelAutoClick:Disconnect()
					end
				end
			end)
			notify('Press F1 To Stop AutoClicking', "Green")
			repeat wait(clickDelay)
				mouse1press()
				wait(releaseDelay)
				mouse1release()
			until autoclicking == false
		else
			notify("Unsupported Exploit", "Red")
		end
	elseif command == "pp" then
		if p.Character:FindFirstChild("Backuette") then
			local plr = p
			local char = plr.Character
			local pp = char["Backuette"]
			pp.Handle.AccessoryWeld:Destroy()
			pp.Handle.SpecialMesh:Destroy()

			local att0 = Instance.new("Attachment",pp.Handle)
			att0.Orientation = Vector3.new(0, 90, 0)
			att0.Position = Vector3.new(3, 1, 0)

			local att1 = Instance.new("Attachment",char["Torso"])

			local ap = Instance.new("AlignPosition",pp.Handle)
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true


			local ao = Instance.new("AlignOrientation",pp.Handle) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			----------------------------------------------

			local RA = p.Character["Right Arm"]
			local att0 = Instance.new("Attachment",RA)
			att0.Orientation = Vector3.new(0, 0, 0)
			att0.Position = Vector3.new(-1.5, 0, 0)
			att0.Name = "RA"

			local att1 = Instance.new("Attachment",p.Character["Torso"])

			local ap = Instance.new("AlignPosition",RA)
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 


			local ao = Instance.new("AlignOrientation",RA) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			p.Character["Right Arm"].RA.Orientation = Vector3.new(0,0,35)
			p.Character.Torso["Right Shoulder"]:Destroy()
			while wait(0.1) do
				game:GetService("TweenService"):Create(p.Character["Right Arm"].RA, TweenInfo.new(0.1), {['Position'] = Vector3.new(-0.5,-0.2,1)}):Play()
				wait(0.1)
				game:GetService("TweenService"):Create(p.Character["Right Arm"].RA, TweenInfo.new(0.1), {['Position'] = Vector3.new(-0.5,-0.2,0.5)}):Play()
			end
		end
	elseif command == "headless" then
		local char = p.Character
		local rig = tostring(char.Humanoid.RigType) == "Enum.HumanoidRigType.R6" and 1 or tostring(char.Humanoid.RigType) == "Enum.HumanoidRigType.R15" and 2
		local test = Instance.new("Model", workspace)
		local hum  = Instance.new("Humanoid", test)
		local animation = Instance.new("Model", workspace)
		local humanoidanimation = Instance.new("Humanoid", animation)

		p.Character = test
		wait(2)
		char.Humanoid.Animator.Parent = humanoidanimation
		char.Humanoid:Destroy()

		char.Head:Destroy()
		wait(5)
		p.Character = char

		local hum2 = Instance.new("Humanoid")
		hum2.Parent = char
		char:FindFirstChildOfClass("Humanoid").Jump = true

		humanoidanimation.Animator.Parent = hum2
		char.Animate.Disabled = true
		wait()
		char.Animate.Disabled = false
		wait()

		if rig == 1 then
			hum2.HipHeight = 0
		elseif rig == 2 then
			hum2.HipHeight = 2.19
		end
	elseif command == "netcheck" then
		local Plrs = {}

		for i,v in pairs(game:GetService("Players"):GetPlayers()) do
			if gethidden(v, "SimulationRadius") >= 5000 then
				table.insert(Plrs, v.Name)
			end
		end

		if #Plrs <= 0 then
			print("Network check ran: No players have been found using networkownership.")
		elseif #Plrs == 1 and Plrs[1] ~= game:GetService("Players").LocalPlayer.Name then
			print("Network check ran, the player using network: " .. Plrs[1])
		elseif #Plrs == 1 and Plrs[1] == game:GetService("Players").LocalPlayer.Name then
			print("You are the only network owner")
		elseif #Plrs > 1 then
			print("Network Check Ran, People Using Net : ")
			for i, v in pairs(Plrs) do
				print(v)
			end
		end
		notify('Netcheck Ran Check The Console', 'Green')
	elseif command == "nazi" then
		if p.Character.Torso:FindFirstChild("NAP Client Reanim") then
			p.Character["Left Leg"].LL.Position = Vector3.new(-1.5, 2, 0)
			p.Character["Left Leg"].LL.Orientation = Vector3.new(0, 0, 0)
			p.Character["Right Leg"].RL.Position = Vector3.new(1.5, -2, 0)
			p.Character["Right Leg"].RL.Orientation = Vector3.new(-0, 0, -0)
			p.Character["Left Arm"].LA.Position = Vector3.new(-1.5, 2, 0)
			p.Character["Left Arm"].LA.Orientation = Vector3.new(0, 0, 90)
			p.Character["Right Arm"].RA.Position = Vector3.new(1.5, -2, 0)
			p.Character["Right Arm"].RA.Orientation = Vector3.new(0, 0, 90)
		else
			notify('Reanimate First', 'Red')
		end
	elseif command == "reanim" or command == "reanimate" then
		loadstring(game:HttpGet("https://raw.githubusercontent.com/Alpha-404/NAP-Client-Reanimate/main/Reanimate.lua"))()
	elseif command == "resetreanim" then
		if p.Character.Torso:FindFirstChild("NAP Client Reanim") then
			local char = p.Character
			char["Left Leg"].LL.Position = Vector3.new(0.5, 2, 0)
			char["Left Leg"].LL.Orientation = Vector3.new(0, 0, 0)

			char["Right Leg"].RL.Position = Vector3.new(-0.5, 2, 0)
			char["Right Leg"].RL.Orientation = Vector3.new(-0, 0, -0)

			char["Left Arm"].LA.Position = Vector3.new(1.5, 0, 0)
			char["Left Arm"].LA.Orientation = Vector3.new(0, 0, 0)

			char["Right Arm"].RA.Position = Vector3.new(-1.5, 0, 0)
			char["Right Arm"].RA.Orientation = Vector3.new(0, 0, 0)

			char["Torso"].TORSO.Orientation = Vector3.new(0, 0, 0)
			char["Torso"].TORSO.Position = Vector3.new(0, 0, 0)
		else
			notify('Failed to detect reanimate', 'Red')
		end
	elseif command == "tpose" then
		if p.Character.Torso:FindFirstChild("NAP Client Reanim") then
			p.Character["Left Arm"].LA.Orientation = Vector3.new(0,0,90)
			p.Character["Left Arm"].LA.Position = Vector3.new(0.5,2,0)
			p.Character["Right Arm"].RA.Orientation = Vector3.new(0,0,-90)
			p.Character["Right Arm"].RA.Position = Vector3.new(-0.5,2,0)
			p.Character["Left Leg"].LL.Position = Vector3.new(0.5, 2, 0)
			p.Character["Left Leg"].LL.Orientation = Vector3.new(0, 0, 0)
			p.Character["Right Leg"].RL.Position = Vector3.new(-0.5, 2, 0)
			p.Character["Right Leg"].RL.Orientation = Vector3.new(-0, 0, -0)
		else
			notify('Reanimate First', 'Red')
		end
	elseif command == "slilent" or command == "silence" then
		for i,v in pairs(p.Character.HumanoidRootPart:GetDescendants()) do
			if v:IsA("Sound") then
				v:Destroy()
			end
		end
	elseif command == "annoy" then
		for i,v in pairs(game:GetService("Players"):GetPlayers()) do
			if v.Character ~= nil then
				for i,c in pairs(v.Character.Head:GetDescendants()) do
					if c:IsA("Sound") then
						c.Looped = true
						c.Playing = true
					end
				end
			end
		end
	elseif command == "unannoy" then
		for i,v in pairs(p.Character.HumanoidRootPart:GetDescendants()) do
			if v:IsA("Sound") then
				v.Looped = false
				v.Playing = false
			end
		end
	elseif command == "longlegs" or command == "slender" then
		Joint(p.Character["Left Arm"], p.Character["Left Leg"], Vector3.new(0,-2,0), Vector3.new(0,0,0))
		p.Character.Torso["Left Shoulder"]:Destroy()
		Joint(p.Character["Right Arm"], p.Character["Right Leg"], Vector3.new(0,-2,0), Vector3.new(0,0,0))
		p.Character.Torso["Right Shoulder"]:Destroy()
		Joint(p.Character["Torso"], p.Character["HumanoidRootPart"], Vector3.new(0,1.5,0), Vector3.new(0,0,0))
		p.Character.HumanoidRootPart["RootJoint"]:Destroy()
	elseif command == "fly" then
		local Root = p.Character.HumanoidRootPart
		local BV = Instance.new("BodyVelocity", Root)
		local BG = Instance.new("BodyGyro", Root)
		flying = true
		BG.Name = "BLACKOUT_BG"
		BV.Name = "BLACKOUT_BV"
		BG.MaxTorque = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
		BV.MaxForce = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
		BV.Velocity = Vector3.new(0,0,0)
		p.Character:FindFirstChildOfClass("Humanoid").PlatformStand = true

		local flyreq = game:GetService('UserInputService').InputBegan:Connect(function(key, gay)
			if gay then return end
			if key.KeyCode == Enum.KeyCode.W then
				while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.W) do
					BV.Velocity += workspace.CurrentCamera.CFrame.LookVector * flyspeed
					wait()
				end
				BV.Velocity = Vector3.new(0,0,0)
			elseif key.KeyCode == Enum.KeyCode.S then
				while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.S) do
					BV.Velocity -= workspace.CurrentCamera.CFrame.LookVector * 4
					wait()
				end
				BV.Velocity = Vector3.new(0,0,0)
			elseif key.KeyCode == Enum.KeyCode.E then
				while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.E) do
					BV.Velocity -= Vector3.new(0,-1,0)
					wait()
				end
				BV.Velocity = Vector3.new(0,0,0)
			elseif key.KeyCode == Enum.KeyCode.Space then
				while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.Space) do
					BV.Velocity += Vector3.new(0,1,0)
					wait()
				end
				BV.Velocity = Vector3.new(0,0,0)
			elseif key.KeyCode == Enum.KeyCode.Q then
				while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.Q) do
					BV.Velocity += Vector3.new(0,-1,0)
					wait()
				end
				BV.Velocity = Vector3.new(0,0,0)
			elseif key.KeyCode == Enum.KeyCode.D then
				while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.D) do
					BV.Velocity += workspace.CurrentCamera.CFrame.RightVector * flyspeed
					wait()
				end
				BV.Velocity = Vector3.new(0,0,0)
			elseif key.KeyCode == Enum.KeyCode.A then
				while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.A) do
					BV.Velocity += -workspace.CurrentCamera.CFrame.RightVector * flyspeed
					wait()
				end
				BV.Velocity = Vector3.new(0,0,0) 
			end
		end)

		p.Character:FindFirstChildOfClass("Humanoid").Died:Connect(function()
			flying = false
			flyreq:Disconnect()
			BV:Destroy()
			BG:Destroy()
		end)

		spawn(function()
			repeat
				wait()
				p.Character:FindFirstChildOfClass("Humanoid").PlatformStand = true
				BG.CFrame = workspace.CurrentCamera.CFrame
			until flying == false
			flyreq:Disconnect()
			p.Character:FindFirstChildOfClass("Humanoid").PlatformStand = false
			BV:Destroy()
			BG:Destroy()
		end)
	elseif command == "flyspeed" then
		if arg then
			if isNumber(arg) then
				flyspeed = arg
			end
		else
			flyspeed = defFlyspeed
		end
	elseif command == "unfly" then
		if flying then
			flying = false
		end
	elseif command == "droptool" then
		if p.Character:FindFirstChildOfClass("Tool") then
			p.Character:FindFirstChildOfClass("Tool").Parent = workspace
		end
	elseif command == "upsidedown" or command == "dinnerbone" then
		local char = p.Character
		local NL

		NL = game:GetService("RunService").Stepped:Connect(function()
			if p.Character ~= nil then
				for _, child in pairs(char:GetDescendants()) do
					if child:IsA("BasePart") and child.CanCollide == true then
						child.CanCollide = false
					end
				end
			end
		end)

		p.CameraMinZoomDistance = math.huge - math.huge
		p.CameraMaxZoomDistance = math.huge - math.huge

		spawn(function()
			p.CharacterAdded:Wait()
			NL:Disconnect()
		end)

		if char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R15 then
			local att0 = Instance.new("Attachment",char["LowerTorso"])
			att0.Orientation = Vector3.new(-180, 180, 0)
			att0.Position = Vector3.new(0, 1, 0)
			att0.Name = "LT"

			local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

			local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 


			local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			char["LowerTorso"].Root:Destroy()
		elseif char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then

			local att0 = Instance.new("Attachment",char["Torso"])
			att0.Orientation = Vector3.new(180, 180, 0)
			att0.Position = Vector3.new(0, 0, 0)
			att0.Name = "TORSO"

			local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

			local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 


			local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			char["HumanoidRootPart"].RootJoint:Destroy()
		else
			print("wtf")
		end
	elseif command == "sleep" or command == "down" then
		if p.Character:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
			local char = p.Character
			local NL

			NL = game:GetService("RunService").Stepped:Connect(function()
				if p.Character ~= nil then
					for _, child in pairs(char:GetDescendants()) do
						if child:IsA("BasePart") and child.CanCollide == true then
							child.CanCollide = false
						end
					end
				end
			end)

			spawn(function()
				p.CharacterAdded:Wait()
				NL:Disconnect()
			end)

			local att0 = Instance.new("Attachment",char["Torso"])
			att0.Orientation = Vector3.new(90,0,0)
			att0.Position = Vector3.new(0,0,2.5)
			att0.Name = "TORSO"

			local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

			local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 

			local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			char["HumanoidRootPart"].RootJoint:Destroy()
		else
			notify('R6 Only', 'Red')
		end
	elseif command == "surrender" then
		if p.Character.Torso:FindFirstChild("NAP Client Reanim") then
			p.Character["Left Arm"].LA.Position = Vector3.new(1.5, 1.5, 0)
			p.Character["Left Arm"].LA.Orientation = Vector3.new(180, 0, 0)
			p.Character["Right Arm"].RA.Position = Vector3.new(-1.5, 1.5, 0)
			p.Character["Right Arm"].RA.Orientation = Vector3.new(180, 0, 0)
		else
			notify('You must reanimate First', 'Red')
		end
	elseif command == "bird" or command == "birb" then
		if p.Character.Torso:FindFirstChild("NAP Client Reanim") then
			p.Character.Torso.TORSO.Orientation = Vector3.new(90,0,0)
			p.Character["Left Arm"].LA.Orientation = Vector3.new(0,0,90)
			p.Character["Left Arm"].LA.Position = Vector3.new(0.5,2,0)
			p.Character["Right Arm"].RA.Orientation = Vector3.new(0,0,-90)
			p.Character["Right Arm"].RA.Position = Vector3.new(-0.5,2,0)
			spawn(function()
				while wait(0.4) do
					game:GetService("TweenService"):Create(p.Character["Torso"].TORSO, TweenInfo.new(0.4), {['Position'] = Vector3.new(0, 0, -5)}):Play()
					wait(0.4)
					game:GetService("TweenService"):Create(p.Character["Torso"].TORSO, TweenInfo.new(0.4), {['Position'] = Vector3.new(0, 0, -2)}):Play()
				end
			end)

			while wait(0.4) do
				game:GetService("TweenService"):Create(p.Character["Left Arm"].LA, TweenInfo.new(0.2), {['Orientation'] = Vector3.new(45, 0, 90)}):Play()
				game:GetService("TweenService"):Create(p.Character["Right Arm"].RA, TweenInfo.new(0.2), {['Orientation'] = Vector3.new(45, 0, -90)}):Play()
				wait(0.4)
				game:GetService("TweenService"):Create(p.Character["Left Arm"].LA, TweenInfo.new(0.2), {['Orientation'] = Vector3.new(-20, 0, 90)}):Play()
				game:GetService("TweenService"):Create(p.Character["Right Arm"].RA, TweenInfo.new(0.2), {['Orientation'] = Vector3.new(-20, 0, -90)}):Play()
			end
		else
			notify('You must reanimate First', 'Red')
		end
	elseif command == "invis" or command == "invisible" then
		if p.Character.Torso:FindFirstChild('NAP Client Reanim') then
			p.Character.Torso.TORSO.Position = Vector3.new(0, 50, 0)
		else
			notify('You must reanimate First', 'Red')
		end
	elseif command == "spec" or command == "spectate" or command == "view" then
		if arg then
			if findplayer(arg) ~= nil then
				workspace.CurrentCamera.CameraSubject = findplayer(arg).Character
			end
		end
	elseif command == "unspec" or command == "unspectate" or command == "unview" then
		workspace.CurrentCamera.CameraSubject = p.Character
	elseif command == "devconsole" or command == "console" then
		game:GetService("StarterGui"):SetCore('DevConsoleVisible', true)
	elseif command == "glitchtool" then
		if p.Character:FindFirstChildOfClass("Tool") then
			local tool = p.Character:FindFirstChildOfClass("Tool")
			p.Character.Humanoid:UnequipTools()
			tool.GripPos = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
			p.Character.Humanoid:EquipTool(tool)
			spawn(function()
				while tool ~= nil do
					tool.Name = randomstring()
					wait()
				end
			end)
		end
	elseif command == "tocframe" or command == "tocf" then
		if p.Character:FindFirstChild("Humanoid") then
			p.Character:FindFirstChildOfClass('Humanoid').Sit = false
		end
		if p.Character ~= nil then
			findroot(p.Character).CFrame = arg
		end
	elseif command == "tweengoto" then
		if p.Character:FindFirstChild("Humanoid") then
			p.Character:FindFirstChildOfClass('Humanoid').Sit = false
		end
		game:GetService("TweenService"):Create(findroot(p.Character), TweenInfo.new(10), {['CFrame'] = findroot(findplayer(arg).Character)}):Play()
	elseif command == "tweenlp" then
		if p.Character:FindFirstChild("Humanoid") then
			p.Character:FindFirstChildOfClass('Humanoid').Sit = false
		end
		game:GetService("TweenService"):Create(findroot(p.Character), TweenInfo.new(10), {['CFrame'] = SP}):Play()
	elseif command == "wsbypass" then
		spawn(function()
			local hum = game:GetService("Players").LocalPlayer.Character.Humanoid
			local GameMt = getrawmetatable(game)
			local OldIndex = GameMt.__index

			setreadonly(GameMt, false)

			GameMt.__index = newcclosure(function(Self, Key)
				if not checkcaller() and Self == hum and Key == "WalkSpeed" then
					return 16
				end

				return OldIndex(Self, Key)
			end)

			setreadonly(GameMt, true)
		end)
		notify('Bypassed WalkSpeed', "Green")
	elseif command == "jpbypass" then
		spawn(function()
			local hum = game:GetService("Players").LocalPlayer.Character.Humanoid
			local GameMt = getrawmetatable(game)
			local OldIndex = GameMt.__index

			setreadonly(GameMt, false)

			GameMt.__index = newcclosure(function(Self, Key)
				if not checkcaller() and Self == hum and Key == "JumpPower" then
					return 50
				end

				return OldIndex(Self, Key)
			end)

			setreadonly(GameMt, true)
		end)
		notify('Bypassed JumpPower', "Green")
	end
end)

local L_1_ = game:GetService("UserInputService")
function drag(L_2_arg1)
	dragToggle = nil
	local dragSpeed = 0.23
	dragInput = nil
	dragStart = nil
	local dragPos = nil
	function updateInput(L_3_arg1)
		local Delta = L_3_arg1.Position - dragStart
		local Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
		game:GetService("TweenService"):Create(L_2_arg1, TweenInfo.new(0.25), {
			Position = Position
		}):Play()
	end
	L_2_arg1.InputBegan:Connect(function(L_4_arg1)
		if (L_4_arg1.UserInputType == Enum.UserInputType.MouseButton1 or L_4_arg1.UserInputType == Enum.UserInputType.Touch) and L_1_:GetFocusedTextBox() == nil then
			dragToggle = true
			dragStart = L_4_arg1.Position
			startPos = L_2_arg1.Position
			L_4_arg1.Changed:Connect(function()
				if L_4_arg1.UserInputState == Enum.UserInputState.End then
					dragToggle = false
				end
			end)
		end
	end)
	L_2_arg1.InputChanged:Connect(function(L_5_arg1)
		if L_5_arg1.UserInputType == Enum.UserInputType.MouseMovement or L_5_arg1.UserInputType == Enum.UserInputType.Touch then
			dragInput = L_5_arg1
		end
	end)
	game:GetService("UserInputService").InputChanged:Connect(function(L_6_arg1)
		if L_6_arg1 == dragInput and dragToggle then
			updateInput(L_6_arg1)
		end
	end)
end
drag(Frame)

cmdbox.PlaceholderText = "Welcome, " .. p.Name
wait(2)
cmdbox.PlaceholderText = "BLACKOUT V" .. ver