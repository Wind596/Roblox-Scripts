local m = getrawmetatable(game)
local runservice = game:GetService("RunService")
local uis = game:GetService("UserInputService")
setreadonly(m,false)
 
local on = false
local namecall = m.__namecall
 
local function kill(code,player)
    if player and code then
        local A_1 =
        {
                [1] =
            {
                [1] = player.Character.Humanoid,
                [2] = code,
                [3] = 170,
                [4] = player.Character.Head.Position,
                [5] = false,
                [6] = false,
                [7] = false
            },
                [2] =
            {
                [1] = false,
                [2] = false,
                [3] = false,
                [4] = false,
                [5] = false,
                [6] = 2,
                [7] = 2
            }
        }
        local Event = game:GetService("Workspace")["__THINGS"]["__REMOTES"]["do damage"]
        Event:FireServer(A_1)
    end
end
 
local function getplayer()
    local f = {}
    for _,player in pairs(game:GetService("Players"):GetPlayers()) do
        if player.Character and player ~= game:GetService("Players").LocalPlayer then
            local c = false
            if player.Neutral then
                c = true
            elseif player.Team ~= game:GetService("Players").LocalPlayer.Team then
                c = true
            end
            if c and player.Character:FindFirstChild("Humanoid") and not player.Character:FindFirstChildOfClass("ForceField") and player.Character:FindFirstChild("Head") then
                f[#f+1] = player
            end
        end
    end
    return f
end
 
local function namecallfunction(self,...)
    local args = {...}
    if getnamecallmethod() == "FireServer" then
        if args[1] then
            if args[1][1] then
                if #args[1][1] == 3 then
                    local f = getplayer()
                    kill(args[1][1][2],f[math.random(1,#f)])
                end
            end
        end
    end
    return namecall(self,unpack(args))
end
 
runservice.RenderStepped:Connect(function()
    if on then
        if validfgwindow() then
        else
            on = false
            warn("Mouse clicked outside of Roblox")
        end
    end
end)
 
uis.InputBegan:Connect(function(input)
    if input.KeyCode == Enum.KeyCode.E then
        if on then on = false else on = true end
        warn(on == true and "On" or on == false and "Off")
    end
end)
 
m.__namecall = namecallfunction
setreadonly(m,true)