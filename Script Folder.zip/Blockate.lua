local UserInputService = game:GetService("UserInputService")
local ScreenGui = Instance.new("ScreenGui")
local Main = Instance.new("ImageLabel")
local Outside = Instance.new("ImageLabel")
local Inside = Instance.new("ImageLabel")
local TabBack = Instance.new("Frame")
local MainTab = Instance.new("TextButton")
local MainTabGui = Instance.new("Frame")
local Chaos = Instance.new("TextButton")
local CHAOS = Instance.new("TextLabel")
local Empty = Instance.new("TextLabel")
local Empty_2 = Instance.new("TextButton")
local TextLabel = Instance.new("TextLabel")
local gui = Main
local dragging
local dragInput
local dragStart
local startPos


ScreenGui.Parent = game.CoreGui

Main.Name = "Main"
Main.Parent = ScreenGui
Main.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Main.BackgroundTransparency = 1.000
Main.Position = UDim2.new(0.710014999, 0, 0.674757242, 0)
Main.Size = UDim2.new(0, 338, 0, 24)
Main.Image = "rbxassetid://3570695787"
Main.ImageColor3 = Color3.fromRGB(33, 33, 33)
Main.ScaleType = Enum.ScaleType.Slice
Main.SliceCenter = Rect.new(100, 100, 100, 100)
Main.SliceScale = 0.060
local function update(input)
	local delta = input.Position - dragStart
	gui.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
end

gui.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
		dragging = true
		dragStart = input.Position
		startPos = gui.Position
		
		input.Changed:Connect(function()
			if input.UserInputState == Enum.UserInputState.End then
				dragging = false
			end
		end)
	end
end)

gui.InputChanged:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
		dragInput = input
	end
end)

UserInputService.InputChanged:Connect(function(input)
	if input == dragInput and dragging then
		update(input)
	end
end)

Outside.Name = "Outside"
Outside.Parent = Main
Outside.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Outside.BackgroundTransparency = 1.000
Outside.Position = UDim2.new(-0.00012421608, 0, 0.689999998, 0)
Outside.Size = UDim2.new(0, 338, 0, 168)
Outside.Image = "rbxassetid://3570695787"
Outside.ImageColor3 = Color3.fromRGB(33, 33, 33)
Outside.ScaleType = Enum.ScaleType.Slice
Outside.SliceCenter = Rect.new(100, 100, 100, 100)
Outside.SliceScale = 0.060

Inside.Name = "Inside"
Inside.Parent = Outside
Inside.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Inside.BackgroundTransparency = 1.000
Inside.Position = UDim2.new(0.0266272202, 0, 0.0714285746, 0)
Inside.Size = UDim2.new(0, 319, 0, 144)
Inside.Image = "rbxassetid://3570695787"
Inside.ImageColor3 = Color3.fromRGB(69, 69, 69)
Inside.ScaleType = Enum.ScaleType.Slice
Inside.SliceCenter = Rect.new(100, 100, 100, 100)
Inside.SliceScale = 0.060

TabBack.Name = "TabBack"
TabBack.Parent = Inside
TabBack.BackgroundColor3 = Color3.fromRGB(49, 49, 49)
TabBack.BorderSizePixel = 0
TabBack.Size = UDim2.new(0, 319, 0, 21)

MainTab.Name = "MainTab"
MainTab.Parent = TabBack
MainTab.BackgroundColor3 = Color3.fromRGB(69, 69, 69)
MainTab.BorderSizePixel = 0
MainTab.Size = UDim2.new(0, 58, 0, 21)
MainTab.Font = Enum.Font.Gotham
MainTab.Text = "Main"
MainTab.TextColor3 = Color3.fromRGB(255, 255, 255)
MainTab.TextSize = 14.000

MainTabGui.Name = "MainTabGui"
MainTabGui.Parent = MainTab
MainTabGui.BackgroundColor3 = Color3.fromRGB(69, 69, 69)
MainTabGui.BorderSizePixel = 0
MainTabGui.Position = UDim2.new(0, 0, 1, 0)
MainTabGui.Size = UDim2.new(0, 319, 0, 123)

Chaos.Name = "Chaos"
Chaos.Parent = MainTabGui
Chaos.BackgroundColor3 = Color3.fromRGB(204, 52, 59)
Chaos.BorderSizePixel = 0
Chaos.Position = UDim2.new(0.031347964, 0, 0.065040648, 0)
Chaos.Size = UDim2.new(0, 25, 0, 25)
Chaos.Font = Enum.Font.SourceSans
Chaos.Text = ""
Chaos.TextColor3 = Color3.fromRGB(0, 0, 0)
Chaos.TextSize = 14.000
Chaos.MouseButton1Down:connect(function()
	local text = "HACKED BY EGG REPUBLIC"
	local kill = true
	local sign = true
	
	
	local x = workspace.Blocks:GetChildren()
	for i=1,#x do
		local child = x[i]
		if kill then
			game:GetService("ReplicatedStorage").Sockets.Edit.EditBlock:FireServer("kill",child)
		end
		if sign then
			game:GetService("ReplicatedStorage").Sockets.Edit.EditBlock:FireServer("sign",{child,text})
		end end
end)

CHAOS.Name = "CHAOS"
CHAOS.Parent = MainTabGui
CHAOS.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
CHAOS.BackgroundTransparency = 1.000
CHAOS.BorderSizePixel = 0
CHAOS.Position = UDim2.new(0.200626969, 0, 0.065040648, 0)
CHAOS.Size = UDim2.new(0, 45, 0, 25)
CHAOS.Font = Enum.Font.Gotham
CHAOS.Text = "CHAOS"
CHAOS.TextColor3 = Color3.fromRGB(255, 255, 255)
CHAOS.TextSize = 14.000

Empty.Name = "Empty"
Empty.Parent = MainTabGui
Empty.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Empty.BackgroundTransparency = 1.000
Empty.BorderSizePixel = 0
Empty.Position = UDim2.new(0.200626969, 0, 0.398373991, 0)
Empty.Size = UDim2.new(0, 45, 0, 25)
Empty.Font = Enum.Font.Gotham
Empty.Text = "DELETE ALL"
Empty.TextColor3 = Color3.fromRGB(255, 255, 255)
Empty.TextSize = 14.000

Empty_2.Name = "Empty"
Empty_2.Parent = MainTabGui
Empty_2.BackgroundColor3 = Color3.fromRGB(204, 52, 59)
Empty_2.BorderSizePixel = 0
Empty_2.Position = UDim2.new(0.031347964, 0, 0.398373991, 0)
Empty_2.Size = UDim2.new(0, 25, 0, 25)
Empty_2.Font = Enum.Font.SourceSans
Empty_2.Text = ""
Empty_2.TextColor3 = Color3.fromRGB(0, 0, 0)
Empty_2.TextSize = 14.000
Empty_2.MouseButton1Down:connect(function()
	local x = workspace.Blocks:GetChildren()
	for i=1,#x do
		local child = x[i]
		game:GetService("ReplicatedStorage").Sockets.Edit.Delete:FireServer(child)
	end
end)

TextLabel.Parent = Outside
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0.130177528, 0, -0.064262569, 0)
TextLabel.Size = UDim2.new(0, 64, 0, 12)
TextLabel.Font = Enum.Font.GothamBlack
TextLabel.Text = "BLOCKATE DESTROYER"
TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.TextSize = 12.000