local p = game:GetService("Players").LocalPlayer
local char = p.Character

function Joint(P1,P2,Pos,Rot)
	local AlignP = Instance.new('AlignPosition', P2);
	AlignP.ApplyAtCenterOfMass = true;
	AlignP.MaxForce = 67752;
	AlignP.MaxVelocity = math.huge/9e110;
	AlignP.ReactionForceEnabled = false;
	AlignP.Responsiveness = 200;
	AlignP.RigidityEnabled = true;
	local AlignO = Instance.new('AlignOrientation', P2);
	AlignO.MaxAngularVelocity = math.huge/9e110;
	AlignO.MaxTorque = 67752;
	AlignO.PrimaryAxisOnly = false;
	AlignO.ReactionTorqueEnabled = false;
	AlignO.Responsiveness = 200;
	AlignO.RigidityEnabled = true;
	local AttA=Instance.new('Attachment',P2);
	local AttB=Instance.new('Attachment',P1);
	AttA.Orientation = Rot
	AttA.Position = Pos
	AlignP.Attachment1 = AttA;
	AlignP.Attachment0 = AttB;
	AlignO.Attachment1 = AttA;
	AlignO.Attachment0 = AttB;
	AttA.Name = "Align" .. P1.Name
	AttB.Name = "Align" .. P1.Name
end

local pr = Instance.new("Part", char)
pr.Size = Vector3.new(1,1,1)
pr.CanCollide = false
pr.Transparency = 1
Joint(char["Right Arm"], pr, Vector3.new(0,0,0), Vector3.new(0,0,0))
Joint(char["bloxcxy"].Handle, char["Right Arm"], Vector3.new(0,0,0), Vector3.new(0,0,0))
char["bloxcxy"].Handle.AccessoryWeld:Destroy()
char["Right Arm"].AlignHandle.CFrame = CFrame.new(-0.100000001, -1, -0.300000012, 1, 0, 0, 0, -4.37113883e-08, 1, 0, -1, -4.37113883e-08)

local weld = Instance.new("Weld", p.Character)
weld.C0 = CFrame.new(1.5, 0.480222225, -0.553956985, 1, 0, 3.82137093e-15, 3.82137093e-15, 4.37113883e-08, -1, 0, 1, 4.37113883e-08)
weld.Part0 = p.Character.Torso
weld.Part1 = pr

local debounce = false

p:GetMouse().Button1Down:Connect(function()
	if debounce == false then
		debounce = true
		weld.C0 = CFrame.new(0.913360596, 0.711382866, -1.16908169, 0.438806683, 0.898287296, 0.0227929056, 0.857509971, -0.411031842, -0.309398651, -0.26856178, 0.155310541, -0.950659215)
		wait(2)
		weld.C0 = CFrame.new(1.5, 0.480222225, -0.553956985, 1, 0, 3.82137093e-15, 3.82137093e-15, 4.37113883e-08, -1, 0, 1, 4.37113883e-08)
		debounce = false
	end
end)

char.Torso["Right Shoulder"]:Destroy()

char["bloxcxy"].Handle:GetPropertyChangedSignal("LocalTransparencyModifier"):Connect(function()
	char["bloxcxy"].Handle.LocalTransparencyModifier = char["bloxcxy"].Handle.Transparency
end)