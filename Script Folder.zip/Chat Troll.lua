local A_1 = "hi                                                                                                                                              {System} ROBLOX has joined the game."
local A_2 = "All"
local Event = game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest
Event:FireServer(A_1, A_2)