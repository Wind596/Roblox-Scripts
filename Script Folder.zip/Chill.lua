local KeyFrames = {
   {
      K = Keyframe,
      Poses = {
         Head = {
            CF = CFrame.new(0, -9.9837779998779e-06, 8.1062316894531e-06, 1, 0, 0, 0, 0.8003186583519, -0.59957486391068, 0, 0.59957486391068, 0.8003186583519),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         HumanoidRootPart = {
            CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         Torso = {
            CF = CFrame.new(0, -0.00067174347350374, 10.250003814697, 1, 0, 0, 0, 6.5521395299584e-05, 1, 0, -1, 6.5521395299584e-05),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Left Arm"] = {
            CF = CFrame.new(3.2126903533936e-05, 0.14982736110687, -0.1610090136528, -0.2762556374073, -0.68574118614197, -0.67338067293167, 0.95788216590881, -0.13930985331535, -0.25110578536987, 0.078385055065155, -0.71438872814178, 0.69534462690353),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Left Leg"] = {
            CF = CFrame.new(-6.6757202148438e-06, 1.9609928131104e-05, 6.258487701416e-06, 0.91989207267761, 0.39217162132263, -1.3329554349184e-08, -0.39217153191566, 0.91989171504974, -0.00049209647113457, -0.00019297411199659, 0.00045268089161254, 0.99999988079071),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Right Arm"] = {
            CF = CFrame.new(-0.23933576047421, 0.048853062093258, -0.052183091640472, -0.31969684362411, 0.43647089600563, 0.84100359678268, -0.94017577171326, -0.25642031431198, -0.22431664168835, 0.11774277687073, -0.86240446567535, 0.49233621358871),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Right Leg"] = {
            CF = CFrame.new(-1.1488795280457e-05, 1.1146068572998e-05, -8.4042549133301e-06, 0.98106235265732, 0.19369207322598, -1.8597351214567e-08, -0.19369204342365, 0.98106199502945, -0.00049550156109035, -9.5956500445027e-05, 0.00048612162936479, 0.99999988079071),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         }
      },
      Time = 0
   },
   {
      K = Keyframe,
      Poses = {
         Head = {
            CF = CFrame.new(0, 4.2319297790527e-06, -2.3424625396729e-05, 1, 0, 0, 0, 0.7509623169899, 0.66034513711929, 0, -0.66034513711929, 0.7509623169899),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         HumanoidRootPart = {
            CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         Torso = {
            CF = CFrame.new(0, -0.00019353759125806, 2.8299958705902, 1, 0, 0, 0, 6.5521395299584e-05, 1, 0, -1, 6.5521395299584e-05),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Left Arm"] = {
            CF = CFrame.new(4.3779611587524e-05, 0.1498126834631, -0.16101014614105, -0.27625676989555, -0.8968819975853, -0.34537607431412, 0.95788198709488, -0.22763511538506, -0.17505407333374, 0.078383192420006, -0.37918940186501, 0.92199301719666),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Left Leg"] = {
            CF = CFrame.new(1.8179416656494e-05, 3.7252902984619e-06, 3.3974647521973e-06, 0.28783929347992, -0.95767855644226, -1.0855727872183e-08, 0.95767843723297, 0.28783911466599, -0.00049175694584846, 0.00047094843466766, 0.00014153655502014, 0.99999982118607),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Right Arm"] = {
            CF = CFrame.new(-0.2393566519022, 0.048832047730684, -0.052186973392963, -0.3196984231472, 0.84582680463791, 0.4270478785038, -0.94017481803894, -0.33918228745461, -0.032040514051914, 0.11774641275406, -0.41174286603928, 0.9036613702774),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Right Leg"] = {
            CF = CFrame.new(-4.1484832763672e-05, -2.0980834960938e-05, -5.1259994506836e-06, 0.80463188886642, 0.5937739610672, -1.2631065970936e-08, -0.59377384185791, 0.80463153123856, -0.00049134116852656, -0.00029173551592976, 0.00039535632822663, 0.99999988079071),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         }
      },
      Time = 6
   },
   {
       K = Keyframe,
      Poses = {
         Head = {
            CF = CFrame.new(0, -9.9837779998779e-06, 8.1062316894531e-06, 1, 0, 0, 0, 0.8003186583519, -0.59957486391068, 0, 0.59957486391068, 0.8003186583519),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         HumanoidRootPart = {
            CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         Torso = {
            CF = CFrame.new(0, -0.00067174347350374, 10.250003814697, 1, 0, 0, 0, 6.5521395299584e-05, 1, 0, -1, 6.5521395299584e-05),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Left Arm"] = {
            CF = CFrame.new(3.2126903533936e-05, 0.14982736110687, -0.1610090136528, -0.2762556374073, -0.68574118614197, -0.67338067293167, 0.95788216590881, -0.13930985331535, -0.25110578536987, 0.078385055065155, -0.71438872814178, 0.69534462690353),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Left Leg"] = {
            CF = CFrame.new(-6.6757202148438e-06, 1.9609928131104e-05, 6.258487701416e-06, 0.91989207267761, 0.39217162132263, -1.3329554349184e-08, -0.39217153191566, 0.91989171504974, -0.00049209647113457, -0.00019297411199659, 0.00045268089161254, 0.99999988079071),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Right Arm"] = {
            CF = CFrame.new(-0.23933576047421, 0.048853062093258, -0.052183091640472, -0.31969684362411, 0.43647089600563, 0.84100359678268, -0.94017577171326, -0.25642031431198, -0.22431664168835, 0.11774277687073, -0.86240446567535, 0.49233621358871),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Right Leg"] = {
            CF = CFrame.new(-1.1488795280457e-05, 1.1146068572998e-05, -8.4042549133301e-06, 0.98106235265732, 0.19369207322598, -1.8597351214567e-08, -0.19369204342365, 0.98106199502945, -0.00049550156109035, -9.5956500445027e-05, 0.00048612162936479, 0.99999988079071),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         }
      },
      Time = 12
   }
}

loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()

local Character = workspace:WaitForChild('Rig')
local Motors = {}
local Normals = {}

for i,v in pairs(Character:GetDescendants()) do
	if v:IsA("Motor6D") and v.Part0 and v.Part1  then
		Motors[tostring(v.Part1)] = v
		Normals[tostring(v.Part1)] = v.Transform
	end
end 

function poseTweenInfo(t,s,g)
	local s = tostring(s)
	local g = tostring(g)
	local s = string.split(s,"Enum.PoseEasingStyle.")
	local g = string.split(g,"Enum.PoseEasingDirection.")
	local s = s[2]
	local g = g[2]
	local s = Enum.EasingStyle[s]
	local g = Enum.EasingDirection[g]
	return TweenInfo.new(t,s,g)
end

while wait() do
	for i,Keyframe in pairs(KeyFrames) do
		local LastKeyframe = KeyFrames[#KeyFrames-1] or Keyframe
		for PoseName,Pose in pairs(Keyframe.Poses) do
			local Inst = Motors[tostring(PoseName)]
			if Inst and Inst.Name ~= "HumanoidRootPart" then
				local waitTime = Keyframe.Time
				local PoseTween = game:GetService("TweenService"):Create(Motors[tostring(PoseName)],poseTweenInfo(waitTime,Pose.EasingStyle,Pose.EasingDirection),{Transform = Pose.CF})

				PoseTween:Play()
			end
		end
		wait(Keyframe.Time)
	end

	for i,v in pairs(Motors) do
		game:GetService("TweenService"):Create(v,TweenInfo.new(),{Transform = Normals[tostring(i)]}):Play()
	end
end