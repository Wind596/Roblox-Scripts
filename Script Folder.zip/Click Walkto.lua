local PathService = game:GetService("PathfindingService")
game:GetService("Players").LocalPlayer:GetMouse().Button1Down:Connect(function()
    if not game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.LeftControl) then
        return
    end
    local NL = game:GetService("RunService").Stepped:Connect(function()
        if game:GetService("Players").LocalPlayer.Character ~= nil then
            for _, child in pairs(game:GetService("Players").LocalPlayer.Character:GetDescendants()) do
                if child:IsA("BasePart") and child.CanCollide == true then
                    child.CanCollide = false
                end
            end
        end
    end)
    local pos = game:GetService("Players").LocalPlayer:GetMouse().Hit
    local path = PathService:CreatePath()
    path:ComputeAsync(game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.Position, game:GetService("Players").LocalPlayer:GetMouse().Hit.Position)
    local waypoints = path:GetWaypoints()
    local dist
    local success, response = pcall(function()
        for waypointIndex, waypoint in pairs(waypoints) do
            local waypointPosition = waypoint.Position
            game:GetService("Players").LocalPlayer.Character:FindFirstChildOfClass("Humanoid"):MoveTo(waypointPosition)
            repeat 
                dist = (waypointPosition - game:GetService("Players").LocalPlayer.Character:FindFirstChildOfClass("Humanoid").Parent.PrimaryPart.Position).magnitude
                wait()
            until dist <= 5
        end
    end)
    if not success then
        game:GetService("StarterGui"):SetCore("SendNotification",{Title="Error:",Text='Unable to compute path check dev console for more info',Duration=5})
        print("Click tp response error : " .. response)
        game:GetService("StarterGui"):SetCore("SendNotification",{Title="Info:",Text='Teleporting Instead',Duration=5})
        game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = pos
    end
    NL:Disconnect()
end)