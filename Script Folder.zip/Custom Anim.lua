local anim = game:GetService("Players").LocalPlayer.Character.Animate
anim.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=656118852"
anim.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=742637942"
anim.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=4417977954"
anim.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=4417978624"
anim.swim.Swim.AnimationId = "http://www.roblox.com/asset/?id=5319850266"
anim.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=742637151"
anim.Disabled = true
anim.Disabled = false