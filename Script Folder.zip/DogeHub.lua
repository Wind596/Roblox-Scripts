local Material = loadstring(game:HttpGet("https://raw.githubusercontent.com/Kinlei/MaterialLua/master/Module.lua"))()
local p = game:GetService("Players").LocalPlayer

local UI = Material.Load({
	Title = "D O G E HUB",
	Style = 3,
	SizeX = 500,
	SizeY = 350,
	Theme = "Dark",
	ColorOverrides = {
		MainFrame = Color3.fromRGB(45,45,45)
	}
})

function notify(Title, String)
	game:GetService("StarterGui"):SetCore("SendNotification",{Title=Title,Text=String,Duration=5})
end

function GetRig()
	if game:GetService("Players").LocalPlayer.Character.RigType == Enum.HumanoidRigType.R6 then
		return "R6"
	else
		return "R15"
	end
end

function IsReanim()
	if GetRig == "R6" and game:GetService("Players").LocalPlayer.Character.Torso:FindFirstChild("NAP Client Reanim") then
		return true
	else
		notify('Reanimate First')
	end
end

function Animate(joint, cFrame)
	if IsReanim() then
		game:GetService("TweenService"):Create(joint, TweenInfo.new(0.2), {['CFrame'] = cFrame}):Play()
	end
end

local Anims = UI.New({
	Title = "Animations"
})

local Others = UI.New({
	Title = "Utils"
})

local gay = Anims.Button({
	Text = "Reanimate",
	Callback = function()
		loadstring(game:HttpGet("https://raw.githubusercontent.com/Alpha-404/NAP-Client-Reanimate/main/Reanimate.lua"))()
	end
})

local Knife = Anims.Button({
	Text = "YandreKnife",
	Callback = function()
		if p.Character:FindFirstChild('YandereKnife') and  p.Character:FindFirstChild('TurtleNeck') then
			local char = game:GetService("Players").LocalPlayer.Character
			local idk = false

			local hrp = char.TurtleNeck

			hrp.Handle.Transparency = 0.5
			hrp.Handle.SpecialMesh:Destroy()
			hrp.Handle.CanCollide = false

			hrp.Parent = workspace

			hrp.Handle.Massless = true
			hrp.Handle:WaitForChild("TouchInterest"):Destroy()

			local OCF = char.HumanoidRootPart.CFrame

			local bp = Instance.new("BodyPosition", hrp.Handle)
			bp.D = 60
			bp.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
			bp.Position = char.Torso.Position + Vector3.new(0, 15, 0)
			wait(0.5)
			local flinger = Instance.new("BodyAngularVelocity",hrp.Handle)
			flinger.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
			flinger.P = 1000000000000000000000000000
			flinger.AngularVelocity = Vector3.new(10000,10000,10000)
			hrp.Handle.CanCollide = false

			char.HumanoidRootPart.CFrame = OCF

			--------------------------------------------------------------

			local att0 = Instance.new("Attachment",char["YandereKnife"].Handle)
			local idk = false
			att0.Orientation = Vector3.new(0, -90, -90)
			att0.Position = Vector3.new(-0.8, 0, 0.9)
			att0.Name = "thingy"

			local att1 = Instance.new("Attachment",char["Right Arm"])

			local ap = Instance.new("AlignPosition",char["Right Arm"])
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 

			local ao = Instance.new("AlignOrientation",char["Right Arm"]) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true
			char["YandereKnife"].Handle.AccessoryWeld:Destroy()

			-----------------------------------------------------------

			local RA = char["Right Arm"]
			local att0 = Instance.new("Attachment",RA)
			att0.Orientation = Vector3.new(0, 0, 0)
			att0.Position = Vector3.new(-1.5, 0, 0)
			att0.Name = "RA"

			local att1 = Instance.new("Attachment",char["Torso"])

			local ap = Instance.new("AlignPosition",RA)
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 


			local ao = Instance.new("AlignOrientation",RA) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			char["Torso"]["Right Shoulder"]:Destroy()

			----------------------------------------------------------------------------------

			local e = game:GetService("Players").LocalPlayer:GetMouse().Button1Down:Connect(function()
				idk = false
				bp.Position = char["YandereKnife"].Handle.Position
				hrp.Handle.Position = char["YandereKnife"].Handle.Position
				game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.2), {['CFrame'] = CFrame.new(-1.5, 0, 0, 0.906307757, 0, -0.42261827, 0.298836231, 0.707106829, 0.640856385, 0.298836231, -0.707106829, 0.640856385)}):Play()
				wait(0.4)
				game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1)}):Play()
			end)

			----------------------------------------------------------------------------------

			local f = game:GetService("UserInputService").InputBegan:Connect(function(key, gay)
				if gay then return end

				if key.KeyCode == Enum.KeyCode.F then
					if idk then
						idk = false
						game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1)}):Play()
						bp.Position = char["YandereKnife"].Handle.Position
						hrp.Handle.Position = char["YandereKnife"].Handle.Position
					else
						idk = true
						game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-0.899999976, 1, -1.39999998, 0.173648223, 0.98480773, 4.30473115e-08, 0, -4.37113883e-08, 0.99999994, 0.98480773, -0.173648223, -7.59040475e-09)}):Play()
					end
				elseif key.KeyCode == Enum.KeyCode.R then
					if game:GetService("Players").LocalPlayer:GetMouse().Target == nil then return end
					idk = false
					game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 1.5, 0, 1, 0, 0, 0, -0.939692616, 0.342020214, 0, -0.342020214, -0.939692616)}):Play()
					wait(0.4)
					game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.2), {['CFrame'] = CFrame.new(-1.5, 0.5, 0.5, 1, 0, -0, 0, 0.707106829, 0.707106829, 0, -0.707106829, 0.707106829)}):Play()
					bp.Position = game:GetService("Players").LocalPlayer:GetMouse().Hit.Position
					hrp.Handle.Position = game:GetService("Players").LocalPlayer:GetMouse().Hit.Position
					wait(0.27)
					game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1)}):Play()
				elseif key.KeyCode == Enum.KeyCode.G then
					bp.Position = char.Torso.Position + Vector3.new(0, 15, 0)
					hrp.Handle.Position = char.Torso.Position + Vector3.new(0, 15, 0)
				end
			end)

			------------------------------------------------------------------------------------

			game:GetService("Players").LocalPlayer.CharacterAdded:Wait()
			e:Disconnect()
			f:Disconnect()
			bp:Destroy()
		else
			notify('Error', 'Hats Needed : Kawaii Knife, Black turtle neck')
		end
	end
})

local birb = Anims.Button({
	Text = "Birb",
	Callback = function()
		if IsReanim() then
			p.Character.Torso.TORSO.Orientation = Vector3.new(90,0,0)
			p.Character["Left Arm"].LA.Orientation = Vector3.new(0,0,90)
			p.Character["Left Arm"].LA.Position = Vector3.new(0.5,2,0)
			p.Character["Right Arm"].RA.Orientation = Vector3.new(0,0,-90)
			p.Character["Right Arm"].RA.Position = Vector3.new(-0.5,2,0)
			spawn(function()
				while wait(0.4) do
					game:GetService("TweenService"):Create(p.Character["Torso"].TORSO, TweenInfo.new(0.4), {['Position'] = Vector3.new(0, 0, -5)}):Play()
					wait(0.4)
					game:GetService("TweenService"):Create(p.Character["Torso"].TORSO, TweenInfo.new(0.4), {['Position'] = Vector3.new(0, 0, -2)}):Play()
				end
			end)

			while wait(0.4) do
				game:GetService("TweenService"):Create(p.Character["Left Arm"].LA, TweenInfo.new(0.2), {['Orientation'] = Vector3.new(45, 0, 90)}):Play()
				game:GetService("TweenService"):Create(p.Character["Right Arm"].RA, TweenInfo.new(0.2), {['Orientation'] = Vector3.new(45, 0, -90)}):Play()
				wait(0.4)
				game:GetService("TweenService"):Create(p.Character["Left Arm"].LA, TweenInfo.new(0.2), {['Orientation'] = Vector3.new(-20, 0, 90)}):Play()
				game:GetService("TweenService"):Create(p.Character["Right Arm"].RA, TweenInfo.new(0.2), {['Orientation'] = Vector3.new(-20, 0, -90)}):Play()
			end
		end
	end
})

local antiskid = Others.Button({
	Text = "AntiClaim",
	Callback = function()
		local char = game:GetService("Players").LocalPlayer.Character
		if char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
			local RA = char["Right Arm"]
			local att0 = Instance.new("Attachment",RA)
			att0.Orientation = Vector3.new(0, 0, 0)
			att0.Position = Vector3.new(-1.5, 0, 0)
			att0.Name = "RA"

			local att1 = Instance.new("Attachment",char["Torso"])

			local ap = Instance.new("AlignPosition",RA)
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 

			local ao = Instance.new("AlignOrientation",RA) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true
		else
			notify('Error', 'R6 Required')
		end
	end
})

local god = Others.Button({
	Text = "Godmode",
	Callback = function()
		game:GetService("Players").LocalPlayer.Character.Archivable = true 
		local real_hum = game:GetService("Players").LocalPlayer.Character
		local fake_hum = Instance.new("Model", workspace)
		local fake_human = Instance.new("Humanoid", fake_hum)
		local anim_holder = Instance.new("Model", workspace)
		anim_holder.Name = "AnimStorageTemp"
		Instance.new("Humanoid", anim_holder)

		real_hum.Animate.Parent = fake_hum
		local rig = real_hum.Humanoid.RigType
		if rig ~= Enum.HumanoidRigType.R6 then
			real_hum.Pants.Parent = fake_hum
			real_hum.Shirt.Parent = fake_hum
		end

		game:GetService("Players").LocalPlayer.Character = fake_hum
		real_hum.Humanoid.Animator.Parent = anim_holder.Humanoid
		real_hum.Humanoid:Destroy()
		wait()
		game:GetService("Players").LocalPlayer.Character = real_hum
		local new_human = Instance.new('Humanoid', game:GetService("Players").LocalPlayer.Character)
		anim_holder.Humanoid.Animator.Parent = game:GetService("Players").LocalPlayer.Character.Humanoid

		if rig ~= Enum.HumanoidRigType.R6 then
			new_human.HipHeight = 2.19
			fake_hum.Pants.Parent = real_hum
			fake_hum.Shirt.Parent = real_hum
			new_human.RigType = Enum.HumanoidRigType.R15
		end
		fake_hum.Animate.Parent = real_hum

		local Reset = Instance.new("BindableEvent")
		Reset.Event:Connect(function()
			game:GetService("StarterGui"):SetCore("ResetButtonCallback", true)
			Reset:Destroy()
			fake_human.Health = 0
			anim_holder.Humanoid.Health = 0
			new_human.Health = 0
			game:GetService("Players").LocalPlayer.Character = fake_hum
		end)
		game:GetService("StarterGui"):SetCore("ResetButtonCallback", Reset)
	end
})

local dinnerbone = Anims.Button({
	Text = "Dinnerbone",
	Callback = function()
		local plr = p
		local char = p.Character
		local NL

		NL = game:GetService("RunService").Stepped:Connect(function()
			if plr.Character ~= nil then
				for _, child in pairs(char:GetDescendants()) do
					if child:IsA("BasePart") and child.CanCollide == true then
						child.CanCollide = false
					end
				end
			end
		end)

		plr.CameraMinZoomDistance = math.huge - math.huge
		plr.CameraMaxZoomDistance = math.huge - math.huge

		spawn(function()
			plr.CharacterAdded:Wait()
			NL:Disconnect()
		end)

		if char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R15 then
			local att0 = Instance.new("Attachment",char["LowerTorso"])
			att0.Orientation = Vector3.new(-180, 180, 0)
			att0.Position = Vector3.new(0, 1, 0)
			att0.Name = "LT"

			local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

			local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 


			local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			char["LowerTorso"].Root:Destroy()
		elseif char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then

			local att0 = Instance.new("Attachment",char["Torso"])
			att0.Orientation = Vector3.new(180, 180, 0)
			att0.Position = Vector3.new(0, 0, 0)
			att0.Name = "TORSO"

			local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

			local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 


			local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			char["HumanoidRootPart"].RootJoint:Destroy()
		else
			print("wtf")
		end
	end
})