local anim_speed = 0.1


for i,v in pairs(game:GetService("Players").LocalPlayer.Character:GetChildren()) do
	if v:IsA("Accessory") then
		if v.Handle:FindFirstChild("SpecialMesh") and v.Name ~= "Hyper Realistic Noob Head" then
			v.Handle.SpecialMesh:Destroy()
		elseif v.Handle:FindFirstChild("Mesh") and v.Name ~= "Hyper Realistic Noob Head" then 
			v.Handle.Mesh:Destroy()
		end
		v.Handle.AccessoryWeld:Destroy()
	end
end

local p = game:GetService("Players").LocalPlayer
local c = p.Character

local Hats = {
	rightarm = c:WaitForChild("Hat1"),
	leftarm = c:WaitForChild("Pal Hair"),
	rightleg = c:WaitForChild("LavanderHair"),
	leftleg = c:WaitForChild("Pink Hair"),
	torso1 = c:WaitForChild("Robloxclassicred"),
	torso2 = c:WaitForChild("Kate Hair"),
	head = c:WaitForChild("Hyper Realistic Noob Head")
}

Hats.torso1.Name = "LeftTorso"
Hats.torso2.Name = "RightTorso"
Hats.rightarm.Name = "RightArm"
Hats.leftarm.Name = "LeftArm"
Hats.leftleg.Name = "LeftLeg"
Hats.rightleg.Name = "RightLeg"
Hats.head.Name = "Head "

function Joint(P1,P2,Pos,Rot)
	local AlignP = Instance.new('AlignPosition', P2);
	AlignP.ApplyAtCenterOfMass = true;
	AlignP.MaxForce = 67752;
	AlignP.MaxVelocity = math.huge/9e110;
	AlignP.ReactionForceEnabled = false;
	AlignP.Responsiveness = 200;
	AlignP.RigidityEnabled = true;
	local AlignO = Instance.new('AlignOrientation', P2);
	AlignO.MaxAngularVelocity = math.huge/9e110;
	AlignO.MaxTorque = 67752;
	AlignO.PrimaryAxisOnly = false;
	AlignO.ReactionTorqueEnabled = false;
	AlignO.Responsiveness = 200;
	AlignO.RigidityEnabled = true;
	local AttA = Instance.new('Attachment',P2);
	local AttB = Instance.new('Attachment',P1);
	AttA.Orientation = Rot
	AttA.Position = Pos
	AlignP.Attachment1 = AttA;
	AlignP.Attachment0 = AttB;
	AlignO.Attachment1 = AttA;
	AlignO.Attachment0 = AttB;
	AttA.Name = "Align" .. P1.Parent.Name
	AttB.Name = "Align" .. P1.Parent.Name
end
Joint(Hats.torso1.Handle, c["HumanoidRootPart"], Vector3.new(-0.5, -1, -2), Vector3.new(0,0,0))
Joint(Hats.torso2.Handle, Hats.torso1.Handle, Vector3.new(1,0,0), Vector3.new(0,0,0))
Joint(Hats.rightarm.Handle, Hats.torso2.Handle, Vector3.new(1, -1, -0.3), Vector3.new(90,-0,0))
Joint(Hats.leftarm.Handle, Hats.torso1.Handle, Vector3.new(-1, -1, -0.3), Vector3.new(90, 0, 0))
Joint(Hats.rightleg.Handle, Hats.torso2.Handle, Vector3.new(0.5, -0.5, 1.5), Vector3.new(40, 30, 0))
Joint(Hats.leftleg.Handle, Hats.torso1.Handle, Vector3.new(-0.5, -0.5, 1.5), Vector3.new(40, -30, 0))
Joint(Hats.head.Handle, Hats.torso1.Handle, Vector3.new(0.5, 0, -1.6), Vector3.new(-40, -0, 0))


local cpos = "Out"
local spos = 1
game:GetService("UserInputService").InputBegan:Connect(function(k, gay)
	if gay then return end
	if k.KeyCode == Enum.KeyCode.E then
		if spos == 1 then
			if cpos == "Out" then--dog
				cpos = "In"
				game:GetService("TweenService"):Create(c.HumanoidRootPart.AlignLeftTorso, TweenInfo.new(anim_speed), {['Position'] = Vector3.new(-0.5, -1, -1.5)}):Play()
			else
				cpos = "Out"
				game:GetService("TweenService"):Create(c.HumanoidRootPart.AlignLeftTorso, TweenInfo.new(anim_speed), {['Position'] = Vector3.new(-0.5, -1, -2)}):Play()
			end
		elseif spos == 2 then--69
			if cpos == "Out" then
				cpos = "In" 
				game:GetService("TweenService"):Create(Hats.torso1.Handle["AlignHead "], TweenInfo.new(anim_speed), {['Position'] = Vector3.new(0.5, -0.5, -1.6)}):Play()
			else
				cpos = "Out"
				game:GetService("TweenService"):Create(Hats.torso1.Handle["AlignHead "], TweenInfo.new(anim_speed), {['Position'] = Vector3.new(0.5, -0, -1.6)}):Play()
			end
		elseif spos == 3 then--blow
			if cpos == "Out" then
				cpos = "In" 
				game:GetService("TweenService"):Create(Hats.torso1.Handle["AlignHead "], TweenInfo.new(anim_speed), {['CFrame'] = CFrame.new(0.5, -0.200000003, -1.60000002, 1, 0, -0, 0, 0.258819073, 0.965925813, 0, -0.965925813, 0.258819073)}):Play()
			else
				cpos = "Out"
				game:GetService("TweenService"):Create(Hats.torso1.Handle["AlignHead "], TweenInfo.new(anim_speed), {['CFrame'] = CFrame.new(0.5, 0, -1.5, 1, 0, -0, 0, 0.258819073, 0.965925813, 0, -0.965925813, 0.258819073)}):Play()
			end
		end
	elseif k.KeyCode == Enum.KeyCode.Q then
		if spos == 1 or spos == 5 then--dog or neutural
			spos = 2 --become 69
			c.HumanoidRootPart.AlignLeftTorso.Position = Vector3.new(-0.5, 0.7, -1.5)
			c.HumanoidRootPart.AlignLeftTorso.Rotation = Vector3.new(-90, -0, 0)
			Hats.torso1.Handle["AlignHead "].Rotation = Vector3.new(-90, -0, 0)
			c.LeftTorso.Handle.AlignLeftLeg.CFrame = CFrame.new(-0.5, -0.5, 1.5, 0.866025388, -0.321393818, -0.383022279, 0, 0.766044557, -0.642787635, 0.5, 0.556670427, 0.663414061)
			c.RightTorso.Handle.AlignRightLeg.CFrame = CFrame.new(0.5, -0.5, 1.5, 0.866025388, 0.321393818, 0.383022279, 0, 0.766044557, -0.642787635, -0.5, 0.556670427, 0.663414061)
			c.LeftTorso.Handle.AlignLeftArm.CFrame = CFrame.new(-1, -1, -0.300000012, 1, 0, 0, 0, -4.37113883e-08, -1, 0, 1, -4.37113883e-08)
			c.RightTorso.Handle.AlignRightArm.CFrame = CFrame.new(1, -1, -0.300000012, 1, 0, 0, 0, -4.37113883e-08, -1, 0, 1, -4.37113883e-08)
			
		elseif spos == 2 then --if 69 then
			spos = 3 --turn into blowj
			c.HumanoidRootPart.AlignLeftTorso.CFrame = CFrame.new(0.5, -2.29999995, -1.79999995, -1, 1.77635684e-15, 8.74227766e-08, -8.21505353e-08, 0.342020154, -0.939692616, -2.99003524e-08, -0.939692616, -0.342020154)
			Hats.torso1.Handle["AlignHead "].CFrame = CFrame.new(0.5, 0, -1.5, 1, 0, -0, 0, 0.258819073, 0.965925813, 0, -0.965925813, 0.258819073)
			c.LeftTorso.Handle.AlignLeftLeg.CFrame = CFrame.new(-0, 1, 1, 1, 0, 0, 0, -4.37113883e-08, 1, 0, -1, -4.37113883e-08)
			c.RightTorso.Handle.AlignRightLeg.CFrame = CFrame.new(0, 1, 1, 0.98480773, 0.173648179, 7.59040297e-09, 0, -4.37113883e-08, 0.99999994, 0.173648179, -0.98480773, -4.30473115e-08)
		elseif spos == 3 then --if blow
			spos = 4 --become neutual
			c.LeftTorso.Handle["AlignHead "].CFrame = CFrame.new(0.5, -0, -1.5, 1, 0, 0, 0, -4.37113883e-08, 1, 0, -1, -4.37113883e-08)
			c.HumanoidRootPart.AlignLeftTorso.CFrame = CFrame.new(-0.5, 2, 0.5, 1, 0, 0, 0, -4.37113883e-08, -1, 0, 1, -4.37113883e-08)
			c.RightTorso.Handle.AlignRightLeg.CFrame = CFrame.new(0.5, -0.600000024, 1.60000002, 0.866025388, 0, 0.5, 0, 1, -0, -0.5, 0, 0.866025388)
			c.LeftTorso.Handle.AlignLeftLeg.CFrame = CFrame.new(-0.600000024, -0.600000024, 1.60000002, 0.866025388, 0, -0.5, 0, 1, 0, 0.5, 0, 0.866025388)
			c.LeftTorso.Handle.AlignLeftArm.CFrame = CFrame.new(-0.200000003, -0.300000012, -0, 0.766044438, 0, 0.642787576, 0, 1, -0, -0.642787576, 0, 0.766044438)
			c.RightTorso.Handle.AlignRightArm.CFrame = CFrame.new(1, -1, -0.5, 1, 0, 0, 0, -4.37113883e-08, -1, 0, 1, -4.37113883e-08)
		elseif spos == 4 then --if neutral
			spos = 1 --become dog
			Hats.torso1.Handle["AlignHead "].Position = Vector3.new(0.5, 0, -1.6)
			Hats.torso1.Handle["AlignHead "].Rotation = Vector3.new(-40, -0, 0)
			c.HumanoidRootPart.AlignLeftTorso.Position = Vector3.new(-0.5, -1, -2)
			c.HumanoidRootPart.AlignLeftTorso.Rotation = Vector3.new(-0, -0, 0)
			c.LeftTorso.Handle.AlignLeftLeg.CFrame = CFrame.new(-0.5, -0.5, 1.5, 0.866025388, -0.321393818, -0.383022279, 0, 0.766044557, -0.642787635, 0.5, 0.556670427, 0.663414061)
			c.RightTorso.Handle.AlignRightLeg.CFrame = CFrame.new(0.5, -0.5, 1.5, 0.866025388, 0.321393818, 0.383022279, 0, 0.766044557, -0.642787635, -0.5, 0.556670427, 0.663414061)
			c.LeftTorso.Handle.AlignLeftArm.CFrame = CFrame.new(-1, -1, -0.300000012, 1, 0, 0, 0, -4.37113883e-08, -1, 0, 1, -4.37113883e-08)
			c.RightTorso.Handle.AlignRightArm.CFrame = CFrame.new(1, -1, -0.300000012, 1, 0, 0, 0, -4.37113883e-08, -1, 0, 1, -4.37113883e-08)
		end
	end
end)

loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/Roblox-Scripts/main/EggRepublicIntro'))()