local UserInputService = game:GetService("UserInputService")
local p = game:GetService("Players").LocalPlayer
local mouse = p:GetMouse()
UserInputService.InputBegan:Connect(function(key)
	if key.keyCode == Enum.KeyCode.F then
	    if game:GetService('Players').LocalPlayer:GetMouse().Target == nil then 
	        return 
	    else 
	        if mouse.Target.Parent:FindFirstChild("Humanoid") then
	            local idiot = mouse.Target.Parent.Name 
	            for i = 1, 50 do
	            wait()
                local userdata_1 = game:GetService("Players")[idiot];
                local Target = game:GetService("ReplicatedStorage").meleeEvent;
                Target:FireServer(userdata_1);
                end
	        end
	    end
	end
end)