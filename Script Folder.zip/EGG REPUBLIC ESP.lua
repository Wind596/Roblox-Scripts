for i,v in pairs(game:GetService("Players"):GetPlayers()) do
	spawn(function()
		if v ~= game:GetService("Players").LocalPlayer then
			v.CharacterAdded:Connect(function()
				v.Character:WaitForChild("Humanoid").DisplayDistanceType = "None"
				v.Character.Humanoid.HealthDisplayType = "AlwaysOff"
				local BillboardGui = Instance.new("BillboardGui")
				local Frame = Instance.new("Frame")
				local TextLabel = Instance.new("TextLabel")
				local TextLabel_2 = Instance.new("TextLabel")
				local Frame_2 = Instance.new("Frame")

				BillboardGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
				BillboardGui.Active = true
				BillboardGui.AlwaysOnTop = true
				BillboardGui.LightInfluence = 1.000
				BillboardGui.Size = UDim2.new(0, 200, 0, 50)
				BillboardGui.SizeOffset = Vector2.new(0, 1)
				BillboardGui.Adornee = v.Character:WaitForChild("Head")

				Frame.Parent = BillboardGui
				Frame.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
				Frame.BackgroundTransparency = 0.400
				Frame.BorderSizePixel = 0
				Frame.Size = UDim2.new(1, 0, 1, 0)

				TextLabel.Parent = Frame
				TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
				TextLabel.BackgroundTransparency = 1.000
				TextLabel.BorderSizePixel = 0
				TextLabel.Size = UDim2.new(1, 0, 0.5, 0)
				TextLabel.Font = Enum.Font.GothamBold
				TextLabel.Text = v.Name
				TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
				TextLabel.TextSize = 20.000
				TextLabel.TextXAlignment = Enum.TextXAlignment.Left
				TextLabel.TextYAlignment = Enum.TextYAlignment.Top

				TextLabel_2.Parent = Frame
				TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
				TextLabel_2.BackgroundTransparency = 1.000
				TextLabel_2.BorderSizePixel = 0
				TextLabel_2.Position = UDim2.new(0, 0, 0.5, 0)
				TextLabel_2.Size = UDim2.new(1, 0, 0.5, 0)
				TextLabel_2.Font = Enum.Font.GothamBold
				TextLabel_2.Text = "HEALTH : " .. v.Character.Humanoid.Health
				TextLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
				TextLabel_2.TextSize = 20.000
				TextLabel_2.TextXAlignment = Enum.TextXAlignment.Left
				TextLabel_2.TextYAlignment = Enum.TextYAlignment.Top

				Frame_2.Parent = Frame
				Frame_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
				Frame_2.BorderSizePixel = 0
				Frame_2.Position = UDim2.new(0, 0, 0.949999988, 0)
				Frame_2.Size = UDim2.new(1, 0, 0.0399999991, 0)
				spawn(function()
					while v.Character ~= nil do
						if v.Team ~= nil then Frame_2.BackgroundColor3 = v.Team.TeamColor.Color end
						pcall(function() TextLabel_2.Text = "HEALTH : " .. v.Character:FindFirstChildOfClass("Humanoid").Health end)
						wait()
					end
				end)
			end)
			if v.Character ~= nil then
				v.Character:WaitForChild("Humanoid").DisplayDistanceType = "None"
				v.Character.Humanoid.HealthDisplayType = "AlwaysOff"
				local BillboardGui = Instance.new("BillboardGui")
				local Frame = Instance.new("Frame")
				local TextLabel = Instance.new("TextLabel")
				local TextLabel_2 = Instance.new("TextLabel")
				local Frame_2 = Instance.new("Frame")

				BillboardGui.Parent = v.Character:WaitForChild("Head")
				BillboardGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
				BillboardGui.Active = true
				BillboardGui.AlwaysOnTop = true
				BillboardGui.LightInfluence = 1.000
				BillboardGui.Size = UDim2.new(0, 200, 0, 50)
				BillboardGui.SizeOffset = Vector2.new(0, 1)

				Frame.Parent = BillboardGui
				Frame.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
				Frame.BackgroundTransparency = 0.400
				Frame.BorderSizePixel = 0
				Frame.Size = UDim2.new(1, 0, 1, 0)

				TextLabel.Parent = Frame
				TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
				TextLabel.BackgroundTransparency = 1.000
				TextLabel.BorderSizePixel = 0
				TextLabel.Size = UDim2.new(1, 0, 0.5, 0)
				TextLabel.Font = Enum.Font.GothamBold
				TextLabel.Text = v.Name
				TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
				TextLabel.TextSize = 20.000
				TextLabel.TextXAlignment = Enum.TextXAlignment.Left
				TextLabel.TextYAlignment = Enum.TextYAlignment.Top

				TextLabel_2.Parent = Frame
				TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
				TextLabel_2.BackgroundTransparency = 1.000
				TextLabel_2.BorderSizePixel = 0
				TextLabel_2.Position = UDim2.new(0, 0, 0.5, 0)
				TextLabel_2.Size = UDim2.new(1, 0, 0.5, 0)
				TextLabel_2.Font = Enum.Font.GothamBold
				TextLabel_2.Text = "HEALTH : " .. v.Character.Humanoid.Health
				TextLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
				TextLabel_2.TextSize = 20.000
				TextLabel_2.TextXAlignment = Enum.TextXAlignment.Left
				TextLabel_2.TextYAlignment = Enum.TextYAlignment.Top

				Frame_2.Parent = Frame
				Frame_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
				Frame_2.BorderSizePixel = 0
				Frame_2.Position = UDim2.new(0, 0, 0.949999988, 0)
				Frame_2.Size = UDim2.new(1, 0, 0.0399999991, 0)
				spawn(function()
					while v.Character ~= nil do
						if v.Team ~= nil then Frame_2.BackgroundColor3 = v.Team.TeamColor.Color end
						pcall(function() TextLabel_2.Text = "HEALTH : " .. v.Character:FindFirstChildOfClass("Humanoid").Health end)
						wait()
					end
				end)
			end
		end
	end)
end

game:GetService("Players").PlayerAdded:Connect(function(v)
	v.CharacterAdded:Connect(function()
		v.Character:WaitForChild("Humanoid").DisplayDistanceType = "None"
		v.Character.Humanoid.HealthDisplayType = "AlwaysOff"
		local BillboardGui = Instance.new("BillboardGui")
		local Frame = Instance.new("Frame")
		local TextLabel = Instance.new("TextLabel")
		local TextLabel_2 = Instance.new("TextLabel")
		local Frame_2 = Instance.new("Frame")

		BillboardGui.Parent = v.Character:WaitForChild("Head")
		BillboardGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		BillboardGui.Active = true
		BillboardGui.AlwaysOnTop = true
		BillboardGui.LightInfluence = 1.000
		BillboardGui.Size = UDim2.new(0, 200, 0, 50)
		BillboardGui.SizeOffset = Vector2.new(0, 1)
		BillboardGui.Adornee = v.Character:WaitForChild("Head")

		Frame.Parent = BillboardGui
		Frame.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
		Frame.BackgroundTransparency = 0.400
		Frame.BorderSizePixel = 0
		Frame.Size = UDim2.new(1, 0, 1, 0)

		TextLabel.Parent = Frame
		TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel.BackgroundTransparency = 1.000
		TextLabel.BorderSizePixel = 0
		TextLabel.Size = UDim2.new(1, 0, 0.5, 0)
		TextLabel.Font = Enum.Font.GothamBold
		TextLabel.Text = v.Name
		TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel.TextSize = 20.000
		TextLabel.TextXAlignment = Enum.TextXAlignment.Left
		TextLabel.TextYAlignment = Enum.TextYAlignment.Top

		TextLabel_2.Parent = Frame
		TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel_2.BackgroundTransparency = 1.000
		TextLabel_2.BorderSizePixel = 0
		TextLabel_2.Position = UDim2.new(0, 0, 0.5, 0)
		TextLabel_2.Size = UDim2.new(1, 0, 0.5, 0)
		TextLabel_2.Font = Enum.Font.GothamBold
		TextLabel_2.Text = "HEALTH : " .. v.Character.Humanoid.Health
		TextLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel_2.TextSize = 20.000
		TextLabel_2.TextXAlignment = Enum.TextXAlignment.Left
		TextLabel_2.TextYAlignment = Enum.TextYAlignment.Top

		Frame_2.Parent = Frame
		Frame_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
		Frame_2.BorderSizePixel = 0
		Frame_2.Position = UDim2.new(0, 0, 0.949999988, 0)
		Frame_2.Size = UDim2.new(1, 0, 0.0399999991, 0)
		spawn(function()
			while v.Character ~= nil do
				if v.Team ~= nil then Frame_2.BackgroundColor3 = v.Team.TeamColor.Color end
				pcall(function() TextLabel_2.Text = "HEALTH : " .. v.Character:FindFirstChildOfClass("Humanoid").Health end)
				wait()
			end
		end)
	end)
	if v.Character ~= nil then
		v.Character:WaitForChild("Humanoid").DisplayDistanceType = "None"
		v.Character.Humanoid.HealthDisplayType = "AlwaysOff"
		local BillboardGui = Instance.new("BillboardGui")
		local Frame = Instance.new("Frame")
		local TextLabel = Instance.new("TextLabel")
		local TextLabel_2 = Instance.new("TextLabel")
		local Frame_2 = Instance.new("Frame")

		BillboardGui.Parent = v.Character:WaitForChild("Head")
		BillboardGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		BillboardGui.Active = true
		BillboardGui.AlwaysOnTop = true
		BillboardGui.LightInfluence = 1.000
		BillboardGui.Size = UDim2.new(0, 200, 0, 50)
		BillboardGui.SizeOffset = Vector2.new(0, 1)

		Frame.Parent = BillboardGui
		Frame.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
		Frame.BackgroundTransparency = 0.400
		Frame.BorderSizePixel = 0
		Frame.Size = UDim2.new(1, 0, 1, 0)

		TextLabel.Parent = Frame
		TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel.BackgroundTransparency = 1.000
		TextLabel.BorderSizePixel = 0
		TextLabel.Size = UDim2.new(1, 0, 0.5, 0)
		TextLabel.Font = Enum.Font.GothamBold
		TextLabel.Text = v.Name
		TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel.TextSize = 20.000
		TextLabel.TextXAlignment = Enum.TextXAlignment.Left
		TextLabel.TextYAlignment = Enum.TextYAlignment.Top

		TextLabel_2.Parent = Frame
		TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel_2.BackgroundTransparency = 1.000
		TextLabel_2.BorderSizePixel = 0
		TextLabel_2.Position = UDim2.new(0, 0, 0.5, 0)
		TextLabel_2.Size = UDim2.new(1, 0, 0.5, 0)
		TextLabel_2.Font = Enum.Font.GothamBold
		TextLabel_2.Text = "HEALTH : " .. v.Character.Humanoid.Health
		TextLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel_2.TextSize = 20.000
		TextLabel_2.TextXAlignment = Enum.TextXAlignment.Left
		TextLabel_2.TextYAlignment = Enum.TextYAlignment.Top

		Frame_2.Parent = Frame
		Frame_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
		Frame_2.BorderSizePixel = 0
		Frame_2.Position = UDim2.new(0, 0, 0.949999988, 0)
		Frame_2.Size = UDim2.new(1, 0, 0.0399999991, 0)
		spawn(function()
			while v.Character ~= nil do
				if v.Team ~= nil then Frame_2.BackgroundColor3 = v.Team.TeamColor.Color end
				pcall(function() TextLabel_2.Text = "HEALTH : " .. v.Character:FindFirstChildOfClass("Humanoid").Health end)
				wait()
			end
		end)
	end
end)
local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local UICorner = Instance.new("UICorner")
local TextLabel = Instance.new("TextLabel")

ScreenGui.Parent = game:GetService("CoreGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
Frame.BackgroundTransparency = 0.300
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.269, 0,1, 0)
Frame.Size = UDim2.new(0.463, 0,0.084, 0)

UICorner.CornerRadius = UDim.new(0, 4)
UICorner.Parent = Frame

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderSizePixel = 0
TextLabel.Size = UDim2.new(1, 0, 1, 0)
TextLabel.Font = Enum.Font.GothamBold
TextLabel.Text = "EGG REPUBLIC\nSCRIPT LOADED"
TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.TextSize = 16.000
TextLabel.TextWrapped = true

wait(0.5)
Frame:TweenPosition(UDim2.new(0.269, 0,0.86, 0), nil, nil, 0.3)
wait(0.8)
game:GetService("TweenService"):Create(TextLabel, TweenInfo.new(0.3), {['TextTransparency'] = 1}):Play()
wait(0.4)
TextLabel.Text = "ENJOY"
game:GetService("TweenService"):Create(TextLabel, TweenInfo.new(0.3), {['TextTransparency'] = 0}):Play()
wait(0.8)
Frame:TweenPosition(UDim2.new(0.269, 0,1, 0), nil, nil, 0.3)
wait(0.3)
ScreenGui:Destroy()