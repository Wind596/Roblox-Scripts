game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = workspace.Flags.FlagRed.Base.CFrame
wait()
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30.4912052, 3.39999914, 177.779282, -0.00523910858, -1.39078651e-07, -0.999986291, 3.34173855e-10, 1, -1.39082317e-07, 0.999986291, -1.0628366e-09, -0.00523910858)
wait()
game:GetService("TweenService"):Create(game:GetService("Players").LocalPlayer.Character.HumanoidRootPart, TweenInfo.new(10), {['CFrame'] = CFrame.new(23.1049519, 3.4000001, -186.799561, -0.635843575, 5.70488226e-08, 0.771817923, 1.31173206e-08, 1, -6.31084802e-08, -0.771817923, -3.00029406e-08, -0.635843575)}):Play()
wait(10)
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = workspace.Flags.FlagBlue.Base.CFrame