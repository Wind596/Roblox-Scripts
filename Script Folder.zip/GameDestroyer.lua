local StarNebula = Instance.new("ScreenGui")
local Main = Instance.new("Frame")
local Shadow = Instance.new("Folder")
local Frame = Instance.new("Frame")
local mainFrame = Instance.new("ImageLabel")
local topbarFrame = Instance.new("ImageLabel")
local TextLabel = Instance.new("TextLabel")
local ScrollingFrame = Instance.new("ScrollingFrame")
local PlaceHolder = Instance.new("TextButton")
local UICorner = Instance.new("UICorner")
local UIListLayout = Instance.new("UIListLayout")
local R6 = Instance.new("TextButton")
local UICorner_2 = Instance.new("UICorner")
local R6_2 = Instance.new("TextButton")
local UICorner_3 = Instance.new("UICorner")
local R6_3 = Instance.new("TextButton")
local UICorner_4 = Instance.new("UICorner")
local R6_4 = Instance.new("TextButton")
local UICorner_5 = Instance.new("UICorner")
local R6_5 = Instance.new("TextButton")
local UICorner_6 = Instance.new("UICorner")
local R6_6 = Instance.new("TextButton")
local UICorner_7 = Instance.new("UICorner")
local R6_7 = Instance.new("TextButton")
local UICorner_8 = Instance.new("UICorner")
local R6_8 = Instance.new("TextButton")
local UICorner_9 = Instance.new("UICorner")
local R6_9 = Instance.new("TextButton")
local UICorner_10 = Instance.new("UICorner")

StarNebula.Name = "Star Nebula"
StarNebula.Parent = game:GetService("CoreGui")
StarNebula.ResetOnSpawn = false

Main.Name = "Main"
Main.Parent = StarNebula
Main.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Main.BackgroundTransparency = 1.000
Main.BorderSizePixel = 0
Main.Position = UDim2.new(0.616363645, -294, 0.598280072, -149)
Main.Size = UDim2.new(0, 267, 0, 170)

Shadow.Name = "Shadow"
Shadow.Parent = Main

Frame.Parent = Shadow
Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0, -4, 0, -4)
Frame.Size = UDim2.new(1, 8, 1, 8)
Frame.Style = Enum.FrameStyle.DropShadow

mainFrame.Name = "mainFrame"
mainFrame.Parent = Main
mainFrame.BackgroundColor3 = Color3.fromRGB(32, 32, 32)
mainFrame.BackgroundTransparency = 1.000
mainFrame.BorderSizePixel = 0
mainFrame.ClipsDescendants = true
mainFrame.Position = UDim2.new(-0.000796778651, 0, -0.00258674752, 0)
mainFrame.Size = UDim2.new(0, 264, 0, 168)
mainFrame.Image = "http://www.roblox.com/asset/?id=4530318781"
mainFrame.ImageColor3 = Color3.fromRGB(32, 32, 32)
mainFrame.ScaleType = Enum.ScaleType.Slice
mainFrame.SliceCenter = Rect.new(20, 20, 480, 480)

topbarFrame.Name = "topbarFrame"
topbarFrame.Parent = mainFrame
topbarFrame.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
topbarFrame.BackgroundTransparency = 1.000
topbarFrame.BorderSizePixel = 0
topbarFrame.Size = UDim2.new(0, 264, 0, 33)
topbarFrame.Image = "http://www.roblox.com/asset/?id=4530319192"
topbarFrame.ImageColor3 = Color3.fromRGB(24, 24, 24)
topbarFrame.ScaleType = Enum.ScaleType.Slice
topbarFrame.SliceCenter = Rect.new(20, 20, 480, 480)

TextLabel.Parent = topbarFrame
TextLabel.BackgroundColor3 = Color3.fromRGB(154, 154, 154)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0.0679237992, 0, 0.24242425, 0)
TextLabel.Size = UDim2.new(0, 228, 0, 16)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "Star Nebula  v1.1| Game Destroyer"
TextLabel.TextColor3 = Color3.fromRGB(189, 189, 189)
TextLabel.TextSize = 12.000

ScrollingFrame.Parent = mainFrame
ScrollingFrame.Active = true
ScrollingFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ScrollingFrame.BackgroundTransparency = 1.000
ScrollingFrame.BorderSizePixel = 0
ScrollingFrame.Position = UDim2.new(0, 0, 0.202380955, 0)
ScrollingFrame.Size = UDim2.new(0, 264, 0, 134)
ScrollingFrame.CanvasSize = UDim2.new(0, 0, 1.35000002, 0)

PlaceHolder.Name = "PlaceHolder"
PlaceHolder.Parent = ScrollingFrame
PlaceHolder.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
PlaceHolder.BackgroundTransparency = 1.000
PlaceHolder.Position = UDim2.new(0.0359848477, 0, 0, 0)
PlaceHolder.Size = UDim2.new(0, 245, 0, 13)
PlaceHolder.Font = Enum.Font.SourceSans
PlaceHolder.Text = ""
PlaceHolder.TextColor3 = Color3.fromRGB(255, 255, 255)
PlaceHolder.TextSize = 14.000

UICorner.Parent = PlaceHolder

UIListLayout.Parent = ScrollingFrame
UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
UIListLayout.Padding = UDim.new(0.00999999978, 0)

R6.Name = "R6"
R6.Parent = ScrollingFrame
R6.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
R6.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
R6.Size = UDim2.new(0, 245, 0, 21)
R6.Font = Enum.Font.SourceSans
R6.Text = "Shutdown"
R6.TextColor3 = Color3.fromRGB(255, 255, 255)
R6.TextSize = 14.000

UICorner_2.Parent = R6

R6_2.Name = "R6"
R6_2.Parent = ScrollingFrame
R6_2.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
R6_2.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
R6_2.Size = UDim2.new(0, 245, 0, 21)
R6_2.Font = Enum.Font.SourceSans
R6_2.Text = "Crash Server"
R6_2.TextColor3 = Color3.fromRGB(255, 255, 255)
R6_2.TextSize = 14.000

UICorner_3.Parent = R6_2

R6_3.Name = "R6"
R6_3.Parent = ScrollingFrame
R6_3.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
R6_3.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
R6_3.Size = UDim2.new(0, 245, 0, 21)
R6_3.Font = Enum.Font.SourceSans
R6_3.Text = "Break Server"
R6_3.TextColor3 = Color3.fromRGB(255, 255, 255)
R6_3.TextSize = 14.000

UICorner_4.Parent = R6_3

R6_4.Name = "R6"
R6_4.Parent = ScrollingFrame
R6_4.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
R6_4.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
R6_4.Size = UDim2.new(0, 245, 0, 21)
R6_4.Font = Enum.Font.SourceSans
R6_4.Text = "Anti Ban"
R6_4.TextColor3 = Color3.fromRGB(255, 255, 255)
R6_4.TextSize = 14.000

UICorner_5.Parent = R6_4

R6_5.Name = "R6"
R6_5.Parent = ScrollingFrame
R6_5.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
R6_5.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
R6_5.Size = UDim2.new(0, 245, 0, 21)
R6_5.Font = Enum.Font.SourceSans
R6_5.Text = "Break HD Admin"
R6_5.TextColor3 = Color3.fromRGB(255, 255, 255)
R6_5.TextSize = 14.000

UICorner_6.Parent = R6_5

R6_6.Name = "R6"
R6_6.Parent = ScrollingFrame
R6_6.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
R6_6.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
R6_6.Size = UDim2.new(0, 245, 0, 21)
R6_6.Font = Enum.Font.SourceSans
R6_6.Text = "Kill All"
R6_6.TextColor3 = Color3.fromRGB(255, 255, 255)
R6_6.TextSize = 14.000

UICorner_7.Parent = R6_6

R6_7.Name = "R6"
R6_7.Parent = ScrollingFrame
R6_7.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
R6_7.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
R6_7.Size = UDim2.new(0, 245, 0, 21)
R6_7.Font = Enum.Font.SourceSans
R6_7.Text = "Destroy"
R6_7.TextColor3 = Color3.fromRGB(255, 255, 255)
R6_7.TextSize = 14.000

UICorner_8.Parent = R6_7

R6_8.Name = "R6"
R6_8.Parent = ScrollingFrame
R6_8.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
R6_8.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
R6_8.Size = UDim2.new(0, 245, 0, 21)
R6_8.Font = Enum.Font.SourceSans
R6_8.Text = "Demon"
R6_8.TextColor3 = Color3.fromRGB(255, 255, 255)
R6_8.TextSize = 14.000

UICorner_9.Parent = R6_8

R6_9.Name = "R6"
R6_9.Parent = ScrollingFrame
R6_9.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
R6_9.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
R6_9.Size = UDim2.new(0, 245, 0, 21)
R6_9.Font = Enum.Font.SourceSans
R6_9.Text = "Destroy Scripts"
R6_9.TextColor3 = Color3.fromRGB(255, 255, 255)
R6_9.TextSize = 14.000

UICorner_10.Parent = R6_9

-- Scripts:

local function SYBTR_fake_script() -- R6.LocalScript 
	local script = Instance.new('LocalScript', R6)

	script.Parent.MouseButton1Click:Connect(function()
		if game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser") then
			game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser"):FireServer("Shutdown", "ko badddddddddddddddddd")
		end
	end)
end
coroutine.wrap(SYBTR_fake_script)()
local function TRODKAT_fake_script() -- R6_2.LocalScript 
	local script = Instance.new('LocalScript', R6_2)

	script.Parent.MouseButton1Click:Connect(function()
		if game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser") then
			game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser"):FireServer("Crash", "ko badddddddddddddddddd")
		end
	end)
end
coroutine.wrap(TRODKAT_fake_script)()
local function TMDHAD_fake_script() -- R6_3.LocalScript 
	local script = Instance.new('LocalScript', R6_3)

	script.Parent.MouseButton1Click:Connect(function()
		if game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser") then
			game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser"):FireServer("BreakServer", "ko badddddddddddddddddd")
		end
	end)
end
coroutine.wrap(TMDHAD_fake_script)()
local function YSOOWHI_fake_script() -- R6_4.LocalScript 
	local script = Instance.new('LocalScript', R6_4)

	script.Parent.MouseButton1Click:Connect(function()
		if game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser") then
			game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser"):FireServer("antiban", "ko badddddddddddddddddd")
		end
	end)
end
coroutine.wrap(YSOOWHI_fake_script)()
local function FAGHYX_fake_script() -- R6_5.LocalScript 
	local script = Instance.new('LocalScript', R6_5)

	script.Parent.MouseButton1Click:Connect(function()
		if game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser") then
			game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser"):FireServer("hdadmin", "ko badddddddddddddddddd")
		end
	end)
end
coroutine.wrap(FAGHYX_fake_script)()
local function IVUGU_fake_script() -- R6_6.LocalScript 
	local script = Instance.new('LocalScript', R6_6)

	script.Parent.MouseButton1Click:Connect(function()
		if game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser") then
			game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser"):FireServer("kill", "ko badddddddddddddddddd")
		end
	end)
end
coroutine.wrap(IVUGU_fake_script)()
local function STFXC_fake_script() -- R6_7.LocalScript 
	local script = Instance.new('LocalScript', R6_7)

	script.Parent.MouseButton1Click:Connect(function()
		if game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser") then
			game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser"):FireServer("destroy", "ko badddddddddddddddddd")
		end
	end)
end
coroutine.wrap(STFXC_fake_script)()
local function NRKKQB_fake_script() -- R6_8.LocalScript 
	local script = Instance.new('LocalScript', R6_8)

	script.Parent.MouseButton1Click:Connect(function()
		if game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser") then
			game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser"):FireServer("demon", "ko badddddddddddddddddd")
		end
	end)
end
coroutine.wrap(NRKKQB_fake_script)()
local function BZFNON_fake_script() -- R6_9.LocalScript 
	local script = Instance.new('LocalScript', R6_9)

	script.Parent.MouseButton1Click:Connect(function()
		if game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser") then
			game:GetService("ReplicatedStorage"):FindFirstChild("HD Admin Command Parser"):FireServer("breakscripts", "ko badddddddddddddddddd")
		end
	end)
end
coroutine.wrap(BZFNON_fake_script)()

local L_1_ = game:GetService("UserInputService")
function drag(L_2_arg1)
	dragToggle = nil
	local dragSpeed = 0.23
	dragInput = nil
	dragStart = nil
	local dragPos = nil
	function updateInput(L_3_arg1)
		local Delta = L_3_arg1.Position - dragStart
		local Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
		game:GetService("TweenService"):Create(L_2_arg1, TweenInfo.new(0.25), {
			Position = Position
		}):Play()
	end
	L_2_arg1.InputBegan:Connect(function(L_4_arg1)
		if (L_4_arg1.UserInputType == Enum.UserInputType.MouseButton1 or L_4_arg1.UserInputType == Enum.UserInputType.Touch) and L_1_:GetFocusedTextBox() == nil then
			dragToggle = true
			dragStart = L_4_arg1.Position
			startPos = L_2_arg1.Position
			L_4_arg1.Changed:Connect(function()
				if L_4_arg1.UserInputState == Enum.UserInputState.End then
					dragToggle = false
				end
			end)
		end
	end)
	L_2_arg1.InputChanged:Connect(function(L_5_arg1)
		if L_5_arg1.UserInputType == Enum.UserInputType.MouseMovement or L_5_arg1.UserInputType == Enum.UserInputType.Touch then
			dragInput = L_5_arg1
		end
	end)
	game:GetService("UserInputService").InputChanged:Connect(function(L_6_arg1)
		if L_6_arg1 == dragInput and dragToggle then
			updateInput(L_6_arg1)
		end
	end)
end
drag(Main)