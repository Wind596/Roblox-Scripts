loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/V2.5.lua'))()
local c = game:GetService("Players").LocalPlayer.Character.Rig
local api = loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/RbxUtil/main/Util.lua'))()
		local root = c:WaitForChild("HumanoidRootPart")
		local BillboardGui = Instance.new("BillboardGui")
		local TextLabel = Instance.new("TextLabel")

		BillboardGui.Parent = c.Head
		BillboardGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		BillboardGui.Active = true
		BillboardGui.Size = UDim2.new(0, 200, 0, 50)
		BillboardGui.StudsOffset = Vector3.new(0, 2, 0)
		BillboardGui.ClipsDescendants = false

		TextLabel.Parent = BillboardGui
		TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel.BackgroundTransparency = 1.000
		TextLabel.BorderSizePixel = 0
		TextLabel.Size = UDim2.new(0, 200, 0, 50)
		TextLabel.Font = Enum.Font.SourceSans
		TextLabel.Text = "HYPER"
		TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel.TextScaled = true
		TextLabel.TextSize = 14.000
		TextLabel.TextWrapped = true
		
		local FONTS = {
			Enum.Font.Antique,
			Enum.Font.Arcade,
			Enum.Font.Arial,
			Enum.Font.ArialBold,
			Enum.Font.Bodoni,
			Enum.Font.Cartoon,
			Enum.Font.Code,
			Enum.Font.Fantasy,
			Enum.Font.Garamond,
			Enum.Font.Highway,
			Enum.Font.Legacy,
			Enum.Font.SciFi,
			Enum.Font.SourceSans,
			Enum.Font.SourceSansBold,
			Enum.Font.SourceSansItalic,
			Enum.Font.SourceSansLight,
			Enum.Font.SourceSansSemibold,
			Enum.Font.DenkOne
		}
		
		spawn(function()
			while true do
				wait(0.1)
				TextLabel.Font = FONTS[math.random(1, #FONTS)]
			end
		end)
		
		local bg = Instance.new("Sound", c.Head)
		bg.SoundId = "rbxassetid://6372629332"
		bg.Volume = 10
		bg.Looped = true
		bg:Play()
		
		c.Humanoid.WalkSpeed = 90
		
		local head = api.Weld(root, c.Head, CFrame.new(-0.10118866, 2.40733576, 0.666854858, 0.847901583, -0.0884377882, 0.522724748, 0.142229557, 0.987789154, -0.0635872111, -0.510718465, 0.128262728, 0.850126505))
		local la = api.Weld(root, c["Left Arm"], CFrame.new(-0.786773682, 1.42581272, -0.480957031, 0.491193652, -0.866390347, 0.0899741277, -0.0633096099, -0.138530701, -0.988331735, 0.868746161, 0.479766011, -0.122896045))
		local ll = api.Weld(root, c["Left Leg"], CFrame.new(-0.478805542, -0.848095894, -0.492553711, 0.957606554, 7.45057971e-09, 0.288079292, 0.11975684, 0.909498036, -0.398084581, -0.262007594, 0.415707827, 0.870941401))
		local ra = api.Weld(root, c["Right Arm"], CFrame.new(0.123527527, 1.74476385, -0.476921082, 0.00364616513, 0.998803258, -0.0487316847, 0.557556927, -0.0424836092, -0.829049289, -0.830129862, -0.0241493285, -0.557044923))
		local rl = api.Weld(root, c["Right Leg"], CFrame.new( 0.575309753, -0.8205688, -0.444038391, 0.957606494, -0.0385346562, 0.285490394, 0.119756848, 0.95457375, -0.272848725, -0.262007594, 0.295471013, 0.918721199))
		local t = api.Weld(root, c.Torso, CFrame.new(0, 1.03077888, 0.207855225, 0.957606554, 7.4505806e-09, 0.288079292, 0.11975684, 0.909498155, -0.398084581, -0.262007594, 0.415707886, 0.870941401))
		spawn(function()
			while true do
				local torvel = (root.Velocity * Vector3.new(1, 0, 1)).magnitude
				if torvel > 1 then --Moving
					for i=0,1, .05 do
						head.C0 = head.C0:Lerp(CFrame.new(-0.0565338135, 3.05557251, -2.02365875, 0.989870548, -0.0999596417, -0.1008185, 0.11663828, 0.977441251, 0.176079944, 0.0809432566, -0.186055645, 0.97919935), i)
						la.C0 = la.C0:Lerp(CFrame.new(-1.70578003, 2.3983984, -1.68082428, 0.991710961, -0.0685321689, 0.10862793, 0.0970674604, -0.153945953, -0.983290613, 0.08411026, 0.98569119, -0.146017238), i)
						ll.C0 = ll.C0:Lerp(CFrame.new(-0.856086731, 2.01151896, 1.48569489, 0.989537716, 0.0600748882, -0.131171972, 0.119756833, 0.1650078, 0.97899437, 0.0804574192, -0.984460294, 0.156087056), i)
						ra.C0 = ra.C0:Lerp(CFrame.new(1.25178528, 2.53171492, -0.379188538, -0.0211888365, 0.0388493538, -0.999020576, 0.989304781, 0.14505586, -0.015341904, 0.144317821, -0.988660812, -0.0415074527), i)
						rl.C0 = rl.C0:Lerp(CFrame.new(0.0922393799, 2.4666748, 1.57393646, 0.989537656, 0.0770811439, -0.121957265, 0.119756803, 0.0325705111, 0.992268443, 0.0804573894, -0.996491849, 0.022998713), i)
						t.C0 = t.C0:Lerp(CFrame.new(-0.241165161, 2.40141296, -0.443000793, 0.989537716, 0.0600748956, -0.131171972, 0.119756833, 0.165007815, 0.97899437, 0.0804574192, -0.984460413, 0.156087056), i)
						game:GetService("RunService").Heartbeat:Wait()
					end	
				else --Idle
					for i=0,1, .05 do
						head.C0 = head.C0:Lerp(CFrame.new(-0.10118866, 2.40733576, 0.666854858, 0.847901583, -0.0884377882, 0.522724748, 0.142229557, 0.987789154, -0.0635872111, -0.510718465, 0.128262728, 0.850126505), i)
						la.C0 = la.C0:Lerp(CFrame.new(-0.786773682, 1.42581272, -0.480957031, 0.491193652, -0.866390347, 0.0899741277, -0.0633096099, -0.138530701, -0.988331735, 0.868746161, 0.479766011, -0.122896045), i)
						ll.C0 = ll.C0:Lerp(CFrame.new(-0.478805542, -0.848095894, -0.492553711, 0.957606554, 7.45057971e-09, 0.288079292, 0.11975684, 0.909498036, -0.398084581, -0.262007594, 0.415707827, 0.870941401), i)
						ra.C0 = ra.C0:Lerp(CFrame.new(0.123527527, 1.74476385, -0.476921082, 0.00364616513, 0.998803258, -0.0487316847, 0.557556927, -0.0424836092, -0.829049289, -0.830129862, -0.0241493285, -0.557044923), i)
						rl.C0 = rl.C0:Lerp(CFrame.new( 0.575309753, -0.8205688, -0.444038391, 0.957606494, -0.0385346562, 0.285490394, 0.119756848, 0.95457375, -0.272848725, -0.262007594, 0.295471013, 0.918721199), i)
						t.C0 = t.C0:Lerp(CFrame.new(0, 1.03077888, 0.207855225, 0.957606554, 7.4505806e-09, 0.288079292, 0.11975684, 0.909498155, -0.398084581, -0.262007594, 0.415707886, 0.870941401), i)
						game:GetService("RunService").Heartbeat:Wait()
					end
				end
			end
		end)