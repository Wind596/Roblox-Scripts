local SECURE_LOAD = "8881"
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Execute = function(...)
        local Arguments = {...}
        return function() ReplicatedStorage.ExecuteString:InvokeServer(SECURE_LOAD, unpack(Arguments)) end
end
local Player = game:GetService("Players").napcat90.Name

Execute('game.SoundService.Music.SoundId = "rbxassetid://5278472153"')()

--[[
        Require scripts
        
        require(4852705087).load(Player) --Cop
        
        require(3029655569):Fire(Player) --Grab knife v4
        
        require(3023102224)(Player)  --IY Admin
        
        require(03124362032) -- KFC mcdonalds thing
        
        require(4765981314).JOJOulti(Player) --Jojo
        
        require(4613126715)(3720592397).killbot(Player) --Killbot
        
        require(4666298879).load(Player) --Trap Gun
        
        require(4442010059).load(Player) --Dunstep gun
        
        require(5617200606).Cyber(Player) --Cyber night
        
        require(4660235055).load(Player) --Dual Sword
]]