if not game:IsLoaded() then
	game.Loaded:Wait()
end
if game:GetService("ReplicatedStorage"):FindFirstChild("ExecuteString") then
local NapClient = Instance.new("ScreenGui")
local Main = Instance.new("ImageLabel")
local Kick = Instance.new("TextButton")
local UICorner = Instance.new("UICorner")
local Punish = Instance.new("TextButton")
local UICorner_2 = Instance.new("UICorner")
local Cdestroy = Instance.new("TextButton")
local UICorner_3 = Instance.new("UICorner")
local Warn = Instance.new("TextButton")
local UICorner_4 = Instance.new("UICorner")
local Freeze = Instance.new("TextButton")
local UICorner_5 = Instance.new("UICorner")
local Ban = Instance.new("TextButton")
local UICorner_6 = Instance.new("UICorner")
local Logo = Instance.new("TextLabel")
local UICorner_7 = Instance.new("UICorner")
local Client = Instance.new("TextBox")
local UICorner_8 = Instance.new("UICorner")
local Close = Instance.new("TextButton")
local UICorner_9 = Instance.new("UICorner")
local Crash = Instance.new("TextButton")
local UICorner_10 = Instance.new("UICorner")
local Kill = Instance.new("TextButton")
local UICorner_11 = Instance.new("UICorner")
local Moreb = Instance.new("TextButton")
local UICorner_12 = Instance.new("UICorner")
local More = Instance.new("ImageLabel")
local Back = Instance.new("TextButton")
local UICorner_13 = Instance.new("UICorner")
local jojo = Instance.new("TextButton")
local UICorner_14 = Instance.new("UICorner")
local R6 = Instance.new("TextButton")
local UICorner_15 = Instance.new("UICorner")
local knife = Instance.new("TextButton")
local UICorner_16 = Instance.new("UICorner")
local rs = Instance.new("TextButton")
local UICorner_17 = Instance.new("UICorner")
local ss = Instance.new("TextButton")
local UICorner_18 = Instance.new("UICorner")
local ds = Instance.new("TextButton")
local UICorner_19 = Instance.new("UICorner")
local ts = Instance.new("TextButton")
local UICorner_20 = Instance.new("UICorner")
local test = Instance.new("TextButton")
local UICorner_21 = Instance.new("UICorner")
local Close_2 = Instance.new("TextLabel")
local UICorner_22 = Instance.new("UICorner")
local open = Instance.new("TextButton")
local UICorner_23 = Instance.new("UICorner")
local Target = nil
local p = game:GetService("Players").LocalPlayer

local SECURE_LOAD = "8881"
local ReplicatedStorage = game:GetService("ReplicatedStorage")

function Execute(args, player)
	ReplicatedStorage.Command:FireServer(args, player, "8881")
end

local Run = function(...)
    local Arguments = {...}
    return function() ReplicatedStorage.ExecuteString:InvokeServer(SECURE_LOAD, unpack(Arguments)) end
end

function findroot(char)
	local rootPart = char:FindFirstChild('HumanoidRootPart') or char:FindFirstChild('Torso') or char:FindFirstChild('UpperTorso')
	return rootPart
end

local function RemoveSpaces(name)
	return name:gsub('%s+', '') or name
end
local function findplayer(name)
	name = RemoveSpaces(name)
	for i, player in pairs(game:GetService('Players'):GetPlayers()) do
		if player.Name:lower():match('^'.. name:lower()) then
			return player
		end
	end
	return nil
end

Client.FocusLost:Connect(function()
	local player = Client.Text
	Target = findplayer(player)
	if Target == nil then
		Client.Text = ""
		Logo.Text = "Failed to find player"
		wait(1)
		Logo.Text = "NAP Client"
	else
		Client.Text = Target.Name
	end
end)

NapClient.Name = "Nap Client"
NapClient.Parent = game.CoreGui

Main.Name = "Main"
Main.Parent = NapClient
Main.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
Main.BackgroundTransparency = 1.000
Main.ClipsDescendants = true
Main.Position = UDim2.new(0.374000013, 0, 1, 0)
Main.Size = UDim2.new(0.251845777, 0, 0.276699036, 0)
Main.Image = "rbxassetid://3570695787"
Main.ImageColor3 = Color3.fromRGB(33, 33, 33)
Main.ScaleType = Enum.ScaleType.Slice
Main.SliceCenter = Rect.new(100, 100, 100, 100)
Main.SliceScale = 0.120

Kick.Name = "Kick"
Kick.Parent = Main
Kick.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Kick.BorderSizePixel = 0
Kick.Position = UDim2.new(0.0403273404, 0, 0.588059664, 0)
Kick.Size = UDim2.new(0.333423793, 0, 0.108530089, 0)
Kick.Font = Enum.Font.Code
Kick.Text = "Kick"
Kick.TextColor3 = Color3.fromRGB(255, 255, 255)
Kick.TextScaled = true
Kick.TextSize = 14.000
Kick.TextWrapped = true
Kick.MouseButton1Click:Connect(function()
	Execute('kick', Target)
end)

UICorner.Parent = Kick

Punish.Name = "Punish"
Punish.Parent = Main
Punish.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Punish.BorderSizePixel = 0
Punish.Position = UDim2.new(0.632763565, 0, 0.588059664, 0)
Punish.Size = UDim2.new(0.333423793, 0, 0.108530089, 0)
Punish.Font = Enum.Font.Code
Punish.Text = "Punish"
Punish.TextColor3 = Color3.fromRGB(255, 255, 255)
Punish.TextScaled = true
Punish.TextSize = 14.000
Punish.TextWrapped = true
Punish.MouseButton1Click:Connect(function()
	Execute('punish', Target)
end)

UICorner_2.Parent = Punish

Cdestroy.Name = "Cdestroy"
Cdestroy.Parent = Main
Cdestroy.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Cdestroy.BorderSizePixel = 0
Cdestroy.Position = UDim2.new(0.632763565, 0, 0.425964892, 0)
Cdestroy.Size = UDim2.new(0.333423793, 0, 0.124857917, 0)
Cdestroy.Font = Enum.Font.Code
Cdestroy.Text = "Destroy Client"
Cdestroy.TextColor3 = Color3.fromRGB(255, 255, 255)
Cdestroy.TextScaled = true
Cdestroy.TextSize = 14.000
Cdestroy.TextWrapped = true
Cdestroy.MouseButton1Click:Connect(function()
	Execute('dc', Target)
end)

UICorner_3.Parent = Cdestroy

Warn.Name = "Warn"
Warn.Parent = Main
Warn.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Warn.BorderSizePixel = 0
Warn.Position = UDim2.new(0.0403273404, 0, 0.425964892, 0)
Warn.Size = UDim2.new(0.333423793, 0, 0.124857917, 0)
Warn.Font = Enum.Font.Code
Warn.Text = "Blur"
Warn.TextColor3 = Color3.fromRGB(255, 255, 255)
Warn.TextScaled = true
Warn.TextSize = 14.000
Warn.TextWrapped = true
Warn.MouseButton1Click:Connect(function()
	Execute('warn', Target)
end)

UICorner_4.Parent = Warn

Freeze.Name = "Freeze"
Freeze.Parent = Main
Freeze.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Freeze.BorderSizePixel = 0
Freeze.Position = UDim2.new(0.632763565, 0, 0.723263919, 0)
Freeze.Size = UDim2.new(0.333423793, 0, 0.108530089, 0)
Freeze.Font = Enum.Font.Code
Freeze.Text = "Freeze"
Freeze.TextColor3 = Color3.fromRGB(255, 255, 255)
Freeze.TextScaled = true
Freeze.TextSize = 14.000
Freeze.TextWrapped = true
Freeze.MouseButton1Click:Connect(function()
	Execute('freeze', Target)
end)

UICorner_5.Parent = Freeze

Ban.Name = "Ban"
Ban.Parent = Main
Ban.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Ban.BorderSizePixel = 0
Ban.Position = UDim2.new(0.0403273404, 0, 0.723263919, 0)
Ban.Size = UDim2.new(0.333423793, 0, 0.108530089, 0)
Ban.Font = Enum.Font.Code
Ban.Text = "Ban"
Ban.TextColor3 = Color3.fromRGB(255, 255, 255)
Ban.TextScaled = true
Ban.TextSize = 14.000
Ban.TextWrapped = true
Ban.MouseButton1Click:Connect(function()
	Execute('ban', Target)
end)

UICorner_6.Parent = Ban

Logo.Name = "Logo"
Logo.Parent = Main
Logo.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Logo.BorderSizePixel = 0
Logo.Size = UDim2.new(1, 0, 0.0936763585, 0)
Logo.Font = Enum.Font.SourceSans
Logo.Text = "NAP Client"
Logo.TextColor3 = Color3.fromRGB(255, 255, 255)
Logo.TextScaled = true
Logo.TextSize = 14.000
Logo.TextWrapped = true

UICorner_7.Parent = Logo

Client.Name = "Client"
Client.Parent = Main
Client.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Client.BorderSizePixel = 0
Client.Position = UDim2.new(0.13948074, 0, 0.184145078, 0)
Client.Size = UDim2.new(0.773910403, 0, 0.11929889, 0)
Client.Font = Enum.Font.SourceSans
Client.PlaceholderText = "Target"
Client.Text = ""
Client.TextColor3 = Color3.fromRGB(255, 255, 255)
Client.TextScaled = true
Client.TextSize = 14.000
Client.TextWrapped = true

UICorner_8.Parent = Client

Close.Name = "Close"
Close.Parent = Main
Close.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Close.BackgroundTransparency = 1.000
Close.BorderSizePixel = 0
Close.Position = UDim2.new(0.861174226, 0, 0, 0)
Close.Size = UDim2.new(0.13758637, 0, 0.0936763361, 0)
Close.Font = Enum.Font.Code
Close.Text = "-"
Close.TextColor3 = Color3.fromRGB(255, 255, 255)
Close.TextScaled = true
Close.TextSize = 14.000
Close.TextWrapped = true
Close.MouseButton1Click:Connect(function()
	Main:TweenPosition(UDim2.new(0.374, 0,1, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Elastic)
	Close_2:TweenPosition(UDim2.new(0.835, 0,0.96, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Elastic)
end)

UICorner_9.Parent = Close

Crash.Name = "Crash"
Crash.Parent = Main
Crash.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Crash.BorderSizePixel = 0
Crash.Position = UDim2.new(0.0403273404, 0, 0.863747299, 0)
Crash.Size = UDim2.new(0.333423734, 0, 0.108530089, 0)
Crash.Font = Enum.Font.Code
Crash.Text = "Crash"
Crash.TextColor3 = Color3.fromRGB(255, 255, 255)
Crash.TextScaled = true
Crash.TextSize = 14.000
Crash.TextWrapped = true
Crash.MouseButton1Click:Connect(function()
	Execute('Crash', Target)
end)

UICorner_10.Parent = Crash

Kill.Name = "Kill"
Kill.Parent = Main
Kill.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Kill.BorderSizePixel = 0
Kill.Position = UDim2.new(0.629903913, 0, 0.863747299, 0)
Kill.Size = UDim2.new(0.333423734, 0, 0.108530089, 0)
Kill.Font = Enum.Font.Code
Kill.Text = "Kill"
Kill.TextColor3 = Color3.fromRGB(255, 255, 255)
Kill.TextScaled = true
Kill.TextSize = 14.000
Kill.TextWrapped = true
Kill.MouseButton1Click:Connect(function()
	Execute('kill', Target)
end)

UICorner_11.Parent = Kill

Moreb.Name = "Moreb"
Moreb.Parent = Main
Moreb.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Moreb.BorderSizePixel = 0
Moreb.Position = UDim2.new(0.404750556, 0, 0.88115865, 0)
Moreb.Size = UDim2.new(0.186843976, 0, 0.0734423846, 0)
Moreb.Font = Enum.Font.Code
Moreb.Text = "More"
Moreb.TextColor3 = Color3.fromRGB(255, 255, 255)
Moreb.TextScaled = true
Moreb.TextSize = 14.000
Moreb.TextWrapped = true
Moreb.MouseButton1Click:Connect(function()
	More:TweenPosition(UDim2.new(0, 0,0.094, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Sine)
end)

UICorner_12.Parent = Moreb

More.Name = "More"
More.Parent = Main
More.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
More.BackgroundTransparency = 1.000
More.Position = UDim2.new(-0.00325732888, 0, 1.03227293, 0)
More.Size = UDim2.new(0.9987607, 0, 0.906323731, 0)
More.Image = "rbxassetid://3570695787"
More.ImageColor3 = Color3.fromRGB(33, 33, 33)
More.ScaleType = Enum.ScaleType.Slice
More.SliceCenter = Rect.new(100, 100, 100, 100)
More.SliceScale = 0.120

Back.Name = "Back"
Back.Parent = More
Back.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Back.BorderSizePixel = 0
Back.Position = UDim2.new(0.404750556, 0, 0.88115865, 0)
Back.Size = UDim2.new(0.186843976, 0, 0.0734423846, 0)
Back.Font = Enum.Font.Code
Back.Text = "Back"
Back.TextColor3 = Color3.fromRGB(255, 255, 255)
Back.TextScaled = true
Back.TextSize = 14.000
Back.TextWrapped = true
Back.MouseButton1Click:Connect(function()
	More:TweenPosition(UDim2.new(-0.003, 0,1.032, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Sine)
end)

UICorner_13.Parent = Back

jojo.Name = "jojo"
jojo.Parent = More
jojo.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
jojo.BorderSizePixel = 0
jojo.Position = UDim2.new(0.0435886867, 0, 0.147820801, 0)
jojo.Size = UDim2.new(0.454558074, 0, 0.119747683, 0)
jojo.Font = Enum.Font.Code
jojo.Text = "Jojo"
jojo.TextColor3 = Color3.fromRGB(255, 255, 255)
jojo.TextScaled = true
jojo.TextSize = 14.000
jojo.TextWrapped = true
jojo.MouseButton1Click:Connect(function()
    Run('game:GetService("SoundService"):ClearAllChildren()')()
	Execute('jojo', Target)
end)

UICorner_14.Parent = jojo

R6.Name = "R6"
R6.Parent = More
R6.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
R6.BorderSizePixel = 0
R6.Position = UDim2.new(0.519748926, 0, 0.147820801, 0)
R6.Size = UDim2.new(0.4480353, 0, 0.119747683, 0)
R6.Font = Enum.Font.Code
R6.Text = "R6"
R6.TextColor3 = Color3.fromRGB(255, 255, 255)
R6.TextScaled = true
R6.TextSize = 14.000
R6.TextWrapped = true
R6.MouseButton1Click:Connect(function()
	Execute('r6', Target)
end)


UICorner_15.Parent = R6

knife.Name = "knife"
knife.Parent = More
knife.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
knife.BorderSizePixel = 0
knife.Position = UDim2.new(0.0435886867, 0, 0.331713885, 0)
knife.Size = UDim2.new(0.454558074, 0, 0.119747683, 0)
knife.Font = Enum.Font.Code
knife.Text = "Grab Knife"
knife.TextColor3 = Color3.fromRGB(255, 255, 255)
knife.TextScaled = true
knife.TextSize = 14.000
knife.TextWrapped = true
knife.MouseButton1Click:Connect(function()
	Execute('knife', Target)
end)

UICorner_16.Parent = knife

rs.Name = "rs"
rs.Parent = More
rs.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
rs.BorderSizePixel = 0
rs.Position = UDim2.new(0.519748807, 0, 0.331713885, 0)
rs.Size = UDim2.new(0.454558074, 0, 0.119747683, 0)
rs.Font = Enum.Font.Code
rs.Text = "Spook Server"
rs.TextColor3 = Color3.fromRGB(255, 255, 255)
rs.TextScaled = true
rs.TextSize = 14.000
rs.TextWrapped = true
rs.MouseButton1Click:Connect(function()
    Run([[
local xd = Instance.new("Sound", game:GetService("SoundService"))
xd.SoundId = "rbxassetid://1008645583"
xd.Volume = 10
xd.Looped = true
xd:Play()
local lights = game:GetService("Lighting")
lights:ClearAllChildren()
lights.TimeOfDay = "00:00:00"
lights.FogEnd = 0
lights.FogColor = Color3.new(0, 0, 0)
lights.Brightness = 0
lights.ExposureCompensation = -3
]])()
end)

UICorner_17.Parent = rs

ss.Name = "ss"
ss.Parent = More
ss.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
ss.BorderSizePixel = 0
ss.Position = UDim2.new(0.513226092, 0, 0.51560694, 0)
ss.Size = UDim2.new(0.454557985, 0, 0.119747683, 0)
ss.Font = Enum.Font.Code
ss.Text = "Shutdown Server"
ss.TextColor3 = Color3.fromRGB(255, 255, 255)
ss.TextScaled = true
ss.TextSize = 14.000
ss.TextWrapped = true
ss.MouseButton1Click:Connect(function()
	Execute('ss')
end)

UICorner_18.Parent = ss

ds.Name = "ds"
ds.Parent = More
ds.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
ds.BorderSizePixel = 0
ds.Position = UDim2.new(0.0435887873, 0, 0.689821482, 0)
ds.Size = UDim2.new(0.454557985, 0, 0.119747683, 0)
ds.Font = Enum.Font.Code
ds.Text = "Destroy Server"
ds.TextColor3 = Color3.fromRGB(255, 255, 255)
ds.TextScaled = true
ds.TextSize = 14.000
ds.TextWrapped = true
ds.MouseButton1Click:Connect(function()
	Execute('ds')
end)

UICorner_19.Parent = ds

ts.Name = "ts"
ts.Parent = More
ts.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
ts.BorderSizePixel = 0
ts.Position = UDim2.new(0.0435886979, 0, 0.51560694, 0)
ts.Size = UDim2.new(0.454557985, 0, 0.119747683, 0)
ts.Font = Enum.Font.Code
ts.Text = "God"
ts.TextColor3 = Color3.fromRGB(255, 255, 255)
ts.TextScaled = true
ts.TextSize = 14.000
ts.TextWrapped = true
ts.MouseButton1Click:Connect(function()
	Execute('God', Target)
end)

UICorner_20.Parent = ts

test.Name = "test"
test.Parent = More
test.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
test.BorderSizePixel = 0
test.Position = UDim2.new(0.516487539, 0, 0.689821482, 0)
test.Size = UDim2.new(0.454557985, 0, 0.119747683, 0)
test.Font = Enum.Font.Code
test.Text = "Dubstep Gun"
test.TextColor3 = Color3.fromRGB(255, 255, 255)
test.TextScaled = true
test.TextSize = 14.000
test.TextWrapped = true
test.MouseButton1Click:Connect(function()
	Execute('Gun', Target)
end)

UICorner_21.Parent = test

Close_2.Name = "Close"
Close_2.Parent = NapClient
Close_2.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Close_2.BorderSizePixel = 0
Close_2.Position = UDim2.new(0.834999979, 0, 0.959999979, 0)
Close_2.Size = UDim2.new(0.155865461, 0, 0.0321450867, 0)
Close_2.Font = Enum.Font.SourceSans
Close_2.Text = "NAP Client"
Close_2.TextColor3 = Color3.fromRGB(255, 255, 255)
Close_2.TextScaled = true
Close_2.TextSize = 14.000
Close_2.TextWrapped = true

UICorner_22.Parent = Close_2

open.Name = "open"
open.Parent = Close_2
open.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
open.BackgroundTransparency = 1.000
open.BorderSizePixel = 0
open.Position = UDim2.new(0.861174226, 0, -0.00493774423, 0)
open.Size = UDim2.new(0.13758637, 0, 1.00493586, 0)
open.Font = Enum.Font.Code
open.Text = "+"
open.TextColor3 = Color3.fromRGB(255, 255, 255)
open.TextScaled = true
open.TextSize = 14.000
open.TextWrapped = true
open.MouseButton1Click:Connect(function()
	Main:TweenPosition(UDim2.new(0.374, 0,0.361, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Elastic)
	Close_2:TweenPosition(UDim2.new(0.835, 0,1, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Elastic)
end)

UICorner_23.Parent = open

local L_1_ = game:GetService("UserInputService")
function drag(L_2_arg1)
	dragToggle = nil
	local dragSpeed = 0.23
	dragInput = nil
	dragStart = nil
	local dragPos = nil
	function updateInput(L_3_arg1)
		local Delta = L_3_arg1.Position - dragStart
		local Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
		game:GetService("TweenService"):Create(L_2_arg1, TweenInfo.new(0.25), {
			Position = Position
		}):Play()
	end
	L_2_arg1.InputBegan:Connect(function(L_4_arg1)
		if (L_4_arg1.UserInputType == Enum.UserInputType.MouseButton1 or L_4_arg1.UserInputType == Enum.UserInputType.Touch) and L_1_:GetFocusedTextBox() == nil then
			dragToggle = true
			dragStart = L_4_arg1.Position
			startPos = L_2_arg1.Position
			L_4_arg1.Changed:Connect(function()
				if L_4_arg1.UserInputState == Enum.UserInputState.End then
					dragToggle = false
				end
			end)
		end
	end)
	L_2_arg1.InputChanged:Connect(function(L_5_arg1)
		if L_5_arg1.UserInputType == Enum.UserInputType.MouseMovement or L_5_arg1.UserInputType == Enum.UserInputType.Touch then
			dragInput = L_5_arg1
		end
	end)
	game:GetService("UserInputService").InputChanged:Connect(function(L_6_arg1)
		if L_6_arg1 == dragInput and dragToggle then
			updateInput(L_6_arg1)
		end
	end)
end
drag(Main)
end