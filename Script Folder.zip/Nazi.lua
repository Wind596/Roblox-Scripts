loadstring(game:HttpGet("https://raw.githubusercontent.com/Alpha-404/NAP-Client-Reanimate/main/Reanimate.lua"))()

repeat
    wait()
until getgenv().Reanimated == true

game:GetService("Players").LocalPlayer.Character["Left Leg"].LL.Position = Vector3.new(-1.5, 2, 0)
game:GetService("Players").LocalPlayer.Character["Left Leg"].LL.Orientation = Vector3.new(0, 0, 0)
game:GetService("Players").LocalPlayer.Character["Right Leg"].RL.Position = Vector3.new(1.5, -2, 0)
game:GetService("Players").LocalPlayer.Character["Right Leg"].RL.Orientation = Vector3.new(-0, 0, -0)

game:GetService("Players").LocalPlayer.Character["Left Arm"].LA.Position = Vector3.new(-1.5, 2, 0)
game:GetService("Players").LocalPlayer.Character["Left Arm"].LA.Orientation = Vector3.new(0, 0, 90)
game:GetService("Players").LocalPlayer.Character["Right Arm"].RA.Position = Vector3.new(1.5, -2, 0)
game:GetService("Players").LocalPlayer.Character["Right Arm"].RA.Orientation = Vector3.new(0, 0, 90)
