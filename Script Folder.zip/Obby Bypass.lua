local delay = 0.2
local SF = game:GetService("Workspace").Checkpoint
local CS = 1
local hrp = game:GetService("Players").LocalPlayer.Character.HumanoidRootPart

while wait(delay) do
    hrp.CFrame = SF[CS + 1].hitbox.CFrame + Vector3.new(0,2,0)
    CS += 1
end