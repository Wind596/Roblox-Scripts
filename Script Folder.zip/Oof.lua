local death = Instance.new("Sound", game:GetService("SoundService"))
death.SoundId = "rbxasset://sounds/uuhhh.mp3"
death.Playing = false
death.Volume = 5
death.Looped = false
while wait() do
    if game.Players.LocalPlayer.Character.Humanoid.Health == 0 then
        death:Play()
        wat(6)
    end
end