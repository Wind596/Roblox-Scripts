game:GetService("Workspace").GameAssets.GlobalAssets.OrbSpawns.ChildAdded:Connect(function(v)
    v:WaitForChild("TouchInterest")
    pcall(function()firetouchinterest(game:GetService("Players").LocalPlayer.Character.HumanoidRootPart, v, 0)end)
end)