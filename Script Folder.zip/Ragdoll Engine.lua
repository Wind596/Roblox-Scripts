local down = false
local ws = game:GetService('Workspace')
local players = game:GetService('Players')
local p = players.LocalPlayer
local Mouse = p:GetMouse()

game:GetService('RunService').RenderStepped:Connect(function()
	game:GetService("ReplicatedStorage").LocalRagdollEvent:Fire(false)
	if p.Character:FindFirstChild("Push") then
		p.Character.Push.Enabled = true
		p.Character.Push.PushEvent:FireServer()
		p.Character.Push.Configuration.Force.Value = math.huge
	end
	if p.Character:FindFirstChild("ImpulseGrenade") then
		p.Character.ImpulseGrenade.Enabled = true
	end
end)

Mouse.Button1Down:Connect(function()
	down = true
	Mouse.Button1Up:Connect(function()
		down = false
	end)
	while wait() do
		if down and p.Character:FindFirstChild("ImpulseGrenade") and p.Character:FindFirstChild("ImpulseGrenade").Enabled == true then
			local userdata_1 = Mouse.Hit.Position;
            local userdata_2 = Mouse.Hit
            local Target = p.Character.ImpulseGrenade.CreateGrenade;
            Target:FireServer(userdata_1, userdata_2);
		else
			break
		end
	end
end)