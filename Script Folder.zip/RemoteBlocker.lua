local re = game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest
local GameMT = getrawmetatable(game)
local Saved = GameMT.__index or GameMT.__namecall

setreadonly(GameMT, false)

GameMT.__index, GameMT.__namecall = newcclosure(function(self, arg, ...)
	if self == re and arg == "FireServer" and not checkcaller() then
		return nil 
	end
	return Saved(self, arg, ...)
end)

setreadonly(GameMT, true)