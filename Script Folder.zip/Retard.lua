loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
workspace:WaitForChild('Rig')

local Character = workspace.Rig
local Humanoid = Character:WaitForChild('Humanoid')

local Motors = {}
local Normals = {}
local state = "idle"

for i,v in pairs(Character:GetDescendants()) do
	if v:IsA("Motor6D") and v.Part0 and v.Part1  then
		Motors[tostring(v.Part1)] = v
		Normals[tostring(v.Part1)] = v.Transform
	end
end 

local function poseTweenInfo(t,s,g)
	local s = tostring(s)
	local g = tostring(g)
	local s = string.split(s,"Enum.PoseEasingStyle.")
	local g = string.split(g,"Enum.PoseEasingDirection.")
	local s = s[2]
	local g = g[2]
	local s = Enum.EasingStyle[s]
	local g = Enum.EasingDirection[g]
	return TweenInfo.new(t,s,g)
end

local RunKeyFrames = {
	{
		K = Keyframe,
		Poses = {
			Head = {
				CF = CFrame.new(0, 0.00011444091796875, -5.7220458984375e-05, 1, 0, 0, 0, 0.90696108341217, 0.42121452093124, 0, -0.42121452093124, 0.90696108341217),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, -0.099999904632568, 1, 0, 0, 0, 0.83143794536591, -0.55561763048172, 0, 0.55561763048172, 0.83143794536591),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Arm"] = {
				CF = CFrame.new(0.41375732421875, -0.52706909179688, 0, 0.59512740373611, -0.80363142490387, 0, 0.80363142490387, 0.59512740373611, 0, 0, -0, 0.99999994039536),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Leg"] = {
				CF = CFrame.new(-0.00011253356933594, 0.00016021728515625, 0, 0.96086204051971, -0.27702698111534, 0, 0.27702698111534, 0.96086204051971, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Arm"] = {
				CF = CFrame.new(-0.25941276550293, -0.33044052124023, 0, 0.75588917732239, 0.65469962358475, 0, -0.65469962358475, 0.75588917732239, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Leg"] = {
				CF = CFrame.new(0.0001068115234375, 0.00012397766113281, 0, 0.50701242685318, -0.86193877458572, 0, 0.86193877458572, 0.50701242685318, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0
	},
	{
		K = Keyframe,
		Poses = {
			Head = {
				CF = CFrame.new(0, 0.00011444091796875, -2.8610229492188e-05, 1, 0, -0, 0, 0.010030776262283, -0.99994969367981, 0, 0.99994969367981, 0.010030776262283),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, -0.099999904632568, 1, 0, 0, 0, 0.77095395326614, -0.63689082860947, 0, 0.63689082860947, 0.77095395326614),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Arm"] = {
				CF = CFrame.new(0.17875480651855, 0.075004577636719, 0, 0.68436139822006, -0.72914290428162, 0, 0.72914290428162, 0.68436139822006, 0, 0, -0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Leg"] = {
				CF = CFrame.new(-0.00016403198242188, 0.00018119812011719, 0, 0.50420278310776, 0.86358523368835, 0, -0.86358523368835, 0.50420278310776, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Arm"] = {
				CF = CFrame.new(-0.1350212097168, 0.041267395019531, 0, 0.80781018733978, 0.58944284915924, 0, -0.58944284915924, 0.80781018733978, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Leg"] = {
				CF = CFrame.new(0.00018501281738281, 0.00015830993652344, 0, 0.4980720281601, 0.86713570356369, 0, -0.86713570356369, 0.4980720281601, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0.20000000298023
	},
	{
		K = Keyframe,
		Poses = {
			Head = {
				CF = CFrame.new(0, 0.00011444091796875, -5.7220458984375e-05, 1, 0, 0, 0, 0.90696108341217, 0.42121452093124, 0, -0.42121452093124, 0.90696108341217),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, -0.099999904632568, 1, 0, 0, 0, 0.83143794536591, -0.55561763048172, 0, 0.55561763048172, 0.83143794536591),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Arm"] = {
				CF = CFrame.new(0.41375732421875, -0.52706909179688, 0, 0.59512740373611, -0.80363142490387, 0, 0.80363142490387, 0.59512740373611, 0, 0, -0, 0.99999994039536),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Leg"] = {
				CF = CFrame.new(-0.00011253356933594, 0.00016021728515625, 0, 0.96086204051971, -0.27702698111534, 0, 0.27702698111534, 0.96086204051971, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Arm"] = {
				CF = CFrame.new(-0.25941276550293, -0.33044052124023, 0, 0.75588917732239, 0.65469962358475, 0, -0.65469962358475, 0.75588917732239, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Leg"] = {
				CF = CFrame.new(0.0001068115234375, 0.00012397766113281, 0, 0.50701242685318, -0.86193877458572, 0, 0.86193877458572, 0.50701242685318, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0.40000000596046
	}
}

local IdleKF = {
	{
		K = Keyframe,
		Poses = {
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, 0.23999977111816, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Arm"] = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.97370451688766, 0.22781464457512, 0, -0.22781464457512, 0.97370451688766),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Leg"] = {
				CF = CFrame.new(0, -0.23000001907349, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Arm"] = {
				CF = CFrame.new(0, 0, 1.9073486328125e-06, 1, 0, 0, 0, 0.97983741760254, 0.19979685544968, 0, -0.19979685544968, 0.97983741760254),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Leg"] = {
				CF = CFrame.new(0, -0.25999975204468, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0
	},
	{
		K = Keyframe,
		Poses = {
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, -0.059999942779541, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Arm"] = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.99986118078232, -0.016661416739225, 0, 0.016661416739225, 0.99986118078232),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Leg"] = {
				CF = CFrame.new(0, -2.3841857910156e-07, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Arm"] = {
				CF = CFrame.new(0, 0, 3.814697265625e-06, 1, 0, 0, 0, 0.99791705608368, 0.064509570598602, 0, -0.064509570598602, 0.99791705608368),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Leg"] = {
				CF = CFrame.new(0, 0.0099999904632568, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0.20000000298023
	},
	{
		K = Keyframe,
		Poses = {
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, 0.23999977111816, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Arm"] = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.97370451688766, 0.22781464457512, 0, -0.22781464457512, 0.97370451688766),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Leg"] = {
				CF = CFrame.new(0, -0.23000001907349, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Arm"] = {
				CF = CFrame.new(0, 0, 1.9073486328125e-06, 1, 0, 0, 0, 0.97983741760254, 0.19979685544968, 0, -0.19979685544968, 0.97983741760254),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Leg"] = {
				CF = CFrame.new(0, -0.25999975204468, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0.40000000596046
	}
}

function onRunning(speed)
	if speed > 0 then
		state = "running_from_mexican_dad"
	else
		state = "idle"
	end
end

local JumpKeyFrames = {
	{
		K = Keyframe,
		Poses = {
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.99985104799271, -0.017262510955334, 0, 0.017262510955334, 0.99985104799271),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Arm"] = {
				CF = CFrame.new(1.6689300537109e-06, -8.0108642578125e-05, 1.3351440429688e-05, -0.51878464221954, 0.51619666814804, -0.68147164583206, -0.39112666249275, 0.56550067663193, 0.72610527276993, 0.76018577814102, 0.64323395490646, -0.091474920511246),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Leg"] = {
				CF = CFrame.new(1.52587890625e-05, 4.9591064453125e-05, 0, -0.84014564752579, 0.542360663414, 0, -0.542360663414, -0.84014564752579, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Arm"] = {
				CF = CFrame.new(-4.7683715820313e-07, -3.814697265625e-05, -1.9073486328125e-06, 0.15360599756241, -0.25349104404449, 0.95506417751312, 0.87915617227554, 0.47629848122597, -0.014979283325374, -0.45109838247299, 0.8419514298439, 0.2960205078125),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Leg"] = {
				CF = CFrame.new(-1.8119812011719e-05, 7.2479248046875e-05, 0, -0.83963316679001, -0.54315394163132, 0, 0.54315394163132, -0.83963316679001, 0, 0, 0, 0.99999994039536),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0
	}
}

function onJumping()
	state = "jumping"
end

local GetUpKF = {
	{
		K = Keyframe,
		Poses = {
			Head = {
				CF = CFrame.new(0, -2.8014183044434e-06, -1.9073486328125e-05, 1, -0, 0, 0, -0.39518517255783, 0.91860139369965, -0, -0.91860139369965, -0.39518517255783),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, -2.6199989318848, 1, 0, -0, 0, -0.012047519907355, -0.99992740154266, 0, 0.99992740154266, -0.012047519907355),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Arm"] = {
				CF = CFrame.new(7.1525573730469e-06, 0.000335693359375, -5.7220458984375e-06, -0.052745554596186, 0.85804098844528, -0.51086533069611, 0.005258553661406, -0.51133173704147, -0.85936719179153, -0.99859410524368, -0.048014294356108, 0.022458523511887),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Arm"] = {
				CF = CFrame.new(-8.3446502685547e-06, 0.000335693359375, -3.814697265625e-06, -0.082712277770042, -0.72951471805573, 0.67894560098648, -0.0094966245815158, -0.68067198991776, -0.73252683877945, 0.9965283870697, -0.067036747932434, 0.049372240900993),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0
	},
	{
		K = Keyframe,
		Poses = {
			Head = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, -0.15000176429749, 1, 0, 0, 0, 0.99988460540771, -0.015191309154034, 0, 0.015191309154034, 0.99988460540771),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Arm"] = {
				CF = CFrame.new(7.1525573730469e-06, 0.000335693359375, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Arm"] = {
				CF = CFrame.new(0.00011062622070313, 0.00033235549926758, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0.40000000596046
	},
	{
		K = Keyframe,
		Poses = {
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, 1.479998588562, 1, 0, 0, 0, 0.60011291503906, -0.7999153137207, 0, 0.7999153137207, 0.60011291503906),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0.60000000298023
	}
}

function onGettingUp()
	state = "gettingup"
end

local FFKF = {
	{
		K = Keyframe,
		Poses = {
			HumanoidRootPart = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			Torso = {
				CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Arm"] = {
				CF = CFrame.new(0, -1.1920928955078e-06, 1.9073486328125e-06, -0.99469649791718, -0.1028536260128, -7.1898102760315e-07, 0.078779183328152, -0.76186817884445, -0.64292359352112, 0.066126488149166, -0.6395138502121, 0.76593035459518),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Left Leg"] = {
				CF = CFrame.new(0, 2.3841857910156e-07, 1.9073486328125e-06, 0.86353558301926, -0.50428783893585, 2.2351741790771e-08, 0.48178628087044, 0.82500422000885, 0.29538103938103, -0.14895711839199, -0.25507199764252, 0.95537948608398),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Arm"] = {
				CF = CFrame.new(0, -1.9073486328125e-06, 3.814697265625e-06, -0.96897524595261, -0.18656252324581, -0.16211535036564, 0.23336590826511, -0.90664410591125, -0.35147798061371, -0.081408299505711, -0.37840566039085, 0.92205286026001),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			},
			["Right Leg"] = {
				CF = CFrame.new(0, 0, 0, 0.66963982582092, 0.74268597364426, 8.9406967163086e-08, -0.66869860887527, 0.60292929410934, 0.43510740995407, 0.32314810156822, -0.2913653254509, 0.90037858486176),
				EasingDirection = Enum.PoseEasingDirection.In,
				EasingStyle = Enum.PoseEasingStyle.Linear
			}
		},
		Time = 0
	}
}

function onFreeFall()
	state = "commiting suicide"
end
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------

Humanoid.Running:Connect(onRunning)
Humanoid.Jumping:Connect(onJumping)
Humanoid.GettingUp:Connect(onGettingUp)
Humanoid.FreeFalling:Connect(onFreeFall)

while Character ~= nil do
	wait()
	if state == "commiting suicide" then
		for i,Keyframe in pairs(FFKF) do
			local LastKeyframe = FFKF[#FFKF-1] or Keyframe
			for PoseName,Pose in pairs(Keyframe.Poses) do
				local Inst = Motors[tostring(PoseName)]
				if Inst and Inst.Name ~= "HumanoidRootPart" then
					local waitTime = Keyframe.Time
					local PoseTween = game:GetService("TweenService"):Create(Motors[tostring(PoseName)],poseTweenInfo(waitTime,Pose.EasingStyle,Pose.EasingDirection),{Transform = Pose.CF})

					PoseTween:Play()
				end
			end
			wait(Keyframe.Time)
		end

		for i,v in pairs(Motors) do
			game:GetService("TweenService"):Create(v,TweenInfo.new(),{Transform = Normals[tostring(i)]}):Play()
		end
	end
	if state == "gettingup" then
		for i,Keyframe in pairs(GetUpKF) do
			local LastKeyframe = GetUpKF[#GetUpKF-1] or Keyframe
			for PoseName,Pose in pairs(Keyframe.Poses) do
				local Inst = Motors[tostring(PoseName)]
				if Inst and Inst.Name ~= "HumanoidRootPart" then
					local waitTime = Keyframe.Time
					local PoseTween = game:GetService("TweenService"):Create(Motors[tostring(PoseName)],poseTweenInfo(waitTime,Pose.EasingStyle,Pose.EasingDirection),{Transform = Pose.CF})

					PoseTween:Play()
				end
			end
			wait(Keyframe.Time)
		end

		for i,v in pairs(Motors) do
			game:GetService("TweenService"):Create(v,TweenInfo.new(),{Transform = Normals[tostring(i)]}):Play()
		end
	end
	if state == "jumping" then
		for i,Keyframe in pairs(JumpKeyFrames) do
			local LastKeyframe = JumpKeyFrames[#JumpKeyFrames-1] or Keyframe
			for PoseName,Pose in pairs(Keyframe.Poses) do
				local Inst = Motors[tostring(PoseName)]
				if Inst and Inst.Name ~= "HumanoidRootPart" then
					local waitTime = Keyframe.Time
					local PoseTween = game:GetService("TweenService"):Create(Motors[tostring(PoseName)],poseTweenInfo(waitTime,Pose.EasingStyle,Pose.EasingDirection),{Transform = Pose.CF})

					PoseTween:Play()
				end
			end
			wait(Keyframe.Time)
		end

		for i,v in pairs(Motors) do
			game:GetService("TweenService"):Create(v,TweenInfo.new(),{Transform = Normals[tostring(i)]}):Play()
		end
	end
	if state == "running_from_mexican_dad" then
		for i,Keyframe in pairs(RunKeyFrames) do
			local LastKeyframe = RunKeyFrames[#RunKeyFrames-1] or Keyframe
			for PoseName,Pose in pairs(Keyframe.Poses) do
				local Inst = Motors[tostring(PoseName)]
				if Inst and Inst.Name ~= "HumanoidRootPart" then
					local waitTime = Keyframe.Time
					local PoseTween = game:GetService("TweenService"):Create(Motors[tostring(PoseName)],poseTweenInfo(waitTime,Pose.EasingStyle,Pose.EasingDirection),{Transform = Pose.CF})

					PoseTween:Play()
				end
			end
			wait(Keyframe.Time)
		end

		for i,v in pairs(Motors) do
			game:GetService("TweenService"):Create(v,TweenInfo.new(),{Transform = Normals[tostring(i)]}):Play()
		end
	end
	if state == "idle" then 
	   	for i,Keyframe in pairs(IdleKF) do
			local LastKeyframe = IdleKF[#IdleKF-1] or Keyframe
			for PoseName,Pose in pairs(Keyframe.Poses) do
				local Inst = Motors[tostring(PoseName)]
				if Inst and Inst.Name ~= "HumanoidRootPart" then
					local waitTime = Keyframe.Time
					local PoseTween = game:GetService("TweenService"):Create(Motors[tostring(PoseName)],poseTweenInfo(waitTime,Pose.EasingStyle,Pose.EasingDirection),{Transform = Pose.CF})

					PoseTween:Play()
				end
			end
			wait(Keyframe.Time)
		end

		for i,v in pairs(Motors) do
			game:GetService("TweenService"):Create(v,TweenInfo.new(),{Transform = Normals[tostring(i)]}):Play()
		end 
	end
end