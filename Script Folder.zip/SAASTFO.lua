workspace.ChildAdded:Connect(function(v)
    if v:IsA("Tool") then
    v:WaitForChild("Handle"):WaitForChild("TouchInterest")
    pcall(function()firetouchinterest(game:GetService("Players").LocalPlayer.Character.HumanoidRootPart, v.Handle, 0)end)
    while v~= nil do
       v:Activate()
       wait() 
    end
    end
end)

for i,v in pairs(workspace:GetChildren()) do
    if v:IsA("Tool") then 
    v:WaitForChild("Handle"):WaitForChild("TouchInterest")
    pcall(function()firetouchinterest(game:GetService("Players").LocalPlayer.Character.HumanoidRootPart, v.Handle, 0)end)
    while v~= nil do
       v:Activate()
       wait() 
    end
    end
end

local Util = loadstring(game:HttpGet("https://raw.githubusercontent.com/Alpha-404/RbxUtil/main/Util.lua"))()
Util.Bypass(game:GetService("ReplicatedStorage").Remotes.CheckTool, "FireServer", nil)