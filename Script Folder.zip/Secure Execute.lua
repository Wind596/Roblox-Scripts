	local success,error = pcall(function()
		spawn(loadstring('\112\114\105\110\116\40\39\104\105\39\41')() or function()end)
	end)

	if error then
		print("Execute Error: ", error);
	end