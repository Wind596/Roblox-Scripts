local FOV = 400 --you can change this obviously
local teamcheck = true

local Players = game:GetService("Players")
local lpr = Players.LocalPlayer
local mouse = lpr:GetMouse()
local cam = workspace.CurrentCamera
local FovCircle = Drawing.new("Circle")
FovCircle.Thickness = 2
FovCircle.NumSides = 40
FovCircle.Radius = FOV / 2
FovCircle.Filled = false
FovCircle.Position = Vector2.new(0, 0)
FovCircle.Visible = true
FovCircle.Color = Color3.fromRGB(255, 255, 255)

local function GetClosestFromMouse()
local lchar = lpr.Character
if lchar then
local dist, x, y = FOV, mouse.X, mouse.Y
for i, v in pairs(Players:GetPlayers()) do
if teamcheck and v.Team == lpr.Team then continue end
local plrChar = v.Character
if plrChar then
local hitting = plrChar:FindFirstChild("Head")
if hitting then
local vppos, inlos = cam:WorldToViewportPoint(hitting.Position)
if inlos then
local fovrad = FOV / 2
local dX = vppos.X - mouse.X
local dY = vppos.Y - mouse.Y - 35
local rX = dX
local rY = dY
if rX < 0 then
rX = -rX
end
if rY < 0 then
rY = -rY
end
if rX < fovrad and rY < fovrad then
local cdist = rX + rY
if cdist < dist then
dist = cdist / 2
x = vppos.X
y = vppos.Y
end
end
end
end
end
end
return Vector2.new(x, y)
end
end

game:GetService("RunService").RenderStepped:Connect(function()
FovCircle.Position = Vector2.new(mouse.x, mouse.y + 35)
end)

local hook
hook = hookfunction(getrawmetatable(game).__namecall, function(...)
if getnamecallmethod() == "GetMouseLocation" then
return GetClosestFromMouse()
end
return hook(...)
end)