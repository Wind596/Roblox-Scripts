game:GetService("UserInputService").InputBegan:Connect(function(key, gay)
    if gay then return "say no homo bitch" end 
    if key.KeyCode == Enum.KeyCode.E then
        local tar = game:GetService("Players").LocalPlayer:GetMouse().Target
        repeat
        local userdata_1 = tar;
        local Target = game:GetService("Players").LocalPlayer.Backpack.Axe.RemoteEvent;
        Target:FireServer(userdata_1);
        game["Run Service"].RenderStepped:Wait()
        until tar == nil
    end
end)

for i,v in pairs(game:GetService("StarterGui"):GetDescendants()) do
    if string.match(string.lower(v.Name), "client") then
       d:Destroy() 
    end
end