loadstring(game:HttpGet("https://raw.githubusercontent.com/Alpha-404/NAP-Client-Reanimate/main/Reanimate.lua"))()

repeat
    wait()
until getgenv().Reanimated == true

game:GetService("Players").LocalPlayer.Character["Left Leg"].LL.Position = Vector3.new(-1.5,2,0)
game:GetService("Players").LocalPlayer.Character["Right Leg"].RL.Position = Vector3.new(1.5,2,0)