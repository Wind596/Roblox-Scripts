loadstring(game:HttpGet("https://pastebin.com/raw/tUUGAeaH", true))()

spoof(game:GetService("Players").LocalPlayer.Character.Humanoid, "WalkSpeed", 16)
game:GetService("Players").LocalPlayer.Character.Humanoid.WalkSpeed = 90