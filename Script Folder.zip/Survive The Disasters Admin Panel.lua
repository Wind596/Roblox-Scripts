if game:GetService("RunService"):IsStudio() then 
    print("stop trying to patch my code")
    wait(3)
    while true do end
    return 
end
if game:GetService("Players").LocalPlayer.Name == "kornelek09" or game:GetService("Players").LocalPlayer.Name == "jwklong" then 
    print("stop trying to patch my code")
    wait(3)
    while true do end
    return 
end
wait(1)
game:GetService("StarterGui").Admin.AdminGui.Script:Destroy()
game:GetService("Players").LocalPlayer.Character:BreakJoints()
print("ADMIN CRACK LOADED BY Birb#4125")