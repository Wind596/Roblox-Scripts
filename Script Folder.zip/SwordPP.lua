local sword = game:GetService("Players").LocalPlayer.Character.Foil
sword.Handle.Mesh:Destroy()
sword.Grip = CFrame.new(1.3, -1.5, -1.5, 0, 1, 0, -1, 0, 0, 0, 0, -1)
game:GetService("Players").LocalPlayer.Character.Humanoid:UnequipTools()
game:GetService("Players").LocalPlayer.Character.Humanoid:EquipTool(sword)