print("NAP SERVICE")
print("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
local viruses = {}

local Blacklist = {"c-rex", "vaccine", "spread", "fire","INfecTION","Script......Or is it...", "4D Being", "ThisScriptIsAJumpStartToAHeï¿½lthyLifestyle", "micolord","ProperGrï¿½mmerNeededInPhilosiphalLocations;insertNoobHere","bryant90","OH SNAP YOU GOT INFECTED XD XD XD","Wormed","NOISE","N0ISESCRIPT","Virus","IStï¿½rtHere","garmo hacked ur place","N00B 4TT4CK!","dï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ng.........you got owned...","letgo09","sonicthehedgehogxx Made this!!","VIVRUS","WTFZ0R","IMAHAKWTFZ","I'm getting T1R33D","System Error 69605X09423","STFU NOOB","SkapeTTAJA","FreeStyleMï¿½yGoAnywhereIfNeeded","Hello...I ï¿½m Your New Lord Lolz","Hello I am your new lord lolz","Elkridge Fire Department","Zackisk","join teh moovment!","Kill tem!";"StockSound";"Deth 2 teh samurai!";"OHAI";"OH SNAP YOU GOT INFECTED XD XD XD";"No samurai plzzz";"4D Being";"Virus";"4dbeing";"4d being";"loser";"infected";"rolf";"Wildfire";"geometry";"guest talker";"anti-lag";"snap infection";"numbrez";"imahakwtfz";"wtfzor";"d??????????????ng.........you got owned...";"vivrus";"zomg saved";"hello...i ?m your new lord lolz";"worm";"guest_talking_script";"snapreducer";"snap-reducer";"timer";"datacontrollers";"chaotic";"teleportscript";"spreadify";"antivirussoftware";"2_2_1_1_s_s_";"safity lock";"ropack";"no availiblitly lock";"protection";"whfcjgysa";"073dea7p";"Snap Reducer";"ROFL";"Anti Lag";"AntiLag";"AntiVirus";"Anti-Virus";"Anti Virus";"Guest Free Chat Script";"lol";"bob";"Snap Remover";"SnapRemover";"N00B 4TT4CK";"garmo hacked ur place";"?9001";"bryant90";"Dont Worry Im A Friendly Virus";"IsAVirus";"Wormed";"stanley12345678910";"micolord";"charlie84";"cahrlie84";"SkapeTTAJA";"STFU NOOB";"Random?GoesHere:3";"Making Cat Ice Cream Make Me Happy!";"ANTIVIRISIS";"ANTIVIRIS";"77?";"IAmHereToHe?lYourPlace";"ProperGr?mmerNeededInPhilosiphalLocations;insertNoobHere";"I'm getting T1R33D";"H4XXX :3";"Sunstaff";"boomboom9188";"FreeStyleM?yGoAnywhereIfNeeded";"ThisScriptIsAJumpStartToAHe?lthyLifestyle";"d??????????????ng.........you got owned...";"Deidara4 is sick of you noobs.";"Fire";"FeelFreeToIns3rtGramm?tic?lErrorsHere";"Nomnomnom1 will hack you too! MWAHAHA!";"ZXMLFCSAJORWQ#)CXFDRE)$#Q)JCOUSEW#)@!HOIFDS(AEQ#HI*DFHRI(#FA";"NoNoIDon'tNeedAllOfYourAwkw?rdSovietArguments";[[""''""''""?|`?]];"ISt?rtHere";"**virusmaster**";"Vivurursdd";"Loadstring";}

function check(obj)
    for i,c in pairs(Blacklist) do
        if obj.Name == c then
            print("Virus Found : " .. obj:GetFullName())
        end
    end
end

for i,c in pairs(game:GetDescendants()) do
    check(c)
end