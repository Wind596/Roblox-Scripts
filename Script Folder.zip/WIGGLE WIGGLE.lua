local lib = loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/RbxUtil/main/Util.lua'))()
local p = game:GetService("Players").LocalPlayer
local REALC = p.Character
loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/V2.5'))()
local rig = REALC.Rig

local RA = lib.Weld(rig["Right Arm"], rig.Torso, CFrame.new())
local LA = lib.Weld(rig["Left Arm"], rig.Torso, CFrame.new())

local bg = Instance.new("Sound", rig)
bg.SoundId = "rbxassetid://170184872"
bg.Volume = 10
bg.Looped = true
bg:Play()

local ded = false

REALC.Humanoid.Died:Connect(function() ded = true end)

spawn(function()
    while ded == false do
        game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer("WIGGLE WIGGLE", "All")
        wait(10)
    end
end)

while true do
	lib.Lerp(0.05, RA, CFrame.new(-1.5, 1.4288764, -0.00530052185, 1, 0, 0, 0, -0.999989212, -0.00461299717, 0, 0.00461299717, -0.999989331))
	lib.Lerp(0.05, LA, CFrame.new(1.5, 0.0095846653, -0.00137901306, 1, 0, 0, 0, 0.999955475, 0.00942543987, 0, -0.0094254408, 0.999955595))
	wait(0.2)
	lib.Lerp(0.05, RA, CFrame.new(-1.5, 0.0095846653, -0.00137901306, 1, 0, 0, 0, 0.999955475, 0.00942543987, 0, -0.0094254408, 0.999955595))
	lib.Lerp(0.05, LA, CFrame.new(1.5, 1.4288764, -0.00530052185, 1, 0, 0, 0, -0.999989212, -0.00461299717, 0, 0.00461299717, -0.999989331))
	wait(0.2)
end