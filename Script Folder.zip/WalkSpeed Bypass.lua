local hum = game:GetService("Players").LocalPlayer.Character.Humanoid
local GameMt = getrawmetatable(game)
local OldIndex = GameMt.__index

setreadonly(GameMt, false)

GameMt.__index = newcclosure(function(Self, Key)
	if not checkcaller() and Self == hum and Key == "WalkSpeed" then
		return 16
	end

	return OldIndex(Self, Key)
end)

setreadonly(GameMt, true)