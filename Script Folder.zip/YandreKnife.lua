local char = game:GetService("Players").LocalPlayer.Character
local idk = false

local hrp = char.TurtleNeck

hrp.Handle.Transparency = 0.5
hrp.Handle.SpecialMesh:Destroy()
hrp.Handle.CanCollide = false

hrp.Parent = workspace

hrp.Handle.Massless = true
hrp.Handle:WaitForChild("TouchInterest"):Destroy()

local OCF = char.HumanoidRootPart.CFrame

local bp = Instance.new("BodyPosition", hrp.Handle)
bp.D = 60
bp.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
bp.Position = char.Torso.Position + Vector3.new(0, 15, 0)
wait(0.5)
flinger = Instance.new("BodyAngularVelocity",hrp.Handle)
flinger.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
flinger.P = 1000000000000000000000000000
flinger.AngularVelocity = Vector3.new(10000,10000,10000)
hrp.Handle.CanCollide = false

char.HumanoidRootPart.CFrame = OCF

--------------------------------------------------------------

local att0 = Instance.new("Attachment",char["YandereKnife"].Handle)
local idk = false
att0.Orientation = Vector3.new(0, -90, -90)
att0.Position = Vector3.new(-0.8, 0, 0.9)
att0.Name = "thingy"

local att1 = Instance.new("Attachment",char["Right Arm"])

local ap = Instance.new("AlignPosition",char["Right Arm"])
ap.Attachment0 = att0
ap.Attachment1 = att1
ap.RigidityEnabled = true 

local ao = Instance.new("AlignOrientation",char["Right Arm"]) 
ao.Attachment0 = att0
ao.Attachment1 = att1
ao.RigidityEnabled = true
char["YandereKnife"].Handle.AccessoryWeld:Destroy()

-----------------------------------------------------------

local RA = char["Right Arm"]
local att0 = Instance.new("Attachment",RA)
att0.Orientation = Vector3.new(0, 0, 0)
att0.Position = Vector3.new(-1.5, 0, 0)
att0.Name = "RA"

local att1 = Instance.new("Attachment",char["Torso"])

local ap = Instance.new("AlignPosition",RA)
ap.Attachment0 = att0
ap.Attachment1 = att1
ap.RigidityEnabled = true 


local ao = Instance.new("AlignOrientation",RA) 
ao.Attachment0 = att0
ao.Attachment1 = att1
ao.RigidityEnabled = true

char["Torso"]["Right Shoulder"]:Destroy()

----------------------------------------------------------------------------------

local e = game:GetService("Players").LocalPlayer:GetMouse().Button1Down:Connect(function()
	idk = false
	bp.Position = char["YandereKnife"].Handle.Position
	hrp.Handle.Position = char["YandereKnife"].Handle.Position
	game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.2), {['CFrame'] = CFrame.new(-1.5, 0, 0, 0.906307757, 0, -0.42261827, 0.298836231, 0.707106829, 0.640856385, 0.298836231, -0.707106829, 0.640856385)}):Play()
	wait(0.4)
	game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1)}):Play()
end)

----------------------------------------------------------------------------------

local f = game:GetService("UserInputService").InputBegan:Connect(function(key, gay)
	if gay then return end

	if key.KeyCode == Enum.KeyCode.F then
		if idk then
			idk = false
			game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1)}):Play()
			bp.Position = char["YandereKnife"].Handle.Position
		    hrp.Handle.Position = char["YandereKnife"].Handle.Position
		else
			idk = true
			game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-0.899999976, 1, -1.39999998, 0.173648223, 0.98480773, 4.30473115e-08, 0, -4.37113883e-08, 0.99999994, 0.98480773, -0.173648223, -7.59040475e-09)}):Play()
		end
	elseif key.KeyCode == Enum.KeyCode.R then
	    if game:GetService("Players").LocalPlayer:GetMouse().Target == nil then return end
	    idk = false
	    game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 1.5, 0, 1, 0, 0, 0, -0.939692616, 0.342020214, 0, -0.342020214, -0.939692616)}):Play()
	    wait(0.4)
	    game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.2), {['CFrame'] = CFrame.new(-1.5, 0.5, 0.5, 1, 0, -0, 0, 0.707106829, 0.707106829, 0, -0.707106829, 0.707106829)}):Play()
	    bp.Position = game:GetService("Players").LocalPlayer:GetMouse().Hit.Position
		hrp.Handle.Position = game:GetService("Players").LocalPlayer:GetMouse().Hit.Position
		wait(0.27)
		game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1)}):Play()
	elseif key.KeyCode == Enum.KeyCode.G then
	    bp.Position = char.Torso.Position + Vector3.new(0, 15, 0)
	    hrp.Handle.Position = char.Torso.Position + Vector3.new(0, 15, 0)
	end
end)

------------------------------------------------------------------------------------

game:GetService("Players").LocalPlayer.CharacterAdded:Wait()
e:Disconnect()
f:Disconnect()
bp:Destroy()