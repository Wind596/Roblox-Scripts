local Anim_Speed = 0.1

loadstring(game:HttpGet("https://raw.githubusercontent.com/Alpha-404/NAP-Client-Reanimate/main/Reanimate.lua"))()
local char = game:GetService("Players").LocalPlayer.Character
local p = game:GetService("Players").LocalPlayer
char.Torso:WaitForChild("NAP Client Reanim")

local RUSSIA = Instance.new("Sound", char["Torso"])
RUSSIA.SoundId = "rbxassetid://4708544112"
RUSSIA.Volume = 10
RUSSIA.Looped = true
RUSSIA:Play()

function Animate(joint, cframe)
    game:GetService("TweenService"):Create(joint, TweenInfo.new(Anim_Speed), {['CFrame'] = cframe}):Play()
end

Animate(char["Torso"].TORSO, CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.978147626, -0.2079117, 0, 0.2079117, 0.978147626))
Animate(char["Left Leg"].LL, CFrame.new(0.5, 2, -0.300000012, 1, 0, -0, 0, 0.978147626, 0.2079117, 0, -0.2079117, 0.978147626))
Animate(char["Right Leg"].RL, CFrame.new(-0.5, 2, -0.300000012, 1, 0, -0, 0, 0.978147626, 0.2079117, 0, -0.2079117, 0.978147626))
    
while wait(Anim_Speed) do
    Animate(char["Torso"].TORSO, CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.978147626, -0.2079117, 0, 0.2079117, 0.978147626))
    Animate(char["Left Arm"].LA, CFrame.new(1.5, 0.200000003, 0.5, 1, 0, -0, 0, 0.707106829, 0.707106829, 0, -0.707106829, 0.707106829))
    Animate(char["Right Arm"].RA, CFrame.new(-1.5, 0.200000003, 0.5, 1, 0, -0, 0, 0.707106829, 0.707106829, 0, -0.707106829, 0.707106829))
    Animate(char["Left Leg"].LL, CFrame.new(0.5, 2, -0.300000012, 1, 0, -0, 0, 0.98480773, 0.173648179, 0, -0.173648179, 0.98480773))
    Animate(char["Right Leg"].RL, CFrame.new(-0.5, 2, -0.300000012, 1, 0, -0, 0, 0.98480773, 0.173648179, 0, -0.173648179, 0.98480773))
    wait(Anim_Speed)
    Animate(char["Left Arm"].LA, CFrame.new(1.5, 0.100000001, 0.200000003, 1, 0, -0, 0, 0.978147626, 0.2079117, 0, -0.2079117, 0.978147626))
    Animate(char["Right Arm"].RA, CFrame.new(-1.5, 0.100000001, 0.200000003, 1, 0, -0, 0, 0.978147626, 0.2079117, 0, -0.2079117, 0.978147626))
    Animate(char["Torso"].TORSO, CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.99619472, -0.087155737, 0, 0.087155737, 0.99619472))
    Animate(char["Left Leg"].LL, CFrame.new(0.5, 2, -0, 1, 0, -0, 0, 0.99619472, 0.087155737, 0, -0.087155737, 0.99619472))
    Animate(char["Right Leg"].RL, CFrame.new(-0.5, 2, -0, 1, 0, -0, 0, 0.99619472, 0.087155737, 0, -0.087155737, 0.99619472))
end