local lib = {}

function lib:CreateWin()
	local Entity = Instance.new("ScreenGui")
	local Top = Instance.new("Frame")
	local MainContainer = Instance.new("Frame")
	local UIListLayout = Instance.new("UIListLayout")
	local Placeholder = Instance.new("TextButton")
	local Placeholder_2 = Instance.new("TextButton")
	local TextBox = Instance.new("TextBox")
	local UICorner_3 = Instance.new("UICorner")
	local TextLabel = Instance.new("TextLabel")
	local Split = Instance.new("Frame")
	local TabContainer = Instance.new("Frame")
	local UIListLayout_2 = Instance.new("UIListLayout")
	local Placeholder_3 = Instance.new("TextButton")
	local Placeholder_4 = Instance.new("TextButton")
	local Tab = Instance.new("TextButton")
	local UICorner_4 = Instance.new("UICorner")

	Entity.Name = "Entity"
	Entity.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
	Entity.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

	Top.Name = "Top"
	Top.Parent = Entity
	Top.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
	Top.BorderSizePixel = 0
	Top.Position = UDim2.new(0.292662114, 0, 0.422330111, 0)
	Top.Size = UDim2.new(0, 209, 0, 13)

	MainContainer.Name = "MainContainer"
	MainContainer.Parent = Top
	MainContainer.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
	MainContainer.BorderSizePixel = 0
	MainContainer.Position = UDim2.new(0.263157904, 0, 0.973393381, 0)
	MainContainer.Size = UDim2.new(0, 154, 0, 209)

	UIListLayout.Parent = MainTabContainer
	UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
	UIListLayout.Padding = UDim.new(0, 5)

	Placeholder.Name = "Placeholder"
	Placeholder.Parent = MainTabContainer
	Placeholder.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Placeholder.BorderSizePixel = 0
	Placeholder.Position = UDim2.new(0.138888896, 0, 0, 0)
	Placeholder.Size = UDim2.new(0, 39, 0, 0)
	Placeholder.Font = Enum.Font.SourceSans
	Placeholder.Text = ""
	Placeholder.TextColor3 = Color3.fromRGB(0, 0, 0)
	Placeholder.TextSize = 14.000

	Placeholder_2.Name = "Placeholder"
	Placeholder_2.Parent = MainTabContainer
	Placeholder_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Placeholder_2.BorderSizePixel = 0
	Placeholder_2.Position = UDim2.new(0.138888896, 0, 0, 0)
	Placeholder_2.Size = UDim2.new(0, 39, 0, 0)
	Placeholder_2.Font = Enum.Font.SourceSans
	Placeholder_2.Text = ""
	Placeholder_2.TextColor3 = Color3.fromRGB(0, 0, 0)

	TextBox.Parent = MainTabContainer
	TextBox.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
	TextBox.BorderSizePixel = 0
	TextBox.Position = UDim2.new(0.147286817, 0, 0.0505617969, 0)
	TextBox.Size = UDim2.new(0, 91, 0, 26)
	TextBox.Font = Enum.Font.Code
	TextBox.Text = ""
	TextBox.TextColor3 = Color3.fromRGB(255, 255, 255)
	TextBox.TextSize = 14.000

	UICorner_3.Parent = TextBox

	TextLabel.Parent = Top
	TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextLabel.BackgroundTransparency = 1.000
	TextLabel.BorderSizePixel = 0
	TextLabel.Size = UDim2.new(0, 72, 0, 13)
	TextLabel.Font = Enum.Font.SciFi
	TextLabel.Text = "Entity"
	TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	TextLabel.TextSize = 14.000

	Split.Name = "Split"
	Split.Parent = Top
	Split.BackgroundColor3 = Color3.fromRGB(250, 250, 250)
	Split.BorderSizePixel = 0
	Split.Position = UDim2.new(0.258373201, 0, 1, 0)
	Split.Size = UDim2.new(0, 1, 0, 208)

	TabContainer.Name = "TabContainer"
	TabContainer.Parent = Top
	TabContainer.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
	TabContainer.BorderSizePixel = 0
	TabContainer.Position = UDim2.new(0, 0, 0.973393381, 0)
	TabContainer.Size = UDim2.new(0, 54, 0, 209)

	UIListLayout_2.Parent = TabContainer
	UIListLayout_2.HorizontalAlignment = Enum.HorizontalAlignment.Center
	UIListLayout_2.SortOrder = Enum.SortOrder.LayoutOrder
	UIListLayout_2.Padding = UDim.new(0, 5)

	Placeholder_3.Name = "Placeholder"
	Placeholder_3.Parent = TabContainer
	Placeholder_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Placeholder_3.BorderSizePixel = 0
	Placeholder_3.Position = UDim2.new(0.138888896, 0, 0, 0)
	Placeholder_3.Size = UDim2.new(0, 39, 0, 0)
	Placeholder_3.Font = Enum.Font.SourceSans
	Placeholder_3.Text = ""
	Placeholder_3.TextColor3 = Color3.fromRGB(0, 0, 0)
	Placeholder_3.TextSize = 14.000

	Placeholder_4.Name = "Placeholder"
	Placeholder_4.Parent = TabContainer
	Placeholder_4.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Placeholder_4.BorderSizePixel = 0
	Placeholder_4.Position = UDim2.new(0.138888896, 0, 0, 0)
	Placeholder_4.Size = UDim2.new(0, 39, 0, 0)
	Placeholder_4.Font = Enum.Font.SourceSans
	Placeholder_4.Text = ""
	Placeholder_4.TextColor3 = Color3.fromRGB(0, 0, 0)
	Placeholder_4.TextSize = 14.000

	local obj = {}

	function obj:Tab(name)
		local MainTabContainer = Instance.new("Frame")
		local UICorner = Instance.new("UICorner")
		local Tab = Instance.new("TextButton")
		local UICorner_4 = Instance.new("UICorner")

		Tab.Name = "Tab"
		Tab.Parent = TabContainer
		Tab.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
		Tab.BorderSizePixel = 0
		Tab.Size = UDim2.new(0, 39, 0, 14)
		Tab.Font = Enum.Font.SciFi
		Tab.Text = name
		Tab.TextColor3 = Color3.fromRGB(255, 255, 255)
		Tab.TextScaled = true
		Tab.TextSize = 14.000
		Tab.TextWrapped = true

		UICorner_4.CornerRadius = UDim.new(0, 4)
		UICorner_4.Parent = Tab

		MainTabContainer.Name = name .. "TabContainer"
		MainTabContainer.Parent = MainContainer
		MainTabContainer.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
		MainTabContainer.BorderSizePixel = 0
		MainTabContainer.Position = UDim2.new(0.077922076, 0, 0.0717703402, 0)
		MainTabContainer.Size = UDim2.new(0, 129, 0, 178)
		UICorner.Parent = MainTabContainer
	end
	
	function obj:Button(name, tab, call)
		local Button = Instance.new("TextButton")
		local UICorner_2 = Instance.new("UICorner")
		local call = call or function() end
		Button.Name = "Button"
		Button.Parent = MainContainer[tab]
		Button.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
		Button.BorderSizePixel = 0
		Button.Position = UDim2.new(0.147286817, 0, 0.26404494, 0)
		Button.Size = UDim2.new(0, 91, 0, 25)
		Button.Font = Enum.Font.SciFi
		Button.Text = name
		Button.TextColor3 = Color3.fromRGB(255, 255, 255)
		Button.TextScaled = true
		Button.TextSize = 14.000
		Button.TextWrapped = true
		Button.MouseButton1Click:Connect(function()
			pcall(call)
		end)
		
		UICorner_2.CornerRadius = UDim.new(0, 6)
		UICorner_2.Parent = Button
	end

	return obj

end
--return lib

local main = lib:CreateWin()
main:Tab("gay")
main:Button("Noice", "gayTabContainer", 
    function() 
        print('hi') 
    end)