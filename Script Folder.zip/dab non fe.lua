local Player = game:GetService('Players').localPlayer
local Character = Player.Character
Character.Animate:Destroy()
local plr = game:GetService('Players').LocalPlayer
local Humanoid = Character.Humanoid
local char = plr.Character
local hum = char.Humanoid
local ra = char["Right Arm"]
local la= char["Left Arm"]
local rl= char["Right Leg"]
local ll = char["Left Leg"]
local hed = char.Head
local root = char.HumanoidRootPart
local rootj = root.RootJoint
local tors = char.Torso
local RootCF = CFrame.fromEulerAnglesXYZ(-1.57, 0, 3.14)
local RHCF = CFrame.fromEulerAnglesXYZ(0, 1.6, 0)
local LHCF = CFrame.fromEulerAnglesXYZ(0, -1.6, 0)
local cam = workspace.CurrentCamera
sine = 0
trazx = Instance.new("ParticleEmitter")
c = game:GetService("Players").LocalPlayer.Character
local meme = Instance.new("Sound", c)
meme.Pitch = 1
meme.Looped = true
meme.TimePosition = 1

CF = CFrame.new
angles = CFrame.Angles
Euler = CFrame.fromEulerAnglesXYZ
Rad = math.rad
Cos = math.cos
Acos = math.acos
Sin = math.sin
random = math.random
radian = math.rad
Vec3 = Vector3.new
-------------------------------------------------------
--End Good Stuff--
-------------------------------------------------------
necko = CF(0, 1, 0, -1, -0, -0, 0, 0, 1, 0, 1, 0)
RSH, LSH = nil, nil 
RW = Instance.new("Weld") 
LW = Instance.new("Weld")
RH = tors["Right Hip"]
LH = tors["Left Hip"]
RSH = tors["Right Shoulder"] 
LSH = tors["Left Shoulder"] 
RSH.Parent = nil 
LSH.Parent = nil 
RW.Name = "RW"
RW.Part0 = tors 
RW.C0 = CF(1.5, 0.5, 0)
RW.C1 = CF(0, 0.5, 0) 
RW.Part1 = ra
RW.Parent = tors 
LW.Name = "LW"
LW.Part0 = tors 
LW.C0 = CF(-1.5, 0.5, 0)
LW.C1 = CF(0, 0.5, 0) 
LW.Part1 = la
LW.Parent = tors

function clerp(a, b, t)
	local qa = {
		QuaternionFromCFrame(a)
	}
	local qb = {
		QuaternionFromCFrame(b)
	}
	local ax, ay, az = a.x, a.y, a.z
	local bx, by, bz = b.x, b.y, b.z
	local _t = 1 - t
	return QuaternionToCFrame(_t * ax + t * bx, _t * ay + t * by, _t * az + t * bz, QuaternionSlerp(qa, qb, t))
end
function QuaternionFromCFrame(cf)
	local mx, my, mz, m00, m01, m02, m10, m11, m12, m20, m21, m22 = cf:components()
	local trace = m00 + m11 + m22
	if trace > 0 then
		local s = math.sqrt(1 + trace)
		local recip = 0.5 / s
		return (m21 - m12) * recip, (m02 - m20) * recip, (m10 - m01) * recip, s * 0.5
	else
		local i = 0
		if m00 < m11 then
			i = 1
		end
		if m22 > (i == 0 and m00 or m11) then
			i = 2
		end
		if i == 0 then
			local s = math.sqrt(m00 - m11 - m22 + 1)
			local recip = 0.5 / s
			return 0.5 * s, (m10 + m01) * recip, (m20 + m02) * recip, (m21 - m12) * recip
		elseif i == 1 then
			local s = math.sqrt(m11 - m22 - m00 + 1)
			local recip = 0.5 / s
			return (m01 + m10) * recip, 0.5 * s, (m21 + m12) * recip, (m02 - m20) * recip
		elseif i == 2 then
			local s = math.sqrt(m22 - m00 - m11 + 1)
			local recip = 0.5 / s
			return (m02 + m20) * recip, (m12 + m21) * recip, 0.5 * s, (m10 - m01) * recip
		end
	end
end
function QuaternionToCFrame(px, py, pz, x, y, z, w)
	local xs, ys, zs = x + x, y + y, z + z
	local wx, wy, wz = w * xs, w * ys, w * zs
	local xx = x * xs
	local xy = x * ys
	local xz = x * zs
	local yy = y * ys
	local yz = y * zs
	local zz = z * zs
	return CFrame.new(px, py, pz, 1 - (yy + zz), xy - wz, xz + wy, xy + wz, 1 - (xx + zz), yz - wx, xz - wy, yz + wx, 1 - (xx + yy))
end
function QuaternionSlerp(a, b, t)
	local cosTheta = a[1] * b[1] + a[2] * b[2] + a[3] * b[3] + a[4] * b[4]
	local startInterp, finishInterp
	if cosTheta >= 1.0E-4 then
		if 1 - cosTheta > 1.0E-4 then
			local theta = math.acos(cosTheta)
			local invSinTheta = 1 / Sin(theta)
			startInterp = Sin((1 - t) * theta) * invSinTheta
			finishInterp = Sin(t * theta) * invSinTheta
		else
			startInterp = 1 - t
			finishInterp = t
		end
	elseif 1 + cosTheta > 1.0E-4 then
		local theta = math.acos(-cosTheta)
		local invSinTheta = 1 / Sin(theta)
		startInterp = Sin((t - 1) * theta) * invSinTheta
		finishInterp = Sin(t * theta) * invSinTheta
	else
		startInterp = t - 1
		finishInterp = t
	end
	return a[1] * startInterp + b[1] * finishInterp, a[2] * startInterp + b[2] * finishInterp, a[3] * startInterp + b[3] * finishInterp, a[4] * startInterp + b[4] * finishInterp
end

function swait()
	game:GetService("RunService").Heartbeat:Wait()
end

function CameraEnshaking(Length, Intensity) --Took Straight from StarGlitcher!
	coroutine.resume(coroutine.create(function()
		local intensity = 1 * Intensity
		local rotM = 0.01 * Intensity
		for i = 0, Length, 0.1 do
			swait()
			intensity = intensity - 0.05 * Intensity / Length
			rotM = rotM - 5.0E-4 * Intensity / Length
			hum.CameraOffset = Vec3(radian(random(-intensity, intensity)), radian(random(-intensity, intensity)), radian(random(-intensity, intensity)))
			cam.CFrame = cam.CFrame * CF(radian(random(-intensity, intensity)), radian(random(-intensity, intensity)), radian(random(-intensity, intensity))) * Euler(radian(random(-intensity, intensity)) * rotM, radian(random(-intensity, intensity)) * rotM, radian(random(-intensity, intensity)) * rotM)
		end
		Humanoid.CameraOffset = Vec3(0, 0, 0)
	end))
end

local joyemoji = Instance.new('ParticleEmitter', tors)
joyemoji.VelocitySpread = 2000
joyemoji.Lifetime = NumberRange.new(1)
joyemoji.Speed = NumberRange.new(40)
joy= {}
for i=0, 19 do
	joy[#joy+ 1] = NumberSequenceKeypoint.new(i/19, math.random(1, 1))
end
joyemoji.Size = NumberSequence.new(joy)
joyemoji.Rate = 0
joyemoji.LockedToPart = false
joyemoji.LightEmission = 0
joyemoji.Texture = "rbxassetid://1176402123"
joyemoji.Color = ColorSequence.new(BrickColor.new("Institutional white").Color)


local LIT = Instance.new('ParticleEmitter', tors)
LIT.VelocitySpread = 2000
LIT.Lifetime = NumberRange.new(1)
LIT.Speed = NumberRange.new(45)
nani= {}
for i=0, 19 do
	nani[#nani+ 1] = NumberSequenceKeypoint.new(i/19, math.random(1, 1))
end
LIT.Size = NumberSequence.new(nani)
LIT.Rate = 0
LIT.LockedToPart = false
LIT.LightEmission = 0
LIT.Texture = "rbxassetid://1492670151"
LIT.Color = ColorSequence.new(BrickColor.new("Institutional white").Color)

local toast = Instance.new('ParticleEmitter', tors)
toast.VelocitySpread = 2000
toast.Lifetime = NumberRange.new(1)
toast.Speed = NumberRange.new(60)
toasterstoasttoast= {}
for i=0, 19 do
	toasterstoasttoast[#toasterstoasttoast+ 1] = NumberSequenceKeypoint.new(i/19, math.random(1, 1))
end
toast.Size = NumberSequence.new(toasterstoasttoast)
toast.Rate = 0
toast.LockedToPart = false
toast.LightEmission = 0
toast.Texture = "rbxassetid://436096230"
toast.Color = ColorSequence.new(BrickColor.new("Institutional white").Color)

local ok = Instance.new('ParticleEmitter', tors)
ok.VelocitySpread = 2000
ok.Lifetime = NumberRange.new(1)
ok.Speed = NumberRange.new(50)
cool= {}
for i=0, 19 do
	cool[#cool+ 1] = NumberSequenceKeypoint.new(i/19, math.random(1, 1))
end
meme.SoundId = "rbxassetid://130762736"
meme:Play()
joyemoji.Rate = 70
LIT.Rate = 70
ok.Rate = 70
toast.Rate = 70

for i = 0,50,0.1 do
	sine += .8
	swait()
	CameraEnshaking(10, 20)
	meme.Parent = hed
	rootj.C0=clerp(rootj.C0,RootCF*CF(0,0,-0.1+0.1*math.cos(sine/20))*angles(math.rad(15),math.rad(-10),math.rad(0)),0.15)
	tors.Neck.C0=clerp(tors.Neck.C0,necko*angles(math.rad(35),math.rad(0),math.rad(0)),.3)
	RH.C0=clerp(RH.C0,CF(1,-.9-0.1*math.cos(sine/20),.025*math.cos(sine/20))*RHCF*angles(math.rad(-5),math.rad(0),math.rad(0)),0.15)
	LH.C0=clerp(LH.C0,CF(-1,-.9-0.1*math.cos(sine/20),.025*math.cos(sine/20))*LHCF*angles(math.rad(-5),math.rad(-0),math.rad(-20)),0.15)
	RW.C0 = clerp(RW.C0, CFrame.new(1.1, 0.5+0.1*math.sin(sine/30), -0.6) * angles(math.rad(-0), math.rad(10), math.rad(-110)), 0.1)
	LW.C0 = clerp(LW.C0, CFrame.new(-1.5, 0.5+0.1*math.sin(sine/30), 0.055*math.cos(sine/20)) * angles(math.rad(-0), math.rad(-10), math.rad(-105)), 0.1)
end