_G.Enabled = true
loadstring(game:HttpGet("https://raw.githubusercontent.com/Skribb11es/Random-Releases/main/BasicallyFNFAutoPlay", true))()