function Joint(P1,P2,Pos,Rot)
	local AlignP = Instance.new('AlignPosition', P2);
	AlignP.ApplyAtCenterOfMass = true;
	AlignP.MaxForce = 67752;
	AlignP.MaxVelocity = math.huge/9e110;
	AlignP.ReactionForceEnabled = false;
	AlignP.Responsiveness = 200;
	AlignP.RigidityEnabled = true;
	local AlignO = Instance.new('AlignOrientation', P2);
	AlignO.MaxAngularVelocity = math.huge/9e110;
	AlignO.MaxTorque = 67752;
	AlignO.PrimaryAxisOnly = false;
	AlignO.ReactionTorqueEnabled = false;
	AlignO.Responsiveness = 200;
	AlignO.RigidityEnabled = true;
	local AttA=Instance.new('Attachment',P2);
	local AttB=Instance.new('Attachment',P1);
	AttA.Orientation = Rot
	AttA.Position = Pos
	AlignP.Attachment1 = AttA;
	AlignP.Attachment0 = AttB;
	AlignO.Attachment1 = AttA;
	AlignO.Attachment0 = AttB;
	AttA.Name = "Align" .. P1.Name
	AttB.Name = "Align" .. P1.Name
end

local bred = game:GetService("Players").LocalPlayer.Character.Backuette

bred.Handle.SpecialMesh:Destroy()
bred.Handle.AccessoryWeld:Destroy()
Joint(bred.Handle, game:GetService("Players").LocalPlayer.Character.Torso,Vector3.new(0, -1, -3.5), Vector3.new(0,90,0))
