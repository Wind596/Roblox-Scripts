function Joint(P1,P2,Pos,Rot)
	local AlignP = Instance.new('AlignPosition', P2);
	AlignP.ApplyAtCenterOfMass = true;
	AlignP.MaxForce = 67752;
	AlignP.MaxVelocity = math.huge/9e110;
	AlignP.ReactionForceEnabled = false;
	AlignP.Responsiveness = 200;
	AlignP.RigidityEnabled = true;
	local AlignO = Instance.new('AlignOrientation', P2);
	AlignO.MaxAngularVelocity = math.huge/9e110;
	AlignO.MaxTorque = 67752;
	AlignO.PrimaryAxisOnly = false;
	AlignO.ReactionTorqueEnabled = false;
	AlignO.Responsiveness = 200;
	AlignO.RigidityEnabled = true;
	local AttA=Instance.new('Attachment',P2);
	local AttB=Instance.new('Attachment',P1);
	AttA.Orientation = Rot
	AttA.Position = Pos
	AlignP.Attachment1 = AttA;
	AlignP.Attachment0 = AttB;
	AlignO.Attachment1 = AttA;
	AlignO.Attachment0 = AttB;
	AttA.Name = "Align" .. P1.Name
	AttB.Name = "Align" .. P1.Name
end

local bred = game:GetService("Players").LocalPlayer.Character.Backuette

bred.Handle.SpecialMesh:Destroy()
bred.Parent = workspace
bred.Handle:WaitForChild("TouchInterest"):Destroy()

wait(0.5)

game:GetService("Players").LocalPlayer.Character:BreakJoints()
game:GetService("Players").LocalPlayer.CharacterAdded:Wait()
wait(1)
local bred2 = game:GetService("Players").LocalPlayer.Character:WaitForChild("Backuette")
game:GetService("Players").LocalPlayer.Character.Backuette:WaitForChild("Handle")
bred2.Handle.SpecialMesh:Destroy()
bred2.Parent = workspace
bred2.Handle:WaitForChild("TouchInterest"):Destroy()

wait(0.5)

game:GetService("Players").LocalPlayer.Character:BreakJoints()
game:GetService("Players").LocalPlayer.CharacterAdded:Wait()

wait(1)

local bred3 = game:GetService("Players").LocalPlayer.Character:WaitForChild("Backuette")
game:GetService("Players").LocalPlayer.Character.Backuette:WaitForChild("Handle")

bred3.Handle.SpecialMesh:Destroy()
bred3.Parent = workspace
bred3.Handle:WaitForChild("TouchInterest"):Destroy()

game:GetService("Players").LocalPlayer.Character:BreakJoints()
game:GetService("Players").LocalPlayer.CharacterAdded:Wait()

wait(1)

local bred4 = game:GetService("Players").LocalPlayer.Character:WaitForChild("Backuette")
game:GetService("Players").LocalPlayer.Character.Backuette:WaitForChild("Handle")

bred4.Handle.SpecialMesh:Destroy()
bred4.Parent = workspace
bred4.Handle:WaitForChild("TouchInterest"):Destroy()

Joint(bred.Handle, game:GetService("Players").LocalPlayer.Character.Torso,Vector3.new(0, -1, -3.5), Vector3.new(0,90,0))
Joint(bred2.Handle, bred.Handle,Vector3.new(6,0,0), Vector3.new(0,0,0))
Joint(bred3.Handle, bred2.Handle,Vector3.new(6,0,0), Vector3.new(0,0,0))
Joint(bred4.Handle, bred3.Handle,Vector3.new(6,0,0), Vector3.new(0,0,0))
bred.Name = "bred"
bred2.Name = "bred2"
bred3.Name = "bred3"
bred4.Name = "bred4"
bred.Handle.CanCollide = false
bred2.Handle.CanCollide = false
bred3.Handle.CanCollide = false
bred4.Handle.CanCollide = false